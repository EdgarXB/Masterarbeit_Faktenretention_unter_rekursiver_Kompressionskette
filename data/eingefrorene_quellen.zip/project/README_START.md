# Masterarbeit – Dokumente und Reproduktion

Paketstand: 13.10.2026. Diesen **gesamten Ordner** auf den Stick kopieren und die Ordnerstruktur beibehalten.

**Zuerst lesen:** [Einsteigeranleitung](07_Reproduktion_und_Pruefung/README_REPRODUKTION.md). Die vorhandene [Masterarbeit](01_Arbeit_und_Dokumentation/1310_02_Masterarbeit.docx) ist die Arbeitsfassung vom 13.10.2026. Eine endgültige PDF, die korrigierte Abgabefassung und ein fertiger digitaler Anhang lagen beim Verpacken nicht vor. Vor der Abgabe ergänzen; anschließend Dateiinventar und Prüfsummen mit `update_file_index.py` aktualisieren. Offene Korrekturen stehen im [Gesamtaudit](01_Arbeit_und_Dokumentation/GESAMTAUDIT_MASTERARBEIT_UND_KORREKTURHINWEISE.md).

## Ergebnisse ohne Installation lesen

HTML-Dateien im Browser öffnen; CSV-Tabellen lassen sich auch mit einer Tabellenkalkulation lesen. Unter `02_Auswertung/` liegen:

- [01 Faktenretention](02_Auswertung/hauptexperiment_01_qa_faktenretention.html)
- [02 Längeneinhaltung](02_Auswertung/hauptexperiment_02_laengeneinhaltung.html)
- [03 Verlustmuster](02_Auswertung/hauptexperiment_03_verlustmuster.html)
- [04 Weitere Evaluationsmetriken](02_Auswertung/hauptexperiment_04_weitere_evaluationsmetriken.html)
- [05 Texttabellen](02_Auswertung/hauptexperiment_05_alle_texttabellen.html)
- [06 Vergleich bei ähnlicher Länge](02_Auswertung/hauptexperiment_06_laengenmatched_vergleichsmatrizen.html)
- [Menschliche Faktenrelevanzprüfung](02_Auswertung/human_validation_faktenrelevanz.html)
- [Menschliche QA-Validierung](02_Auswertung/human_validation_qa_faktenretention.html)

Das Faktenrelevanz-Notebook enthält bereits gespeicherte Ausgaben; seine neu erzeugte HTML-Leseversion liegt ebenfalls in `02_Auswertung/`.

## Was enthalten ist

| Ordner | Inhalt |
|---|---|
| `01_Arbeit_und_Dokumentation` | Arbeitsfassung, Kapitelentwürfe, Audits, USB-Plan, Kapitelzuordnung, Datenwörterbuch |
| `02_Auswertung` | Acht maßgebliche Notebooks, HTML, portable Eingabedaten, Tabellen, Grafiken, Quellenmanifeste |
| `03_Experiment` | Unveränderte Originalskripte, Prompts, Demonstrationsentwicklung, tatsächliche Generierungsausgaben und Calllogs; Piloten in ihrer ursprünglichen relativen Struktur |
| `04_Human_Validation_Originaldaten` | Bewertungsmasken, Instruktionen, anonyme Reviewer-Rückläufe und ursprüngliche Auswertungen |
| `05_Piloten_und_Historie` | Lesbarer Wegweiser durch Entwicklungsstände und ausgeschlossene Daten |
| `06_Umgebung_und_Modelle` | Softwarestände, kleine Bewertungsmodelle, NLTK-Daten, Modellmetadaten |
| `07_Reproduktion_und_Pruefung` | Einfache Python-Einstiegsskripte mit englischen Klassennamen, Installationsdateien und Testprotokoll |
| `08_Portable_Experiment` | Aufbereiteter Code für externe Ausführung aller sechs Verfahren und optionale künftige Kandidatengenerierung bei Temperatur 0 |

`DATEIINDEX.csv` verzeichnet Herkunft, Zweck, Status, Größe und Hash jeder Nutzdatei. `SHA256SUMS` sichert Nutzdateien und Dateiinventar. Historische Manifeste bleiben zusätzlich erhalten.

## Datengrundlage und Grenzen

Die maßgebliche Fassung heißt `aktuell_20260930`: 100 Artikel, 2.000 kanonische Fakten, sechs Verfahren, 600 rekursive Ketten, 2.400 Stufenpositionen und 48.000 QA-Positionen. Sie enthält 400 ursprüngliche sowie 200 neu erzeugte Plain-/Few-Shot-Ketten. `original_frozen` bleibt als eigener historischer Stand enthalten. Die beiden Fassungen **nicht zu einem größeren Hauptdatensatz zusammenfügen**. Leere Ausgaben und technische Fehlwerte bleiben erhalten.

Die drei großen Ollama-Modelle einschließlich des Qwen-Projektors sind auf Wunsch **nicht enthalten**. Gespeicherte Ergebnisse können ohne sie und ohne GPU ausgewertet werden. Die kleineren Modelle für BERTScore, SummaC und Clustering sind enthalten, wie im Plan vorgesehen. Eine vollständige Neugenerierung benötigt extern bereitgestellte Modelle und eine passende Runtime. Das Paket enthält keine vollständige Sammlung von Offline-Installationspaketen.

Der Originalcode bleibt zur Herkunftssicherung unverändert. Zum Einstieg die kleinen Klassen `ExperimentData`, `PackageValidator`, `AnalysisRunner`, `MetricRunner`, `ExperimentGenerator`, `SummaryRunner` und `CandidateGenerator` in Ordner 07/08 lesen. Der [Codewegweiser](07_Reproduktion_und_Pruefung/CODE_GUIDE.md) erklärt ihre Aufgaben. Im aufbereiteten Code werden alle sechs Verfahren gemeinsam ausgeführt, mit rotierender Reihenfolge der fünf generativen Verfahren. Vorhandene Kandidaten und Demonstrationen bleiben erhalten; künftige Kandidatengenerierung ist separat mit Temperatur 0 vorgesehen. Die [kurze Änderungsnotiz](08_Portable_Experiment/CODE_UND_EXPERIMENTSTAND.md) beschreibt diese Anpassung gegenüber den tatsächlich gespeicherten Läufen.

Bekannte fachliche Grenzen – etwa der nicht erhaltene echte frühere Scorer, die deterministische Artikelauswahl und Kalibrierung auf denselben Fällen – sind im Audit dokumentiert. Verpackung und technische Tests lösen diese Punkte nicht. Original-README-Dateien und Auditlinks können noch auf frühere absolute Quellpfade zeigen; die mitgelieferten Quellen sind über `DATEIINDEX.csv` auffindbar. Die neuen Startskripte finden das Paket relativ zu ihrer eigenen Datei.
