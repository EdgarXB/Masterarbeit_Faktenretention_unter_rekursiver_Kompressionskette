#!/usr/bin/env python3
"""Compute article-level paired bootstrap uncertainty for final GLM QA outcomes."""

from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Any

import numpy as np


METRICS = ("retention", "loss", "reference_discordant_answer", "token_f1")
PRIMARY_CONTRASTS = (
    ("plain", "lead_k"), ("zero_shot_cot", "plain"), ("few_shot_cot", "plain"),
    ("auto_cot", "plain"), ("automate_cot", "plain"),
    ("few_shot_cot", "zero_shot_cot"), ("automate_cot", "auto_cot"),
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def value(row: dict[str, str], metric: str) -> float:
    if metric == "token_f1":
        return float(row[metric])
    return 1.0 if row[metric] == "True" else 0.0


def ci(values: list[float], samples: int, seed: int) -> tuple[float, float]:
    array = np.asarray(values, dtype=np.float64)
    rng = np.random.default_rng(seed)
    estimates = np.asarray([
        rng.choice(array, size=len(array), replace=True).mean() for _ in range(samples)
    ])
    low, high = np.quantile(estimates, [0.025, 0.975])
    return float(low), float(high)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--detailed", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=32)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = read_csv(args.detailed)
    grouped: dict[tuple[str, str, int], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[(row["article_id"], row["summary_prompt_variant"], int(row["stage_target_words"]))].append(row)
    article_rows: list[dict[str, Any]] = []
    for (article_id, method, target), items in sorted(grouped.items()):
        observed = [row for row in items if row.get("analysis_eligible") == "True"]
        missing = len(items) - len(observed)
        if not observed:
            raise RuntimeError(f"No analyzable QA units for {article_id}/{method}/{target}")
        observed_metrics = {metric: mean(value(row, metric) for row in observed) for metric in METRICS}
        article_rows.append({
            "article_id": article_id,
            "method": method,
            "stage_target_words": target,
            "n_canonical_facts": len(items),
            "n_analyzed": len(observed),
            "n_technical_missing": missing,
            **observed_metrics,
            **{
                f"{metric}_all_missing_zero": sum(value(row, metric) for row in observed) / len(items)
                for metric in METRICS
            },
            **{
                f"{metric}_all_missing_one": (
                    sum(value(row, metric) for row in observed) + missing
                ) / len(items)
                for metric in METRICS
            },
        })
    aggregates: list[dict[str, Any]] = []
    methods = sorted({row["method"] for row in article_rows})
    for method in methods:
        for target in (500, 300, 150, 75):
            subset = [row for row in article_rows if row["method"] == method and row["stage_target_words"] == target]
            for metric in METRICS:
                values = [float(row[metric]) for row in subset]
                low, high = ci(values, args.bootstrap_samples, args.seed + target)
                aggregates.append({
                    "method": method, "stage_target_words": target, "metric": metric,
                    "n_articles": len(values), "article_mean": mean(values),
                    "bootstrap_95_ci_low": low, "bootstrap_95_ci_high": high,
                    "technical_missing_units": sum(int(row["n_technical_missing"]) for row in subset),
                    "all_missing_zero_mean": mean(float(row[f"{metric}_all_missing_zero"]) for row in subset),
                    "all_missing_one_mean": mean(float(row[f"{metric}_all_missing_one"]) for row in subset),
                })
    index = {(row["article_id"], row["method"], row["stage_target_words"]): row for row in article_rows}
    paired: list[dict[str, Any]] = []
    for contrast_index, (left, right) in enumerate(PRIMARY_CONTRASTS):
        if not {left, right}.issubset(methods):
            continue
        for target in (500, 300, 150, 75):
            articles = sorted({row["article_id"] for row in article_rows if row["stage_target_words"] == target})
            for metric in METRICS:
                differences = [
                    float(index[(article, left, target)][metric]) - float(index[(article, right, target)][metric])
                    for article in articles
                    if (article, left, target) in index and (article, right, target) in index
                ]
                if not differences:
                    continue
                low, high = ci(differences, args.bootstrap_samples, args.seed + 1000 + target + contrast_index * 10000)
                paired.append({
                    "contrast": f"{left}_minus_{right}", "stage_target_words": target,
                    "metric": metric, "n_paired_articles": len(differences),
                    "mean_paired_difference": mean(differences),
                    "bootstrap_95_ci_low": low, "bootstrap_95_ci_high": high,
                })
    write_csv(args.output_dir / "qa_article_level.csv", article_rows, list(article_rows[0].keys()))
    write_csv(
        args.output_dir / "qa_article_bootstrap_by_method_stage.csv", aggregates,
        ["method", "stage_target_words", "metric", "n_articles", "article_mean", "bootstrap_95_ci_low", "bootstrap_95_ci_high", "technical_missing_units", "all_missing_zero_mean", "all_missing_one_mean"],
    )
    write_csv(
        args.output_dir / "qa_paired_method_differences.csv", paired,
        ["contrast", "stage_target_words", "metric", "n_paired_articles", "mean_paired_difference", "bootstrap_95_ci_low", "bootstrap_95_ci_high"],
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
