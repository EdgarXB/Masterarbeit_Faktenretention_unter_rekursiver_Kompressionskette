# Eingefrorenes Protokoll für das 100-Artikel-Hauptexperiment

Status: **vor dem ersten Modellaufruf auf dem finalen Testset eingefroren**. Dieses Dokument ist
die kompakte, in ein ChatGPT-Projekt übertragbare Spezifikation. Der 30-Artikel-Pilot und der
separate 10-Artikel-Temperatur-Preflight sind Entwicklungsdaten und werden nicht mit den finalen
Ergebnissen zusammengeführt.

## Begründete Temperaturentscheidung

Die Demonstrationen für Auto-CoT und Automate-CoT wurden bereits mit `temperature=1.1` erzeugt;
die Few-Shot-CoT-Beispiele wurden ebenfalls vor dem Hauptexperiment fertiggestellt. Diese
Demonstrationen sind nun feste Textartefakte und werden weder neu erzeugt noch nachträglich
ausgewählt oder verändert. Ihre Entstehungstemperatur ist deshalb eine Eigenschaft der
Promptentwicklung.

Alle neuen Modellantworten des 100-Artikel-Hauptexperiments werden dagegen mit
`temperature=0.0` erzeugt. Diese Entscheidung wurde nach dem 30-Artikel-Piloten und vor Öffnung
des finalen Testsets durch einen getrennten, gepaarten 10-Artikel-Preflight getroffen. Im
Preflight erzeugte Temperatur 0 keine leeren Ausgaben und verbesserte Zero-Shot-CoT leicht; bei
Auto-CoT entstand kein durchgängiger Längenvorteil. Temperatur 0 wird daher primär zur Reduktion
der Samplingvarianz und zur leichteren Reproduzierbarkeit gewählt, nicht als behauptete
allgemeine Leistungsverbesserung.

## Daten und experimentelles Design

- Datensatz: `abisee/cnn_dailymail`, Konfiguration `3.0.0`, offizieller Test-Split.
- Finales Testset: exakt 100 vorab ausgewählte Artikel.
- Eingabedatei: `experiments/autocot_automatecot_100/data/final_test_100.csv`.
- SHA-256 der Eingabedatei:
  `d64d132fb953893fdf57651918fe7627174e0209fd229273ba7d4a58c8901464`.
- Alle Methoden erhalten dieselben 100 Artikel.
- Die Artikel wurden nicht zur Promptentwicklung, Demonstrationserzeugung oder
  Hyperparameterentscheidung verwendet.
- Generative Methoden werden pro Artikel in einer zyklisch rotierten Reihenfolge ausgeführt.
  Bei 100 Artikeln erscheint jede der fünf generativen Methoden exakt 20-mal an jeder
  Reihenfolgeposition.
- Lead-k ist deterministisch und benötigt keinen Modellaufruf.

Die sechs Methoden sind:

1. Lead-k
2. Plain prompting
3. Zero-Shot-CoT
4. Five-Shot-CoT
5. Auto-CoT
6. Automate-CoT

## Rekursive Kompression

Jede Methode arbeitet rekursiv:

`Originalartikel -> 500 Wörter -> 300 Wörter -> 150 Wörter -> 75 Wörter`

Die Ausgabe einer Stufe ist damit die Eingabe der folgenden Stufe. Pro generativer Methode,
Artikel und Stufe gibt es genau einen Modellaufruf. Es gibt keine Längenrevision, kein Best-of,
keine Kandidatenauswahl und keinen automatischen Retry. Technische Ausfälle oder leere Ausgaben
werden als solche gespeichert und nicht durch einen inhaltlichen Neuversuch ersetzt.

Die akzeptierten Fenster werden mit derselben implementierten Rundungsfunktion wie im Piloten
berechnet:

- 500 Wörter: 475–525
- 300 Wörter: 285–315
- 150 Wörter: 142–158
- 75 Wörter: 71–79

Wörter werden durch den bereits verwendeten regulären Ausdruck `\b\w+\b` gezählt. Diese
Definition wird nach Beginn nicht geändert.

## Eingefrorene Generierungseinstellungen

- Modellalias: `thesis-seed:v1`
- Modelldigest:
  `7a66a2f466bf48fdafa7004a7975a7f5fac6e667a6de7d01751aacb98b3f387c`
- `temperature=0.0`
- `seed=32`
- `top_p=0.95`
- `repeat_penalty=1.0`
- `num_ctx=524288`
- `num_predict=4096`
- `raw=true`
- `keep_alive=30m`
- Request-Timeout: 1800 Sekunden
- Nicht gesetzte Samplingparameter bleiben ungesetzt und verwenden den eingefrorenen
  Modell-/Runtime-Default; es werden nicht nachträglich neue Decodingparameter ergänzt.

Methodenspezifischer Raw-Wrapper:

- Plain: `cot=false`
- Zero-Shot-CoT: `cot=true`
- Five-Shot-CoT: `cot=false`
- Auto-CoT: `cot=false`
- Automate-CoT: `cot=false`

Nur Zero-Shot-CoT nutzt den aktiven Thinking-Wrapper. Dafür bleiben
`reasoning_budget=1024` und `reflection_interval=512` eingefroren. Sichtbare Reasoning-Beispiele
innerhalb eines Demonstrationsprompts sind Bestandteil des festen Prompttexts und nicht mit dem
Raw-Thinking-Wrapper gleichzusetzen.

## Prompts und Demonstrationen

- Promptmanifest:
  `experiments/autocot_automatecot_100/final_prompts/manifest.json`
- SHA-256 des Promptmanifests:
  `1c99a698b3ee40e8e72942ee262b1f50ed6e96375f9990032fd5706acbee9828`.
- Für Five-Shot-CoT, Auto-CoT und Automate-CoT existiert pro Kompressionsstufe genau ein
  eingefrorener Prompt mit fünf geordneten Demonstrationen.
- Vor jedem Start werden Manifest-, Prompt- und Demonstrationshashes geprüft.
- Plain und Zero-Shot-CoT verwenden die im Runner festgeschriebenen direkten Promptvorlagen.
- Nach Beginn des Hauptexperiments sind weder Promptänderungen noch Demonstrationsaustausch
  zulässig.

## Technische Umgebung

Beim Freeze vorhandene Umgebung:

- Ollama `0.32.6`
- Python `3.13.15`
- GPU: NVIDIA RTX PRO 6000 Blackwell Workstation Edition, 97887 MiB
- NVIDIA-Treiber `580.173.02`

Die tatsächlich beim Start beobachteten Versionen werden zusätzlich im Startmanifest erfasst.
Entscheidend ist insbesondere die Übereinstimmung des Modelldigests. Temperatur 0 garantiert
nicht auf jeder denkbaren Hardware bitidentische Ausgaben; Modellartefakt, Softwarestand und
Hardware werden deshalb gemeinsam berichtet.

## Eingefrorene Evaluation

- 20 kanonische Fakten/Fragen pro Artikel aus einem vorab definierten Pool von 24 Kandidaten.
- Faktengenerator: `thesis-gemma:v1`, `temperature=0`, `seed=32`, `num_ctx=8192`.
- Faktengenerator-Digest:
  `6316f0629137b426c9d9b853ffc4c8209589f30ee39aebede6285096c0ff47e7`.
- Der Faktengenerator darf zur Behebung eines technisch oder strukturell ungültigen Kandidatenpools
  höchstens fünf protokollierte Versuche verwenden; dies sind keine Summary-Längenrevisionen.
- QA-Antwortmodell: `thesis-qwen38-qa:v1`, `temperature=0`, `seed=32`, `num_ctx=8192`.
- QA-Modell-Digest:
  `d80421b9191aff0d4d8ea0911068452f11f3963e3e282c6b9d778932c4b268b3`.
- Für QA-Transportfehler sind höchstens drei identische API-Wiederholungen erlaubt. Inhaltlich
  gültige QA-Antworten werden nicht erneut gezogen.
- Die QA-Auswertung verlangt exakte zusammenhängende Evidenz im jeweils bewerteten Text.
- Persistente Groundingfehler werden als technisch fehlend behandelt, nicht als inhaltlicher
  Verlust umetikettiert.
- Bootstrap: 10.000 Stichproben, `seed=32`, Resampling auf Artikelebene.
- Paarweise Vergleiche verwenden dieselben Artikel über alle Methoden hinweg.

Primäre Ergebnisdimensionen sind QA-Retention und kontinuierliche Längenabweichung. Die
kontinuierliche Längenabweichung ist die Distanz in Wörtern zur nächsten Grenze des erlaubten
Fensters, geteilt durch die Zielwortzahl; innerhalb des Fensters ist sie null. Zusätzlich werden
Fenstertrefferquote, vollständige Sätze, technische Missingness und eine vorab definierte
längenadjustierte Retentionsmetrik berichtet. Für jede Artikel-Methoden-Stufen-Einheit gilt:

`length_adjusted_retention = retention_all_missing_zero / (1 + word_window_violation_rate)`

Damit entspricht der Wert bei eingehaltenem Fenster der QA-Retention; außerhalb des Fensters
sinkt er stetig mit der normalisierten Distanz. Technisch fehlende QA-Werte werden in dieser
sekundären Kennzahl konservativ als nicht behalten behandelt. Die Formel besitzt keinen anhand
des finalen Datensatzes anzupassenden Strafparameter. Sie dient als kompakte deskriptive
Gesamtsicht und ersetzt keine getrennte Berichterstattung oder Pareto-Betrachtung der beiden
Primärdimensionen. Ergebnisse werden sowohl insgesamt als auch
getrennt für 500, 300, 150 und 75 Wörter ausgewiesen. Ein hoher Retentionswert aufgrund einer
stark überlangen Ausgabe darf nicht ohne die Längenmetrik als überlegen interpretiert werden.

## Unveränderlichkeits- und Abbruchregeln

- Das Hauptexperiment beginnt erst nach erfolgreicher statischer Readiness-Prüfung.
- Der Start erfordert den expliziten Schalter `--confirm-frozen-protocol`.
- Zwischenergebnisse werden je Artikel atomar gespeichert; das Audit-JSONL wird nach jedem
  Modellaufruf auf den Datenträger synchronisiert.
- Ein unterbrochener Lauf darf ausschließlich aus diesen gespeicherten Zuständen fortgesetzt
  werden. Bereits abgeschlossene Stufen werden nicht erneut generiert.
- Ein Protokoll- oder Hashkonflikt führt zum Abbruch statt zu einer stillen Anpassung.
- Die 100 Testartikel werden nicht mit Pilot- oder Preflightdaten gepoolt.
- Nach dem ersten finalen Modellaufruf werden keine Einstellungen anhand finaler Ergebnisse
  verändert. Abweichungen und technische Probleme werden transparent berichtet.

## Zeitplanung

Der 30-Artikel-Pilot benötigte für 600 generative Aufrufe etwa 1 Stunde 55 Minuten. Linear auf
2.000 Aufrufe des 100-Artikel-Experiments hochgerechnet sind für die reine Zusammenfassungs-
generierung ungefähr 6 Stunden 20 Minuten zu erwarten. Mit Temperatur 0 ist ein realistisches
Planungsfenster **5–8 Stunden**. Die nachgelagerte Fakt-, QA- und Metrikauswertung benötigte beim
30er-Piloten rund vier Stunden; hochgerechnet sind dafür weitere **12–15 Stunden** einzuplanen.
Für die komplette Pipeline sollte daher mit **ungefähr 18–24 Stunden** gerechnet werden.
