#!/usr/bin/env python3
"""Analyze returned human-validation answer CSVs.

Drop reviewer exports into:

    human_validation_package/returns/

Then run:

    python3 analyze_human_validation_returns.py

Outputs are written to:

    human_validation_package/analysis/
"""

from __future__ import annotations

import csv
import itertools
import math
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RETURNS = ROOT / "returns"
ANALYSIS = ROOT / "analysis"
KEY_PATH = ROOT / "internal_model_label_key.csv"

VALID_QUESTION = {"good", "partial", "bad", "unclear"}
VALID_ANSWER = {"retained", "lost", "unsupported", "unclear"}
MODEL_LABELS = {"retained", "lost", "unsupported"}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def norm(value: str) -> str:
    return (value or "").strip().lower().replace(" ", "_").replace("-", "_")


def reviewer_id_from_path(path: Path) -> str:
    name = path.stem
    for suffix in ("_answers", "_completed", "_return", "_review"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
    return name or path.stem


def pct(numerator: int, denominator: int) -> str:
    if denominator == 0:
        return ""
    return f"{numerator / denominator:.3f}"


def load_key() -> dict[str, dict[str, str]]:
    return {row["review_id"]: row for row in read_csv(KEY_PATH)}


def return_files() -> list[Path]:
    if not RETURNS.exists():
        return []
    return sorted(
        path
        for path in RETURNS.glob("*.csv")
        if path.is_file() and not path.name.startswith(".")
    )


def load_returns(key: dict[str, dict[str, str]]) -> tuple[list[dict[str, str]], list[dict[str, object]]]:
    merged: list[dict[str, str]] = []
    completion: list[dict[str, object]] = []

    for path in return_files():
        reviewer = reviewer_id_from_path(path)
        rows = read_csv(path)
        seen_ids: set[str] = set()
        invalid_ids = 0
        completed = 0
        answered_any = 0

        for row in rows:
            review_id = (row.get("review_id") or "").strip()
            if not review_id:
                continue
            if review_id not in key:
                invalid_ids += 1
                continue
            if review_id in seen_ids:
                continue
            seen_ids.add(review_id)

            question_quality = norm(row.get("question_quality", ""))
            answer_label = norm(row.get("human_answer_label", ""))
            if question_quality not in VALID_QUESTION:
                question_quality = ""
            if answer_label not in VALID_ANSWER:
                answer_label = ""

            notes = (
                row.get("overall_notes")
                or row.get("human_answer_label_notes")
                or row.get("question_quality_notes")
                or ""
            )

            if question_quality or answer_label or notes.strip():
                answered_any += 1
            if question_quality and answer_label:
                completed += 1

            base = key[review_id]
            merged.append(
                {
                    "reviewer_id": reviewer,
                    "source_file": path.name,
                    "review_id": review_id,
                    "question_quality": question_quality,
                    "human_answer_label": answer_label,
                    "human_notes": notes.strip(),
                    "article_id": base["article_id"],
                    "dataset_index": base["dataset_index"],
                    "method": base["method"],
                    "stage_target_words": base["stage_target_words"],
                    "entity_type": base["entity_type"],
                    "canonical_fact_id": base["canonical_fact_id"],
                    "generated_question": base["generated_question"],
                    "reference_answer": base["reference_answer"],
                    "model_answer": base["model_answer"],
                    "model_label": base["model_label"],
                    "model_answer_status": base["model_answer_status"],
                    "model_confidence": base["model_confidence"],
                    "model_support_rationale": base["model_support_rationale"],
                    "summary_text": base["summary_text"],
                }
            )

        completion.append(
            {
                "reviewer_id": reviewer,
                "source_file": path.name,
                "rows_in_file": len(rows),
                "valid_review_ids": len(seen_ids),
                "invalid_review_ids": invalid_ids,
                "rows_with_any_human_input": answered_any,
                "complete_rows": completed,
                "completion_rate": pct(completed, len(key)),
            }
        )

    return merged, completion


def count_summary(
    rows: list[dict[str, str]],
    category: str,
    label_field: str,
    valid_labels: set[str],
) -> list[dict[str, object]]:
    counts: dict[str, Counter[str]] = defaultdict(Counter)
    for row in rows:
        label = row.get(label_field, "")
        if label not in valid_labels:
            continue
        counts[row.get(category, "")][label] += 1

    out: list[dict[str, object]] = []
    for value, counter in sorted(counts.items()):
        total = sum(counter.values())
        for label in sorted(valid_labels):
            count = counter[label]
            out.append(
                {
                    "category": category,
                    "value": value,
                    "label": label,
                    "count": count,
                    "share": pct(count, total),
                    "total": total,
                }
            )
    return out


def question_quality_summary(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    out: list[dict[str, object]] = []
    for category in ("overall", "method", "stage_target_words", "entity_type", "reviewer_id"):
        if category == "overall":
            overall_rows = [dict(row, overall="all") for row in rows]
            out.extend(count_summary(overall_rows, "overall", "question_quality", VALID_QUESTION))
        else:
            out.extend(count_summary(rows, category, "question_quality", VALID_QUESTION))
    return out


def agreement_rows(rows: list[dict[str, str]], category: str) -> list[dict[str, object]]:
    groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        human = row.get("human_answer_label", "")
        model = row.get("model_label", "")
        if human not in MODEL_LABELS or model not in MODEL_LABELS:
            continue
        groups[row.get(category, "")].append(row)

    out: list[dict[str, object]] = []
    for value, group in sorted(groups.items()):
        total = len(group)
        matches = sum(1 for row in group if row["human_answer_label"] == row["model_label"])
        out.append(
            {
                "category": category,
                "value": value,
                "compared_rows": total,
                "matches": matches,
                "agreement": pct(matches, total),
            }
        )
    return out


def human_model_agreement_summary(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    out: list[dict[str, object]] = []
    overall = [dict(row, overall="all") for row in rows]
    for category in (
        "overall",
        "reviewer_id",
        "method",
        "stage_target_words",
        "entity_type",
        "model_label",
    ):
        out.extend(agreement_rows(overall if category == "overall" else rows, category))
    return out


def confusion_matrix(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    counter: Counter[tuple[str, str]] = Counter()
    for row in rows:
        human = row.get("human_answer_label", "")
        model = row.get("model_label", "")
        if human in MODEL_LABELS and model in MODEL_LABELS:
            counter[(model, human)] += 1

    out: list[dict[str, object]] = []
    for model in sorted(MODEL_LABELS):
        for human in sorted(MODEL_LABELS):
            out.append(
                {
                    "model_label": model,
                    "human_answer_label": human,
                    "count": counter[(model, human)],
                }
            )
    return out


def disagreements(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    out = []
    for row in rows:
        human = row.get("human_answer_label", "")
        model = row.get("model_label", "")
        if human in MODEL_LABELS and model in MODEL_LABELS and human != model:
            out.append(row)
    return sorted(out, key=lambda r: (r["review_id"], r["reviewer_id"]))


def majority_label(labels: list[str], valid: set[str]) -> tuple[str, int, bool]:
    filtered = [label for label in labels if label in valid]
    if not filtered:
        return "", 0, False
    counter = Counter(filtered)
    top_count = max(counter.values())
    winners = sorted(label for label, count in counter.items() if count == top_count)
    return winners[0], top_count, len(winners) > 1


def majority_by_item(rows: list[dict[str, str]], key: dict[str, dict[str, str]]) -> list[dict[str, object]]:
    by_item: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_item[row["review_id"]].append(row)

    out = []
    for review_id, base in sorted(key.items()):
        item_rows = by_item.get(review_id, [])
        q_majority, q_count, q_tie = majority_label(
            [row.get("question_quality", "") for row in item_rows], VALID_QUESTION
        )
        a_majority, a_count, a_tie = majority_label(
            [row.get("human_answer_label", "") for row in item_rows], VALID_ANSWER
        )
        comparable = a_majority in MODEL_LABELS and base["model_label"] in MODEL_LABELS
        out.append(
            {
                "review_id": review_id,
                "num_reviewers": len({row["reviewer_id"] for row in item_rows}),
                "method": base["method"],
                "stage_target_words": base["stage_target_words"],
                "entity_type": base["entity_type"],
                "model_label": base["model_label"],
                "majority_question_quality": q_majority,
                "majority_question_quality_count": q_count,
                "question_quality_tie": q_tie,
                "majority_answer_label": a_majority,
                "majority_answer_label_count": a_count,
                "answer_label_tie": a_tie,
                "majority_matches_model": comparable and a_majority == base["model_label"],
            }
        )
    return out


def pairwise_agreement(rows: list[dict[str, str]], label_field: str, valid: set[str]) -> tuple[int, int, float | None]:
    by_item: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        if row.get(label_field, "") in valid:
            by_item[row["review_id"]].append(row)

    agreements = 0
    total_pairs = 0
    for item_rows in by_item.values():
        for left, right in itertools.combinations(item_rows, 2):
            total_pairs += 1
            if left[label_field] == right[label_field]:
                agreements += 1
    if total_pairs == 0:
        return agreements, total_pairs, None
    return agreements, total_pairs, agreements / total_pairs


def cohen_kappa_for_two_reviewers(
    rows: list[dict[str, str]], label_field: str, valid: set[str]
) -> float | None:
    reviewers = sorted({row["reviewer_id"] for row in rows})
    if len(reviewers) != 2:
        return None

    by_reviewer_item = {
        (row["reviewer_id"], row["review_id"]): row.get(label_field, "")
        for row in rows
        if row.get(label_field, "") in valid
    }
    common_ids = sorted(
        review_id
        for review_id in {row["review_id"] for row in rows}
        if all((reviewer, review_id) in by_reviewer_item for reviewer in reviewers)
    )
    if not common_ids:
        return None

    observed = sum(
        1
        for review_id in common_ids
        if by_reviewer_item[(reviewers[0], review_id)]
        == by_reviewer_item[(reviewers[1], review_id)]
    ) / len(common_ids)

    marginals = []
    for reviewer in reviewers:
        counter = Counter(by_reviewer_item[(reviewer, review_id)] for review_id in common_ids)
        marginals.append(counter)

    expected = sum(
        (marginals[0][label] / len(common_ids)) * (marginals[1][label] / len(common_ids))
        for label in valid
    )
    if math.isclose(1.0, expected):
        return None
    return (observed - expected) / (1 - expected)


def inter_annotator_summary(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    out = []
    for field, valid in (
        ("question_quality", VALID_QUESTION),
        ("human_answer_label", VALID_ANSWER),
    ):
        agreements, pairs, raw = pairwise_agreement(rows, field, valid)
        kappa = cohen_kappa_for_two_reviewers(rows, field, valid)
        out.append(
            {
                "label_field": field,
                "pairwise_pairs": pairs,
                "pairwise_agreements": agreements,
                "pairwise_raw_agreement": "" if raw is None else f"{raw:.3f}",
                "cohen_kappa_if_two_reviewers": "" if kappa is None else f"{kappa:.3f}",
            }
        )
    return out


def markdown_table(rows: list[dict[str, object]], fields: list[str], limit: int | None = None) -> str:
    shown = rows[:limit] if limit else rows
    if not shown:
        return "_No rows._"
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in shown:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def build_report(
    merged: list[dict[str, str]],
    completion: list[dict[str, object]],
    q_summary: list[dict[str, object]],
    agreement: list[dict[str, object]],
    inter: list[dict[str, object]],
    disagreement_rows: list[dict[str, object]],
) -> str:
    num_reviewers = len({row["reviewer_id"] for row in merged})
    completed_rows = sum(
        1 for row in merged if row.get("question_quality") and row.get("human_answer_label")
    )
    comparable_rows = sum(
        1
        for row in merged
        if row.get("human_answer_label") in MODEL_LABELS and row.get("model_label") in MODEL_LABELS
    )
    matches = sum(
        1
        for row in merged
        if row.get("human_answer_label") in MODEL_LABELS
        and row.get("human_answer_label") == row.get("model_label")
    )

    q_overall = [
        row for row in q_summary if row["category"] == "overall" and row["value"] == "all"
    ]
    agreement_overall = [
        row for row in agreement if row["category"] == "overall" and row["value"] == "all"
    ]

    lines = [
        "# Human Validation Report",
        "",
        f"- Returned reviewer files: {len(return_files())}",
        f"- Reviewers detected: {num_reviewers}",
        f"- Human annotation rows loaded: {len(merged)}",
        f"- Complete rows with both labels: {completed_rows}",
        f"- Human/model comparable answer rows: {comparable_rows}",
        f"- Human/model answer-label agreement: {pct(matches, comparable_rows) or 'n/a'}",
        "",
        "## Reviewer Completion",
        "",
        markdown_table(
            completion,
            [
                "reviewer_id",
                "source_file",
                "valid_review_ids",
                "rows_with_any_human_input",
                "complete_rows",
                "completion_rate",
            ],
        ),
        "",
        "## Question Quality Overall",
        "",
        markdown_table(q_overall, ["label", "count", "share", "total"]),
        "",
        "## Human vs Model Agreement Overall",
        "",
        markdown_table(agreement_overall, ["compared_rows", "matches", "agreement"]),
        "",
        "## Inter-Annotator Summary",
        "",
        markdown_table(
            inter,
            [
                "label_field",
                "pairwise_pairs",
                "pairwise_agreements",
                "pairwise_raw_agreement",
                "cohen_kappa_if_two_reviewers",
            ],
        ),
        "",
        "## Example Disagreements",
        "",
        markdown_table(
            disagreement_rows,
            [
                "review_id",
                "reviewer_id",
                "method",
                "stage_target_words",
                "entity_type",
                "model_label",
                "human_answer_label",
                "generated_question",
                "reference_answer",
                "model_answer",
            ],
            limit=12,
        ),
        "",
        "## Output Files",
        "",
        "- `merged_human_annotations.csv`",
        "- `reviewer_completion.csv`",
        "- `question_quality_summary.csv`",
        "- `human_model_agreement_summary.csv`",
        "- `human_model_confusion_matrix.csv`",
        "- `human_model_disagreements.csv`",
        "- `majority_by_item.csv`",
        "- `inter_annotator_agreement.csv`",
    ]
    return "\n".join(lines) + "\n"


def main() -> None:
    ANALYSIS.mkdir(parents=True, exist_ok=True)
    key = load_key()
    merged, completion = load_returns(key)

    merged_fields = [
        "reviewer_id",
        "source_file",
        "review_id",
        "question_quality",
        "human_answer_label",
        "human_notes",
        "article_id",
        "dataset_index",
        "method",
        "stage_target_words",
        "entity_type",
        "canonical_fact_id",
        "generated_question",
        "reference_answer",
        "model_answer",
        "model_label",
        "model_answer_status",
        "model_confidence",
        "model_support_rationale",
        "summary_text",
    ]
    completion_fields = [
        "reviewer_id",
        "source_file",
        "rows_in_file",
        "valid_review_ids",
        "invalid_review_ids",
        "rows_with_any_human_input",
        "complete_rows",
        "completion_rate",
    ]

    q_summary = question_quality_summary(merged)
    agreement = human_model_agreement_summary(merged)
    confusion = confusion_matrix(merged)
    disagreement_rows = disagreements(merged)
    majority = majority_by_item(merged, key)
    inter = inter_annotator_summary(merged)

    write_csv(ANALYSIS / "merged_human_annotations.csv", merged, merged_fields)
    write_csv(ANALYSIS / "reviewer_completion.csv", completion, completion_fields)
    write_csv(
        ANALYSIS / "question_quality_summary.csv",
        q_summary,
        ["category", "value", "label", "count", "share", "total"],
    )
    write_csv(
        ANALYSIS / "human_model_agreement_summary.csv",
        agreement,
        ["category", "value", "compared_rows", "matches", "agreement"],
    )
    write_csv(
        ANALYSIS / "human_model_confusion_matrix.csv",
        confusion,
        ["model_label", "human_answer_label", "count"],
    )
    write_csv(ANALYSIS / "human_model_disagreements.csv", disagreement_rows, merged_fields)
    write_csv(
        ANALYSIS / "majority_by_item.csv",
        majority,
        [
            "review_id",
            "num_reviewers",
            "method",
            "stage_target_words",
            "entity_type",
            "model_label",
            "majority_question_quality",
            "majority_question_quality_count",
            "question_quality_tie",
            "majority_answer_label",
            "majority_answer_label_count",
            "answer_label_tie",
            "majority_matches_model",
        ],
    )
    write_csv(
        ANALYSIS / "inter_annotator_agreement.csv",
        inter,
        [
            "label_field",
            "pairwise_pairs",
            "pairwise_agreements",
            "pairwise_raw_agreement",
            "cohen_kappa_if_two_reviewers",
        ],
    )
    write_text(
        ANALYSIS / "human_validation_report.md",
        build_report(merged, completion, q_summary, agreement, inter, disagreement_rows),
    )

    print(f"Loaded {len(return_files())} return file(s), {len(merged)} annotation row(s).")
    print(f"Wrote analysis outputs to {ANALYSIS}")


if __name__ == "__main__":
    main()
