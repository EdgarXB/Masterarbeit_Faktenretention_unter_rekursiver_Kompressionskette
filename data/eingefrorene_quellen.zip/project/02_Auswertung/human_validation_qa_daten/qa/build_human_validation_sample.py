#!/usr/bin/env python3
"""Build a small human-validation packet from the latest 10-article pilot."""

from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "experiments/prompt_comparison/20260516T134205Z_qwen30_10_article_kpi_test"
REPORT = RUN / "report"
SUMMARY_RUN = RUN / "20260516T134240Z"
OUT = ROOT / "human_validation_package"

QA_DETAILED = REPORT / "qa_retention_detailed.csv"
FACTS = RUN / "facts/canonical_facts.csv"
ARTICLES = RUN / "selected_articles_10.csv"
SUMMARY_FILES = {
    "plain": SUMMARY_RUN / "20260516T134240Z__qwen3_30b__plain_summaries.csv",
    "zero_shot_cot": SUMMARY_RUN / "20260516T134240Z__qwen3_30b__zero_shot_cot_summaries.csv",
    "few_shot_cot": SUMMARY_RUN / "20260516T134240Z__qwen3_30b__few_shot_cot_summaries.csv",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def write_csv(path: Path, rows: list[dict[str, str]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def model_label(row: dict[str, str]) -> str:
    if row.get("retention") == "True":
        return "retained"
    if row.get("loss") == "True":
        return "lost"
    if row.get("unsupported_or_hallucinated") == "True":
        return "unsupported"
    return "unclear"


def article_excerpt(text: str, limit_words: int = 120) -> str:
    words = text.split()
    if len(words) <= limit_words:
        return text
    return " ".join(words[:limit_words]) + " ..."


def main() -> None:
    facts = {row["canonical_fact_id"]: row for row in read_csv(FACTS)}
    articles = {row["article_id"]: row for row in read_csv(ARTICLES)}

    summaries: dict[tuple[str, str, str], str] = {}
    for prompt, path in SUMMARY_FILES.items():
        for row in read_csv(path):
            for stage in ("500", "300", "150", "75"):
                summaries[(prompt, row["article_id"], stage)] = row[f"summary_{stage}"]

    qa_rows = read_csv(QA_DETAILED)

    preferred_articles = {"1", "2", "3", "4", "5", "6"}
    preferred_prompts = {"plain", "few_shot_cot", "zero_shot_cot"}
    preferred_stages = {"500", "300", "150", "75"}

    candidates = [
        row
        for row in qa_rows
        if row["article_id"] in preferred_articles
        and row["summary_prompt_variant"] in preferred_prompts
        and row["stage_target_words"] in preferred_stages
    ]

    # Keep the packet small enough for volunteer reviewers while covering all
    # label types, methods, and compression depths.
    targets = {
        "model_label": {"retained": 20, "lost": 20, "unsupported": 20},
        "stage_target_words": {"500": 15, "300": 15, "150": 15, "75": 15},
        "summary_prompt_variant": {
            "plain": 20,
            "few_shot_cot": 20,
            "zero_shot_cot": 20,
        },
    }

    selected: list[dict[str, str]] = []
    used_keys: set[tuple[str, str, str, str]] = set()
    counts: dict[tuple[str, str], int] = defaultdict(int)

    def deficit(category: str, value: str) -> int:
        return max(targets[category].get(value, 0) - counts[(category, value)], 0)

    def row_score(row: dict[str, str]) -> tuple[int, int, int, str]:
        label = model_label(row)
        stage = row["stage_target_words"]
        prompt = row["summary_prompt_variant"]
        entity = row["entity_type"]
        article = row["article_id"]
        return (
            deficit("model_label", label) * 100
            + deficit("stage_target_words", stage) * 25
            + deficit("summary_prompt_variant", prompt) * 25
            + max(8 - counts[("article_id", article)], 0) * 4
            + max(6 - counts[("entity_type", entity)], 0),
            -counts[("article_id", article)],
            -counts[("entity_type", entity)],
            row["canonical_fact_id"],
        )

    while len(selected) < 60:
        eligible = []
        for row in candidates:
            label = model_label(row)
            stage = row["stage_target_words"]
            prompt = row["summary_prompt_variant"]
            key = (
                prompt,
                row["article_id"],
                stage,
                row["canonical_fact_id"],
            )
            if key in used_keys:
                continue
            if counts[("model_label", label)] >= targets["model_label"][label]:
                continue
            if counts[("stage_target_words", stage)] >= targets["stage_target_words"][stage]:
                continue
            if (
                counts[("summary_prompt_variant", prompt)]
                >= targets["summary_prompt_variant"][prompt]
            ):
                continue
            eligible.append(row)

        if not eligible:
            break

        row = max(eligible, key=row_score)
        key = (
            row["summary_prompt_variant"],
            row["article_id"],
            row["stage_target_words"],
            row["canonical_fact_id"],
        )
        selected.append(row)
        used_keys.add(key)
        counts[("model_label", model_label(row))] += 1
        counts[("stage_target_words", row["stage_target_words"])] += 1
        counts[("summary_prompt_variant", row["summary_prompt_variant"])] += 1
        counts[("article_id", row["article_id"])] += 1
        counts[("entity_type", row["entity_type"])] += 1

    selected = sorted(
        selected,
        key=lambda r: (
            int(r["article_id"]),
            int(r["stage_target_words"]),
            r["summary_prompt_variant"],
            r["canonical_fact_id"],
        ),
    )

    reviewer_rows: list[dict[str, str]] = []
    key_rows: list[dict[str, str]] = []

    for idx, row in enumerate(selected, 1):
        fact = facts[row["canonical_fact_id"]]
        article = articles[row["article_id"]]
        prompt = row["summary_prompt_variant"]
        article_id = row["article_id"]
        stage = row["stage_target_words"]
        review_id = f"HV{idx:03d}"
        summary_text = summaries[(prompt, article_id, stage)]

        reviewer_row = {
            "review_id": review_id,
            "article_id": article_id,
            "dataset_index": row["dataset_index"],
            "method": prompt,
            "stage_target_words": stage,
            "entity_type": row["entity_type"],
            "article_excerpt": article_excerpt(article["article"]),
            "source_evidence": fact["source_evidence"],
            "canonical_fact": fact["fact"],
            "generated_question": row["question"],
            "reference_answer": row["reference_answer"],
            "summary_text": summary_text,
            "model_answer": row["answer"],
            "model_support_rationale": row["support"],
            "question_quality": "",
            "question_quality_notes": "",
            "human_answer_label": "",
            "human_answer_label_notes": "",
            "overall_notes": "",
        }
        reviewer_rows.append(reviewer_row)

        key = dict(reviewer_row)
        key.update(
            {
                "canonical_fact_id": row["canonical_fact_id"],
                "model_answer_status": row["answer_status"],
                "model_confidence": row["confidence"],
                "model_label": model_label(row),
                "model_retention": row["retention"],
                "model_loss": row["loss"],
                "model_unsupported_or_hallucinated": row[
                    "unsupported_or_hallucinated"
                ],
                "token_f1": row["token_f1"],
                "normalized_exact_or_containment": row[
                    "normalized_exact_or_containment"
                ],
            }
        )
        key_rows.append(key)

    reviewer_fields = [
        "review_id",
        "article_id",
        "dataset_index",
        "method",
        "stage_target_words",
        "entity_type",
        "article_excerpt",
        "source_evidence",
        "canonical_fact",
        "generated_question",
        "reference_answer",
        "summary_text",
        "model_answer",
        "model_support_rationale",
        "question_quality",
        "question_quality_notes",
        "human_answer_label",
        "human_answer_label_notes",
        "overall_notes",
    ]
    key_fields = reviewer_fields + [
        "canonical_fact_id",
        "model_answer_status",
        "model_confidence",
        "model_label",
        "model_retention",
        "model_loss",
        "model_unsupported_or_hallucinated",
        "token_f1",
        "normalized_exact_or_containment",
    ]

    write_csv(OUT / "human_validation_annotation.csv", reviewer_rows, reviewer_fields)
    write_csv(OUT / "internal_model_label_key.csv", key_rows, key_fields)

    counts: dict[tuple[str, str], int] = defaultdict(int)
    for row in key_rows:
        counts[("model_label", row["model_label"])] += 1
        counts[("method", row["method"])] += 1
        counts[("stage", row["stage_target_words"])] += 1
        counts[("entity_type", row["entity_type"])] += 1

    summary_rows = [
        {"category": category, "value": value, "count": count}
        for (category, value), count in sorted(counts.items())
    ]
    write_csv(OUT / "sample_composition.csv", summary_rows, ["category", "value", "count"])


if __name__ == "__main__":
    main()
