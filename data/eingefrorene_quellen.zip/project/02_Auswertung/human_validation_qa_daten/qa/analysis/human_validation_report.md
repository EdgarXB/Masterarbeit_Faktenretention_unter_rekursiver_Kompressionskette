# Human Validation Report

- Returned reviewer files: 7
- Reviewers detected: 7
- Human annotation rows loaded: 420
- Complete rows with both labels: 204
- Human/model comparable answer rows: 182
- Human/model answer-label agreement: 0.582

## Reviewer Completion

| reviewer_id | source_file | valid_review_ids | rows_with_any_human_input | complete_rows | completion_rate |
| --- | --- | --- | --- | --- | --- |
| reviewer_01 | reviewer_01_answers.csv | 60 | 60 | 60 | 1.000 |
| reviewer_02 | reviewer_02_answers.csv | 60 | 2 | 2 | 0.033 |
| reviewer_03 | reviewer_03_answers.csv | 60 | 30 | 30 | 0.500 |
| reviewer_04 | reviewer_04_answers.csv | 60 | 7 | 7 | 0.117 |
| reviewer_05 | reviewer_05_answers.csv | 60 | 6 | 6 | 0.100 |
| reviewer_06 | reviewer_06_answers.csv | 60 | 39 | 39 | 0.650 |
| reviewer_07 | reviewer_07_answers.csv | 60 | 60 | 60 | 1.000 |

## Question Quality Overall

| label | count | share | total |
| --- | --- | --- | --- |
| bad | 6 | 0.029 | 204 |
| good | 172 | 0.843 | 204 |
| partial | 19 | 0.093 | 204 |
| unclear | 7 | 0.034 | 204 |

## Human vs Model Agreement Overall

| compared_rows | matches | agreement |
| --- | --- | --- |
| 182 | 106 | 0.582 |

## Inter-Annotator Summary

| label_field | pairwise_pairs | pairwise_agreements | pairwise_raw_agreement | cohen_kappa_if_two_reviewers |
| --- | --- | --- | --- | --- |
| question_quality | 264 | 184 | 0.697 |  |
| human_answer_label | 264 | 149 | 0.564 |  |

## Example Disagreements

| review_id | reviewer_id | method | stage_target_words | entity_type | model_label | human_answer_label | generated_question | reference_answer | model_answer |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| HV001 | reviewer_01 | zero_shot_cot | 75 | EVENT | unsupported | retained | How significant was this tornado outbreak compared to previous ones in the US? | It was the deadliest in more than 20 years | The summary states this was the deadliest tornado event in over two decades and the worst casualty count since the early 1990s. |
| HV001 | reviewer_03 | zero_shot_cot | 75 | EVENT | unsupported | retained | How significant was this tornado outbreak compared to previous ones in the US? | It was the deadliest in more than 20 years | The summary states this was the deadliest tornado event in over two decades and the worst casualty count since the early 1990s. |
| HV001 | reviewer_07 | zero_shot_cot | 75 | EVENT | unsupported | retained | How significant was this tornado outbreak compared to previous ones in the US? | It was the deadliest in more than 20 years | The summary states this was the deadliest tornado event in over two decades and the worst casualty count since the early 1990s. |
| HV002 | reviewer_01 | zero_shot_cot | 75 | ORG | unsupported | lost | Which agency deployed teams to the disaster area? | The Federal Emergency Management Agency | Federal aid |
| HV002 | reviewer_03 | zero_shot_cot | 75 | ORG | unsupported | retained | Which agency deployed teams to the disaster area? | The Federal Emergency Management Agency | Federal aid |
| HV002 | reviewer_07 | zero_shot_cot | 75 | ORG | unsupported | retained | Which agency deployed teams to the disaster area? | The Federal Emergency Management Agency | Federal aid |
| HV003 | reviewer_01 | plain | 150 | EVENT | unsupported | retained | How significant was this tornado outbreak compared to previous ones in the US? | It was the deadliest in more than 20 years | The outbreak was the deadliest in over two decades and represented the most severe tornado-related fatalities in the region since the early 2000s. |
| HV003 | reviewer_04 | plain | 150 | EVENT | unsupported | retained | How significant was this tornado outbreak compared to previous ones in the US? | It was the deadliest in more than 20 years | The outbreak was the deadliest in over two decades and represented the most severe tornado-related fatalities in the region since the early 2000s. |
| HV003 | reviewer_06 | plain | 150 | EVENT | unsupported | retained | How significant was this tornado outbreak compared to previous ones in the US? | It was the deadliest in more than 20 years | The outbreak was the deadliest in over two decades and represented the most severe tornado-related fatalities in the region since the early 2000s. |
| HV003 | reviewer_07 | plain | 150 | EVENT | unsupported | retained | How significant was this tornado outbreak compared to previous ones in the US? | It was the deadliest in more than 20 years | The outbreak was the deadliest in over two decades and represented the most severe tornado-related fatalities in the region since the early 2000s. |
| HV004 | reviewer_01 | zero_shot_cot | 150 | EVENT | unsupported | retained | How significant was this tornado outbreak compared to previous ones in the US? | It was the deadliest in more than 20 years | The summary states that this event was the deadliest tornado-related casualty count since the early 1990s, marking the deadliest such event in over two decades. |
| HV004 | reviewer_07 | zero_shot_cot | 150 | EVENT | unsupported | retained | How significant was this tornado outbreak compared to previous ones in the US? | It was the deadliest in more than 20 years | The summary states that this event was the deadliest tornado-related casualty count since the early 1990s, marking the deadliest such event in over two decades. |

## Output Files

- `merged_human_annotations.csv`
- `reviewer_completion.csv`
- `question_quality_summary.csv`
- `human_model_agreement_summary.csv`
- `human_model_confusion_matrix.csv`
- `human_model_disagreements.csv`
- `majority_by_item.csv`
- `inter_annotator_agreement.csv`
