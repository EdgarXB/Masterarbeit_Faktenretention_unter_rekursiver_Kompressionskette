# Three General Answer Prompt Test

The model received only `generated_question` and `summary_text`. Reference answers and human labels were used only after generation for scoring.

- Total validation items per prompt: 60
- Strict comparable set: 52 items (non-unclear human majority, answer-label ties excluded)
- Model: `glm-4.7-flash:latest`
- Temperature: 0.0
- Seed: 32

## Score Comparison

| Prompt | Scorer | Matches | Score |
| --- | --- | ---: | ---: |
| Original prompt | Original scorer | 32/52 | 61.5% |
| Original prompt | Final calibrated scorer | 41/52 | 78.8% |
| Prompt v2 | Original scorer | 33/52 | 63.5% |
| Prompt v2 | Final calibrated scorer | 36/52 | 69.2% |
| `a_minimal_evidence_span` | Original scorer | 29/52 | 55.8% |
| `a_minimal_evidence_span` | Final calibrated scorer | 33/52 | 63.5% |
| `b_typed_granularity_decision` | Original scorer | 31/52 | 59.6% |
| `b_typed_granularity_decision` | Final calibrated scorer | 37/52 | 71.2% |
| `c_verify_then_canonicalize` | Original scorer | 33/52 | 63.5% |
| `c_verify_then_canonicalize` | Final calibrated scorer | 38/52 | 73.1% |

## Final-Scorer Breakdown

### `a_minimal_evidence_span`

| Dimension | Value | Matches | Total | Score |
| --- | --- | ---: | ---: | ---: |
| method | few_shot_cot | 10 | 19 | 52.6% |
| method | plain | 15 | 16 | 93.8% |
| method | zero_shot_cot | 8 | 17 | 47.1% |
| entity_type | DATE_TIME | 7 | 7 | 100.0% |
| entity_type | EVENT | 3 | 8 | 37.5% |
| entity_type | LOCATION | 0 | 5 | 0.0% |
| entity_type | NUMBER | 5 | 7 | 71.4% |
| entity_type | OBJECT | 5 | 6 | 83.3% |
| entity_type | ORG | 4 | 7 | 57.1% |
| entity_type | OTHER | 4 | 5 | 80.0% |
| entity_type | PERSON | 5 | 7 | 71.4% |
| human_majority_label | lost | 11 | 19 | 57.9% |
| human_majority_label | retained | 21 | 30 | 70.0% |
| human_majority_label | unsupported | 1 | 3 | 33.3% |

Generation errors in comparable set: 0.

### `b_typed_granularity_decision`

| Dimension | Value | Matches | Total | Score |
| --- | --- | ---: | ---: | ---: |
| method | few_shot_cot | 13 | 19 | 68.4% |
| method | plain | 14 | 16 | 87.5% |
| method | zero_shot_cot | 10 | 17 | 58.8% |
| entity_type | DATE_TIME | 7 | 7 | 100.0% |
| entity_type | EVENT | 3 | 8 | 37.5% |
| entity_type | LOCATION | 1 | 5 | 20.0% |
| entity_type | NUMBER | 5 | 7 | 71.4% |
| entity_type | OBJECT | 5 | 6 | 83.3% |
| entity_type | ORG | 5 | 7 | 71.4% |
| entity_type | OTHER | 5 | 5 | 100.0% |
| entity_type | PERSON | 6 | 7 | 85.7% |
| human_majority_label | lost | 14 | 19 | 73.7% |
| human_majority_label | retained | 23 | 30 | 76.7% |
| human_majority_label | unsupported | 0 | 3 | 0.0% |

Generation errors in comparable set: 0.

### `c_verify_then_canonicalize`

| Dimension | Value | Matches | Total | Score |
| --- | --- | ---: | ---: | ---: |
| method | few_shot_cot | 14 | 19 | 73.7% |
| method | plain | 15 | 16 | 93.8% |
| method | zero_shot_cot | 9 | 17 | 52.9% |
| entity_type | DATE_TIME | 7 | 7 | 100.0% |
| entity_type | EVENT | 4 | 8 | 50.0% |
| entity_type | LOCATION | 1 | 5 | 20.0% |
| entity_type | NUMBER | 5 | 7 | 71.4% |
| entity_type | OBJECT | 5 | 6 | 83.3% |
| entity_type | ORG | 4 | 7 | 57.1% |
| entity_type | OTHER | 5 | 5 | 100.0% |
| entity_type | PERSON | 7 | 7 | 100.0% |
| human_majority_label | lost | 15 | 19 | 78.9% |
| human_majority_label | retained | 23 | 30 | 76.7% |
| human_majority_label | unsupported | 0 | 3 | 0.0% |

Generation errors in comparable set: 0.

## Full Prompt Texts

### `a_minimal_evidence_span`

```text
You are a grounded question-answering component in a factual-retention evaluation.
Use only the SUMMARY. Never use outside knowledge or infer a missing identity or value.

Procedure:
1. Find the smallest passage in the summary that directly answers the question.
2. If such evidence exists, return the shortest answer that preserves the exact meaning and specificity of that passage. Prefer words copied from the summary.
3. A paraphrase is acceptable only when it is unambiguously equivalent. Do not replace a requested name, place, date, quantity, or event with a broader category.
4. If the requested information is absent, only implied, or less specific than the question requires, return NOT_FOUND.
5. If the summary explicitly gives a different or contradictory value, answer with the value actually stated in the summary.

Return JSON only with exactly these keys: answer, support, confidence.
answer must be one concise phrase or sentence. support must quote the decisive summary text.
confidence must be HIGH, MEDIUM, or LOW.

QUESTION:
{question}

SUMMARY:
{summary}
```

### `b_typed_granularity_decision`

```text
You perform strict, summary-grounded QA for factual-retention measurement.
The SUMMARY is the only allowed evidence. The reference answer is intentionally unavailable.

Before producing JSON, silently apply this decision process:
- Determine what kind of information the question requests and its required granularity (for example identity, location, time, quantity, yes/no, action, cause, status, or comparison).
- Locate explicit summary evidence that fills that requested slot at the same granularity.
- Distinguish three situations:
  A. The requested fact is explicitly supported: answer it directly.
  B. The summary explicitly supplies a different specific fact: return that stated fact.
  C. The requested slot is absent or only vaguely suggested: return NOT_FOUND.
- Do not turn related context into an answer. Do not invent a proper name from a generic description. Do not treat a broader region, approximate category, or associated event as the specific item requested.
- When supported, phrase the answer so that it directly completes the question, while staying as close as possible to the summary's wording. Preserve negation, comparison direction, units, scope, and certainty.

Return valid JSON only: {{"answer": ..., "support": ..., "confidence": ...}}.
Use NOT_FOUND exactly when situation C applies. Keep answer concise. Quote only decisive summary evidence in support. confidence is HIGH, MEDIUM, or LOW.

QUESTION:
{question}

SUMMARY:
{summary}
```

### `c_verify_then_canonicalize`

```text
Answer a factual question from a summary under a strict no-external-knowledge rule.

Silently perform two passes.
PASS 1 — Evidence and entailment:
Identify the exact claim requested by the question. Find the strongest explicit evidence in the SUMMARY. Decide whether that evidence alone would let a careful reader answer the question without guessing. Mere topical relevance, partial clues, and broader categories are insufficient.

PASS 2 — Answer verification:
Draft a minimal answer and check every content word against the evidence. The answer must match the requested entity/value type and specificity, preserve qualifiers and polarity, and contain no unsupported detail. Use an ordinary canonical expression when two wordings are clearly equivalent, but do not perform uncertain semantic expansion. If verification fails because the requested fact is missing, output NOT_FOUND. If the evidence clearly states a conflicting alternative, output that alternative rather than NOT_FOUND.

Output JSON only with exactly three keys:
- answer: one short, direct phrase or sentence, or NOT_FOUND
- support: the shortest exact excerpt that justifies the decision
- confidence: HIGH, MEDIUM, or LOW

QUESTION:
{question}

SUMMARY:
{summary}
```

