# Optimized Answer Prompt Validation

- Items rerun: 60
- Comparable human-majority items: 58
- Old model vs human-majority agreement: 33/58 = 0.569
- New model vs human-majority agreement: 30/58 = 0.517
- Delta: -3 item(s)

## New Agreement By Method

| method | matches | total | agreement |
| --- | ---: | ---: | ---: |
| few_shot_cot | 12 | 19 | 0.632 |
| plain | 11 | 20 | 0.550 |
| zero_shot_cot | 7 | 19 | 0.368 |

## New Agreement By Entity

| entity_type | matches | total | agreement |
| --- | ---: | ---: | ---: |
| DATE_TIME | 7 | 7 | 1.000 |
| EVENT | 0 | 9 | 0.000 |
| LOCATION | 1 | 6 | 0.167 |
| NUMBER | 3 | 8 | 0.375 |
| OBJECT | 4 | 6 | 0.667 |
| ORG | 5 | 8 | 0.625 |
| OTHER | 4 | 6 | 0.667 |
| PERSON | 6 | 8 | 0.750 |

## Agreement By Old Model Label

| old_model_label | old_matches | new_matches | total |
| --- | ---: | ---: | ---: |
| lost | 17 | 13 | 20 |
| retained | 16 | 15 | 19 |
| unsupported | 0 | 2 | 19 |

## New Label Distribution

| new_model_label | count |
| --- | ---: |
| lost | 16 |
| retained | 23 |
| unsupported | 19 |

## Label Changes

| old_model_label | new_model_label | count |
| --- | --- | ---: |
| lost | lost | 15 |
| lost | retained | 4 |
| lost | unsupported | 1 |
| retained | lost | 1 |
| retained | retained | 18 |
| retained | unsupported | 1 |
| unsupported | lost | 1 |
| unsupported | retained | 1 |
| unsupported | unsupported | 18 |
