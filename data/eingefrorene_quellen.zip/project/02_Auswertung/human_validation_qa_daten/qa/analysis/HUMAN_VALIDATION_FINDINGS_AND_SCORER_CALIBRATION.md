# Human Validation Findings And Scorer Calibration

Date: 2026-06-17

This document summarizes the human validation procedure for the QA-based factual-retention metric, the baseline findings, the prompt/scorer changes tested afterwards, and the resulting KPI changes. It is intended as source material for the thesis methodology and results discussion.

## 1. Purpose

The thesis uses automatic question answering over generated summaries as a proxy for factual retention. The validation checked two linked assumptions:

1. The generated facts/questions/reference answers are usable for human factual-retention assessment.
2. The automatic answer labels, `retained`, `lost`, and `unsupported`, agree reasonably with human judgments.

The validation sample contains 60 QA items selected from:

`experiments/prompt_comparison/20260516T134205Z_qwen30_10_article_kpi_test`

The answer model used in the original pipeline was:

`glm-4.7-flash:latest`

## 2. Human Validation Inputs

Returned reviewer files were placed in:

`human_validation_package/returns/`

They were normalized to stable filenames:

| Reviewer file |
| --- |
| `reviewer_01_answers.csv` |
| `reviewer_02_answers.csv` |
| `reviewer_03_answers.csv` |
| `reviewer_04_answers.csv` |
| `reviewer_05_answers.csv` |
| `reviewer_06_answers.csv` |
| `reviewer_07_answers.csv` |

Then the analysis script was run:

```bash
cd /home/edgar/main/.tools/ollama/human_validation_package
python3 analyze_human_validation_returns.py
```

Outputs were written to:

`human_validation_package/analysis/`

Key output files:

| File | Role |
| --- | --- |
| `human_validation_report.md` | Main generated validation report |
| `merged_human_annotations.csv` | Human annotations joined with hidden model labels |
| `majority_by_item.csv` | Human-majority label per validation item |
| `human_model_agreement_summary.csv` | Agreement by method, stage, entity type, and model label |
| `human_model_confusion_matrix.csv` | Model-label vs human-label counts |
| `human_model_disagreements.csv` | Row-level disagreements |
| `inter_annotator_agreement.csv` | Pairwise reviewer agreement |

## 3. Baseline Human Validation KPIs

The returned files contained 420 possible reviewer rows: 7 reviewers times 60 validation items.

| KPI | Value |
| --- | ---: |
| Returned reviewer files | 7 |
| Reviewers detected | 7 |
| Human annotation rows loaded | 420 |
| Complete rows with both labels | 204 |
| Human/model comparable answer rows | 182 |
| Row-level human/model answer-label agreement | 106/182 = 0.582 |
| Pairwise raw agreement for question quality | 184/264 = 0.697 |
| Pairwise raw agreement for answer labels | 149/264 = 0.564 |

Reviewer completion was uneven:

| Reviewer | Complete rows | Completion rate |
| --- | ---: | ---: |
| reviewer_01 | 60 | 1.000 |
| reviewer_02 | 2 | 0.033 |
| reviewer_03 | 30 | 0.500 |
| reviewer_04 | 7 | 0.117 |
| reviewer_05 | 6 | 0.100 |
| reviewer_06 | 39 | 0.650 |
| reviewer_07 | 60 | 1.000 |

## 4. Question Quality Finding

The generated questions were judged mostly usable.

| Question-quality label | Count | Share |
| --- | ---: | ---: |
| good | 172 | 0.843 |
| partial | 19 | 0.093 |
| bad | 6 | 0.029 |
| unclear | 7 | 0.034 |

Combined `good + partial` coverage was:

```text
191/204 = 0.936
```

At the item-majority level, all 60 validation items had majority question quality `good`.

Interpretation: the fact/question generation step is sufficiently reliable for the validation sample. The main weakness is not question generation but answer-label classification.

## 5. Baseline Answer-Label Finding

At the item-majority level, two items had a human-majority label of `unclear`, leaving 58 comparable items for model-vs-human majority comparison.

| Metric | Value |
| --- | ---: |
| Original item-level agreement | 33/58 = 0.569 |

The original item-level agreement by method was:

| Method | Matches | Total | Agreement |
| --- | ---: | ---: | ---: |
| few_shot_cot | 15 | 19 | 0.789 |
| plain | 13 | 20 | 0.650 |
| zero_shot_cot | 5 | 19 | 0.263 |

The original item-level agreement by entity type was:

| Entity type | Matches | Total | Agreement |
| --- | ---: | ---: | ---: |
| DATE_TIME | 7 | 7 | 1.000 |
| EVENT | 0 | 9 | 0.000 |
| LOCATION | 3 | 6 | 0.500 |
| NUMBER | 3 | 8 | 0.375 |
| OBJECT | 5 | 6 | 0.833 |
| ORG | 3 | 8 | 0.375 |
| OTHER | 5 | 6 | 0.833 |
| PERSON | 7 | 8 | 0.875 |

The weakest class was the original `unsupported` label:

| Original model label | Matches | Total | Agreement |
| --- | ---: | ---: | ---: |
| lost | 17 | 20 | 0.850 |
| retained | 16 | 19 | 0.842 |
| unsupported | 0 | 19 | 0.000 |

Interpretation: `lost` and `retained` labels were relatively reliable, but `unsupported` was overproduced by the lexical scorer. Many human reviewers considered paraphrased answers retained, while the lexical scorer marked them unsupported because they did not overlap enough with the reference answer.

Example:

| Field | Text |
| --- | --- |
| Reference answer | `It was the deadliest in more than 20 years` |
| Model answer | `The summary states this was the deadliest tornado event in over two decades and the worst casualty count since the early 1990s.` |
| Original model label | `unsupported` |
| Human majority | `retained` |

## 6. Prompt Optimization Experiments

After the human validation, a focused rerun script was created:

`human_validation_package/rerun_optimized_answer_prompt.py`

The script reruns only the 60 human-validation items instead of the full 10-article grid. It:

1. Reads `internal_model_label_key.csv`.
2. Reads human-majority labels from `analysis/majority_by_item.csv`.
3. Calls `glm-4.7-flash:latest` with a revised answer prompt.
4. Scores the new answers.
5. Compares new labels to the human-majority labels.

### 6.1 Optimized Prompt v1

Output folder:

`human_validation_package/analysis/optimized_answer_prompt/`

Result:

| Metric | Value |
| --- | ---: |
| Original agreement on comparable items | 33/58 = 0.569 |
| v1 prompt agreement | 30/58 = 0.517 |
| Delta | -3 items |

Interpretation: v1 was rejected. It encouraged cleaner answer behavior but overproduced `NOT_FOUND`/`lost` in some cases and reduced agreement.

### 6.2 Optimized Prompt v2

Output folder:

`human_validation_package/analysis/optimized_answer_prompt_v2/`

The v2 prompt explicitly asked for more canonical, question-aligned answers, especially for comparison questions. It included guidance such as:

```text
For 'how significant' comparison questions, answer as a full sentence beginning with 'It was ...' when possible.
Convert equivalent expressions to simple question-aligned wording when safe: 'over two decades' may be answered as 'more than 20 years'.
```

Result:

| Metric | Value |
| --- | ---: |
| Original agreement on comparable items | 33/58 = 0.569 |
| v2 prompt agreement | 34/58 = 0.586 |
| Delta | +1 item |

v2 agreement by method:

| Method | Matches | Total | Agreement |
| --- | ---: | ---: | ---: |
| few_shot_cot | 13 | 19 | 0.684 |
| plain | 13 | 20 | 0.650 |
| zero_shot_cot | 8 | 19 | 0.421 |

v2 agreement by entity:

| Entity type | Matches | Total | Agreement |
| --- | ---: | ---: | ---: |
| DATE_TIME | 4 | 7 | 0.571 |
| EVENT | 4 | 9 | 0.444 |
| LOCATION | 1 | 6 | 0.167 |
| NUMBER | 4 | 8 | 0.500 |
| OBJECT | 5 | 6 | 0.833 |
| ORG | 5 | 8 | 0.625 |
| OTHER | 4 | 6 | 0.667 |
| PERSON | 7 | 8 | 0.875 |

Interpretation: prompt v2 partially fixed event paraphrase cases, especially where the answerer could restate `over two decades` as a more reference-aligned answer. However, the overall improvement was small. This showed that prompt wording alone was not the main bottleneck; the scoring rule also needed calibration.

## 7. Lexical Scorer Calibration

The scorer was patched in:

`score_model_selection_batch.py`

Original scoring rule:

```python
norm_ref in norm_answer
or norm_answer in norm_ref
or token_f1(reference, answer) >= 0.50
```

This was brittle for short paraphrases. A correct answer such as `over two decades` could fail against a reference answer such as `more than 20 years`.

### 7.1 Patch Summary

The patch added:

1. `canonicalize_for_retention(text)`
2. Safe paraphrase normalization:
   - `over two decades` -> `more than 20 years`
   - `more than two decades` -> `more than 20 years`
   - `two decades` -> `20 years`
   - `U.S.`, `US`, `USA` -> `United States`
   - simple decade-word conversion, e.g. `three decades` -> `30 years`
3. A conservative calibrated short-answer fallback:
   - reference length must be at most 10 tokens
   - answer/reference length ratio must be at most 4.0
   - canonicalized token F1 must be at least 0.43
4. `retention_token_f1()`, so the detailed QA output reports the calibrated F1 value.

The patch intentionally does not expand vague category descriptions into named entities. For example:

| Reference | Answer | Patched retained? |
| --- | --- | ---: |
| `The Federal Emergency Management Agency` | `Federal aid` | False |
| `It was the deadliest in more than 20 years` | `The summary states this was the deadliest tornado event in over two decades...` | True |

This preserves a conservative treatment of named-entity questions.

## 8. Impact Of The Lexical Scorer Patch

The scorer patch was evaluated against the original human-validation answer outputs. This isolates the effect of the scoring change without changing the answer model.

| Metric | Before patch | After patch |
| --- | ---: | ---: |
| Item-level agreement with human majority | 33/58 = 0.569 | 37/58 = 0.638 |
| Improvement | | +4 items |

Patched agreement by method:

| Method | Before | After |
| --- | ---: | ---: |
| few_shot_cot | 15/19 = 0.789 | 15/19 = 0.789 |
| plain | 13/20 = 0.650 | 14/20 = 0.700 |
| zero_shot_cot | 5/19 = 0.263 | 8/19 = 0.421 |

Patched agreement by stage:

| Target words | Before | After |
| --- | ---: | ---: |
| 75 | 8/15 = 0.533 | 9/15 = 0.600 |
| 150 | 8/15 = 0.533 | 10/15 = 0.667 |
| 300 | 7/15 = 0.467 | 8/15 = 0.533 |
| 500 | 10/13 = 0.769 | 10/13 = 0.769 |

Patched agreement by entity type:

| Entity type | Before | After |
| --- | ---: | ---: |
| DATE_TIME | 7/7 = 1.000 | 7/7 = 1.000 |
| EVENT | 0/9 = 0.000 | 4/9 = 0.444 |
| LOCATION | 3/6 = 0.500 | 3/6 = 0.500 |
| NUMBER | 3/8 = 0.375 | 3/8 = 0.375 |
| OBJECT | 5/6 = 0.833 | 5/6 = 0.833 |
| ORG | 3/8 = 0.375 | 3/8 = 0.375 |
| OTHER | 5/6 = 0.833 | 5/6 = 0.833 |
| PERSON | 7/8 = 0.875 | 7/8 = 0.875 |

Patched agreement by original model label:

| Original label | Before | After |
| --- | ---: | ---: |
| lost | 17/20 = 0.850 | 17/20 = 0.850 |
| retained | 16/19 = 0.842 | 16/19 = 0.842 |
| unsupported | 0/19 = 0.000 | 4/19 = 0.211 |

Label changes caused by the patch:

| Original label | Patched label | Count |
| --- | --- | ---: |
| lost | lost | 20 |
| retained | retained | 19 |
| unsupported | unsupported | 15 |
| unsupported | retained | 4 |

Interpretation: the scorer patch improved the exact weakness identified by human validation. It corrected four false-`unsupported` paraphrase cases, primarily in `EVENT` items, while leaving `lost`, `retained`, and named-entity cases stable.

## 9. Remaining Disagreements After Patch

After scorer calibration, 21 of the 58 comparable item-majority cases still disagreed with human majority labels.

Remaining disagreements by human-majority label:

| Human-majority label | Count |
| --- | ---: |
| retained | 11 |
| lost | 7 |
| unsupported | 3 |

Remaining disagreements by patched model label:

| Patched model label | Count |
| --- | ---: |
| unsupported | 15 |
| retained | 3 |
| lost | 3 |

Remaining disagreements by entity type:

| Entity type | Count |
| --- | ---: |
| ORG | 5 |
| NUMBER | 5 |
| EVENT | 5 |
| LOCATION | 3 |
| PERSON | 1 |
| OTHER | 1 |
| OBJECT | 1 |

Remaining disagreements by method:

| Method | Count |
| --- | ---: |
| zero_shot_cot | 11 |
| plain | 6 |
| few_shot_cot | 4 |

Five of the 21 remaining disagreements had human answer-label ties. These cases should be interpreted cautiously because the human signal itself was weak.

### 9.1 Explanation Categories

The remaining disagreements fall into several categories.

#### A. Semantic paraphrases still too broad for lexical scoring

Example:

| Field | Text |
| --- | --- |
| Reference answer | `a brutal counter-insurgency campaign` |
| Model answer | `systematically planning, committing, and covering up crimes` |
| Human majority | `retained` |
| Patched scorer | `unsupported` |

Humans often accepted this as a retained event-level fact, but the lexical scorer cannot reliably infer that the two phrasings refer to the same broader campaign.

#### B. Vague answer versus named-entity answer

Example:

| Field | Text |
| --- | --- |
| Reference answer | `The Federal Emergency Management Agency` |
| Model answer | `Federal aid` |
| Human majority | sometimes `retained` |
| Patched scorer | `unsupported` |

This is a defensible conservative scorer decision. The summary answer indicates federal assistance but does not name the agency requested by the question.

#### C. Human-majority ambiguity

Several remaining cases had split human labels or very small majorities because some reviewers returned partial files.

Example:

| Field | Text |
| --- | --- |
| Reference answer | `He was suspended indefinitely` |
| Model answer | `suspension` |
| Human labels | split between `lost` and `retained` |

These cases should not be treated as strong evidence of scorer failure.

#### D. Genuine answer errors or overly vague answers

Examples:

| Reference answer | Model answer |
| --- | --- |
| `Luckie Food Lounge in Atlanta, Georgia` | `Hawaii` |
| `France and Italy` | `Europe` |

These are factual mismatches or over-generalizations. The scorer is correct to avoid crediting them as retained.

### 9.2 Generalized Follow-Up Calibration

Date: 2026-06-22

A second calibration pass addressed six validation cases that were judged safe to count as retained, while replacing one-off fraction and comparator fixes with a generalized numeric-expression normalizer:

| Review ID | Issue | Calibration |
| --- | --- | --- |
| `HV010` | `The Federal Emergency Management Agency` vs `Federal Emergency Management Agency teams...` | Leading article-insensitive containment |
| `HV023` | `He was suspended indefinitely` vs `suspension` | Conservative `suspend`/`suspended`/`suspension` normalization |
| `HV033` | `By a third` vs `one-third` | General fraction normalization using canonical rational tokens |
| `HV041` | `as a genocide` vs `... as genocide` | Short predicate article normalization |
| `HV046` | `as a genocide` vs longer answer containing `as genocide` | Short predicate article normalization |
| `HV048` | `More than 115` vs `over 115` | General numeric comparator normalization |

The update was implemented in `score_model_selection_batch.py` inside `canonicalize_for_retention()` and supporting helper functions. The numeric normalizer uses Python's standard `fractions.Fraction` representation for exact rational values and a reusable English-number grammar for common numeric expressions. For example:

| Expression A | Expression B | Shared canonical form |
| --- | --- | --- |
| `one-third` | `a third` | `frac1over3` |
| `one fourth` | `a quarter` | `frac1over4` |
| `three quarters` | `3/4` | `frac3over4` |
| `25%` | `one quarter` | `frac1over4` |
| `over 115` | `more than 115` | `more than 115` |
| `over two decades` | `more than 20 years` | `more than 20 years` |

Comparator direction is preserved, so `at least 115` is not normalized as equivalent to `more than 115`.

The update deliberately kept ambiguous cases conservative, including:

| Reference answer | Model answer | Updated scorer |
| --- | --- | --- |
| `The Federal Emergency Management Agency` | `Federal aid` | `unsupported` |
| `Luckie Food Lounge in Atlanta, Georgia` | `Hawaii` | `unsupported` |
| `France and Italy` | `Europe` | `unsupported` |
| `a brutal counter-insurgency campaign` | `systematically planning, committing, and covering up crimes` | `unsupported` |

Validation impact on the 58 comparable item-majority cases:

| Metric | Original scorer | First calibrated scorer | Generalized follow-up scorer |
| --- | ---: | ---: | ---: |
| Item-level agreement with human majority | 33/58 = 0.569 | 37/58 = 0.638 | 42/58 = 0.724 |

Validation impact on the 182 comparable reviewer rows:

| Metric | Original scorer | Generalized follow-up scorer |
| --- | ---: | ---: |
| Row-level agreement with human labels | 106/182 = 0.582 | 128/182 = 0.703 |

Updated item-level agreement by method:

| Method | Agreement |
| --- | ---: |
| `few_shot_cot` | 15/19 = 0.789 |
| `plain` | 16/20 = 0.800 |
| `zero_shot_cot` | 11/19 = 0.579 |

Updated item-level agreement by entity type:

| Entity type | Agreement |
| --- | ---: |
| `DATE_TIME` | 7/7 = 1.000 |
| `EVENT` | 4/9 = 0.444 |
| `LOCATION` | 3/6 = 0.500 |
| `NUMBER` | 5/8 = 0.625 |
| `OBJECT` | 5/6 = 0.833 |
| `ORG` | 6/8 = 0.750 |
| `OTHER` | 5/6 = 0.833 |
| `PERSON` | 7/8 = 0.875 |

Interpretation: the generalized follow-up improved agreement by catching safe surface-form and numeric equivalences without converting vague category answers into named entities. Broad `EVENT` paraphrases remain the major residual weakness and are better treated as candidates for optional semantic adjudication than for looser lexical thresholds.

## 10. Recommended Thesis Interpretation

The human validation supports the QA-based metric as a useful but conservative factual-retention proxy.

Suggested thesis wording:

> Human validation showed that the generated QA items were generally usable: 84.3% of completed question-quality judgments marked the questions as good, and 93.6% marked them as good or partial. However, answer-label agreement showed that the initial lexical scorer overproduced unsupported labels. At the item-majority level, the original automatic labels agreed with human majority judgments on 33 of 58 comparable items (56.9%). The main failure mode was paraphrastic retention: humans often accepted semantically equivalent answers such as "over two decades" for "more than 20 years", while the lexical scorer marked them unsupported due to low token overlap.
>
> A targeted prompt rerun with more canonical answer instructions produced only a small improvement, from 33/58 to 34/58 agreement. This indicated that the main bottleneck was not only answer generation but also lexical scoring. A conservative human-validation-informed scorer calibration was therefore introduced. The calibration normalized safe paraphrases such as decade/year expressions, U.S./United States variants, article-insensitive short predicates, generalized numeric expressions, and limited morphological variants, while deliberately avoiding risky named-entity expansions such as treating "federal aid" as "Federal Emergency Management Agency". This improved item-majority agreement from 33/58 (56.9%) to 42/58 (72.4%) after the generalized follow-up pass.
>
> Remaining disagreements were concentrated in broad event descriptions, vague named-entity substitutions, weak human-majority cases, and genuinely incorrect summary answers. Therefore, the QA metric should be interpreted as a conservative factual-retention indicator rather than a definitive semantic entailment judge, and unsupported labels should be discussed with particular caution.

## 11. Practical Consequence For Later Experiments

For future scoring runs, use the patched `score_model_selection_batch.py`. The scorer now better reflects the human validation without becoming an unrestricted semantic judge.

Recommended reporting convention:

1. Report QA retention/loss/unsupported metrics as automatic proxy metrics.
2. State that human validation found strong question quality but moderate answer-label agreement.
3. Note that conservative calibration improved item-majority agreement from 56.9% to 72.4% after the generalized follow-up pass.
4. Treat `unsupported_or_hallucinated` as a high-precision warning signal, not as an exact hallucination count.
5. Mention that broad `EVENT` facts remain the hardest category for lexical matching.

## 12. Files Created Or Modified During This Procedure

| File | Change |
| --- | --- |
| `human_validation_package/returns/reviewer_*_answers.csv` | Returned reviewer files renamed to stable filenames |
| `human_validation_package/analysis/*` | Human-validation analysis outputs regenerated |
| `human_validation_package/rerun_optimized_answer_prompt.py` | New focused 60-item rerun script for optimized answer prompts |
| `human_validation_package/analysis/optimized_answer_prompt/` | v1 optimized prompt outputs |
| `human_validation_package/analysis/optimized_answer_prompt_v2/` | v2 optimized prompt outputs |
| `score_model_selection_batch.py` | Lexical scorer calibrated using human-validation findings |
| `human_validation_package/analysis/HUMAN_VALIDATION_FINDINGS_AND_SCORER_CALIBRATION.md` | This thesis-facing summary document |
