# Optimized Answer Prompt Validation

- Items rerun: 60
- Comparable human-majority items: 58
- Old model vs human-majority agreement: 33/58 = 0.569
- New model vs human-majority agreement: 34/58 = 0.586
- Delta: +1 item(s)

## New Agreement By Method

| method | matches | total | agreement |
| --- | ---: | ---: | ---: |
| few_shot_cot | 13 | 19 | 0.684 |
| plain | 13 | 20 | 0.650 |
| zero_shot_cot | 8 | 19 | 0.421 |

## New Agreement By Entity

| entity_type | matches | total | agreement |
| --- | ---: | ---: | ---: |
| DATE_TIME | 4 | 7 | 0.571 |
| EVENT | 4 | 9 | 0.444 |
| LOCATION | 1 | 6 | 0.167 |
| NUMBER | 4 | 8 | 0.500 |
| OBJECT | 5 | 6 | 0.833 |
| ORG | 5 | 8 | 0.625 |
| OTHER | 4 | 6 | 0.667 |
| PERSON | 7 | 8 | 0.875 |

## Agreement By Old Model Label

| old_model_label | old_matches | new_matches | total |
| --- | ---: | ---: | ---: |
| lost | 17 | 14 | 20 |
| retained | 16 | 13 | 19 |
| unsupported | 0 | 7 | 19 |

## New Label Distribution

| new_model_label | count |
| --- | ---: |
| lost | 17 |
| retained | 27 |
| unsupported | 14 |

## Label Changes

| old_model_label | new_model_label | count |
| --- | --- | ---: |
| lost | lost | 16 |
| lost | retained | 4 |
| retained | lost | 1 |
| retained | retained | 16 |
| retained | unsupported | 3 |
| unsupported | lost | 1 |
| unsupported | retained | 7 |
| unsupported | unsupported | 12 |
