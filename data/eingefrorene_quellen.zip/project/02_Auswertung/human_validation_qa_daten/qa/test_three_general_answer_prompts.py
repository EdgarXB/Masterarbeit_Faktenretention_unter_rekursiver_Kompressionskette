#!/usr/bin/env python3
"""Test three general QA prompts on the 60-item human-validation sample.

The model receives only the question and summary. Reference answers and human
labels are used after generation for scoring, never in the prompt.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from iterative_summarize import ollama_generate
from score_model_selection_batch import normalize, retained, retention_token_f1, token_f1


ROOT = Path(__file__).resolve().parent
KEY_PATH = ROOT / "internal_model_label_key.csv"
MAJORITY_PATH = ROOT / "analysis" / "majority_by_item.csv"
V2_PATH = ROOT / "analysis" / "optimized_answer_prompt_v2" / "optimized_prompt_answers_vs_human_majority.csv"
OUT_DIR = ROOT / "analysis" / "three_general_prompt_test"
ROWS_PATH = OUT_DIR / "prompt_test_answers.csv"
REPORT_PATH = OUT_DIR / "prompt_test_report.md"

LABELS = {"retained", "lost", "unsupported"}


PROMPTS: dict[str, str] = {
    "a_minimal_evidence_span": (
        "You are a grounded question-answering component in a factual-retention evaluation.\n"
        "Use only the SUMMARY. Never use outside knowledge or infer a missing identity or value.\n\n"
        "Procedure:\n"
        "1. Find the smallest passage in the summary that directly answers the question.\n"
        "2. If such evidence exists, return the shortest answer that preserves the exact meaning "
        "and specificity of that passage. Prefer words copied from the summary.\n"
        "3. A paraphrase is acceptable only when it is unambiguously equivalent. Do not replace a "
        "requested name, place, date, quantity, or event with a broader category.\n"
        "4. If the requested information is absent, only implied, or less specific than the question "
        "requires, return NOT_FOUND.\n"
        "5. If the summary explicitly gives a different or contradictory value, answer with the value "
        "actually stated in the summary.\n\n"
        "Return JSON only with exactly these keys: answer, support, confidence.\n"
        "answer must be one concise phrase or sentence. support must quote the decisive summary text.\n"
        "confidence must be HIGH, MEDIUM, or LOW.\n\n"
        "QUESTION:\n{question}\n\nSUMMARY:\n{summary}"
    ),
    "b_typed_granularity_decision": (
        "You perform strict, summary-grounded QA for factual-retention measurement.\n"
        "The SUMMARY is the only allowed evidence. The reference answer is intentionally unavailable.\n\n"
        "Before producing JSON, silently apply this decision process:\n"
        "- Determine what kind of information the question requests and its required granularity "
        "(for example identity, location, time, quantity, yes/no, action, cause, status, or comparison).\n"
        "- Locate explicit summary evidence that fills that requested slot at the same granularity.\n"
        "- Distinguish three situations:\n"
        "  A. The requested fact is explicitly supported: answer it directly.\n"
        "  B. The summary explicitly supplies a different specific fact: return that stated fact.\n"
        "  C. The requested slot is absent or only vaguely suggested: return NOT_FOUND.\n"
        "- Do not turn related context into an answer. Do not invent a proper name from a generic "
        "description. Do not treat a broader region, approximate category, or associated event as the "
        "specific item requested.\n"
        "- When supported, phrase the answer so that it directly completes the question, while staying "
        "as close as possible to the summary's wording. Preserve negation, comparison direction, units, "
        "scope, and certainty.\n\n"
        "Return valid JSON only: {{\"answer\": ..., \"support\": ..., \"confidence\": ...}}.\n"
        "Use NOT_FOUND exactly when situation C applies. Keep answer concise. Quote only decisive "
        "summary evidence in support. confidence is HIGH, MEDIUM, or LOW.\n\n"
        "QUESTION:\n{question}\n\nSUMMARY:\n{summary}"
    ),
    "c_verify_then_canonicalize": (
        "Answer a factual question from a summary under a strict no-external-knowledge rule.\n\n"
        "Silently perform two passes.\n"
        "PASS 1 — Evidence and entailment:\n"
        "Identify the exact claim requested by the question. Find the strongest explicit evidence in "
        "the SUMMARY. Decide whether that evidence alone would let a careful reader answer the question "
        "without guessing. Mere topical relevance, partial clues, and broader categories are insufficient.\n\n"
        "PASS 2 — Answer verification:\n"
        "Draft a minimal answer and check every content word against the evidence. The answer must match "
        "the requested entity/value type and specificity, preserve qualifiers and polarity, and contain no "
        "unsupported detail. Use an ordinary canonical expression when two wordings are clearly equivalent, "
        "but do not perform uncertain semantic expansion. If verification fails because the requested fact "
        "is missing, output NOT_FOUND. If the evidence clearly states a conflicting alternative, output that "
        "alternative rather than NOT_FOUND.\n\n"
        "Output JSON only with exactly three keys:\n"
        "- answer: one short, direct phrase or sentence, or NOT_FOUND\n"
        "- support: the shortest exact excerpt that justifies the decision\n"
        "- confidence: HIGH, MEDIUM, or LOW\n\n"
        "QUESTION:\n{question}\n\nSUMMARY:\n{summary}"
    ),
}


FIELDS = [
    "prompt_variant",
    "review_id",
    "article_id",
    "method",
    "stage_target_words",
    "entity_type",
    "generated_question",
    "reference_answer",
    "human_majority_label",
    "human_answer_tie",
    "answer",
    "support",
    "confidence",
    "answer_status",
    "original_scorer_label",
    "final_scorer_label",
    "original_matches_human",
    "final_matches_human",
    "final_retention_token_f1",
    "latency_seconds",
    "raw_response",
    "error",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def compact_json_text(text: str) -> str:
    stripped = (text or "").strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", stripped, flags=re.DOTALL | re.IGNORECASE)
    return fence.group(1).strip() if fence else stripped


def parse_answer(text: str) -> tuple[str, str, str, str]:
    raw = compact_json_text(text)
    data: Any = {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        start, end = raw.find("{"), raw.rfind("}")
        if start >= 0 and end > start:
            try:
                data = json.loads(raw[start : end + 1])
            except json.JSONDecodeError:
                data = {}
    if not isinstance(data, dict):
        data = {}
    answer = str(data.get("answer", "")).strip()
    support = str(data.get("support", "")).strip()
    confidence = str(data.get("confidence", "")).strip().upper()
    if not answer or answer.upper() == "NOT_FOUND":
        return "NOT_FOUND", support, confidence if confidence in {"HIGH", "MEDIUM", "LOW"} else "LOW", "not_found"
    if confidence not in {"HIGH", "MEDIUM", "LOW"}:
        confidence = "LOW"
    return answer, support, confidence, "answered"


def original_retained(reference: str, answer: str) -> bool:
    if answer.upper() == "NOT_FOUND":
        return False
    norm_ref = normalize(reference)
    norm_answer = normalize(answer)
    return bool(
        norm_ref
        and (norm_ref in norm_answer or norm_answer in norm_ref)
        or token_f1(reference, answer) >= 0.50
    )


def label(reference: str, answer: str, retention_rule: Callable[[str, str], bool]) -> str:
    if retention_rule(reference, answer):
        return "retained"
    if answer.upper() == "NOT_FOUND":
        return "lost"
    return "unsupported"


def comparable_ids(majority: dict[str, dict[str, str]]) -> list[str]:
    return sorted(
        review_id
        for review_id, row in majority.items()
        if row.get("majority_answer_label") in LABELS
        and row.get("answer_label_tie") == "False"
    )


def score_answers(
    ids: list[str],
    key: dict[str, dict[str, str]],
    majority: dict[str, dict[str, str]],
    answers: dict[str, str],
    retention_rule: Callable[[str, str], bool],
) -> int:
    return sum(
        label(key[review_id]["reference_answer"], answers[review_id], retention_rule)
        == majority[review_id]["majority_answer_label"]
        for review_id in ids
    )


def pct(matches: int, total: int) -> str:
    return f"{matches / total * 100:.1f}%" if total else "n/a"


def baseline_rows(
    ids: list[str],
    key: dict[str, dict[str, str]],
    majority: dict[str, dict[str, str]],
) -> list[tuple[str, str, int]]:
    v2 = {row["review_id"]: row for row in read_csv(V2_PATH)}
    sources = {
        "Original prompt": {review_id: key[review_id]["model_answer"] for review_id in ids},
        "Prompt v2": {review_id: v2[review_id]["new_answer"] for review_id in ids},
    }
    out = []
    for prompt_name, answers in sources.items():
        out.append((prompt_name, "Original scorer", score_answers(ids, key, majority, answers, original_retained)))
        out.append((prompt_name, "Final calibrated scorer", score_answers(ids, key, majority, answers, retained)))
    return out


def build_report(
    rows: list[dict[str, Any]],
    key: dict[str, dict[str, str]],
    majority: dict[str, dict[str, str]],
) -> str:
    ids = comparable_ids(majority)
    by_prompt = defaultdict(list)
    for row in rows:
        by_prompt[row["prompt_variant"]].append(row)

    lines = [
        "# Three General Answer Prompt Test",
        "",
        "The model received only `generated_question` and `summary_text`. Reference answers and human labels were used only after generation for scoring.",
        "",
        f"- Total validation items per prompt: 60",
        f"- Strict comparable set: {len(ids)} items (non-unclear human majority, answer-label ties excluded)",
        "- Model: `glm-4.7-flash:latest`",
        "- Temperature: 0.0",
        "- Seed: 32",
        "",
        "## Score Comparison",
        "",
        "| Prompt | Scorer | Matches | Score |",
        "| --- | --- | ---: | ---: |",
    ]
    for prompt_name, scorer_name, matches in baseline_rows(ids, key, majority):
        lines.append(f"| {prompt_name} | {scorer_name} | {matches}/{len(ids)} | {pct(matches, len(ids))} |")

    for prompt_id in PROMPTS:
        group = {row["review_id"]: row for row in by_prompt[prompt_id]}
        for scorer_field, scorer_name in (
            ("original_scorer_label", "Original scorer"),
            ("final_scorer_label", "Final calibrated scorer"),
        ):
            matches = sum(
                group[review_id][scorer_field] == majority[review_id]["majority_answer_label"]
                for review_id in ids
            )
            lines.append(f"| `{prompt_id}` | {scorer_name} | {matches}/{len(ids)} | {pct(matches, len(ids))} |")

    lines.extend(["", "## Final-Scorer Breakdown", ""])
    for prompt_id in PROMPTS:
        group = [
            row for row in by_prompt[prompt_id]
            if row["review_id"] in ids
        ]
        lines.extend([
            f"### `{prompt_id}`",
            "",
            "| Dimension | Value | Matches | Total | Score |",
            "| --- | --- | ---: | ---: | ---: |",
        ])
        for dimension in ("method", "entity_type", "human_majority_label"):
            grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
            for row in group:
                grouped[str(row[dimension])].append(row)
            for value, subset in sorted(grouped.items()):
                matches = sum(row["final_scorer_label"] == row["human_majority_label"] for row in subset)
                lines.append(f"| {dimension} | {value} | {matches} | {len(subset)} | {pct(matches, len(subset))} |")
        errors = sum(bool(row["error"]) for row in group)
        lines.extend(["", f"Generation errors in comparable set: {errors}.", ""])

    lines.extend(["## Full Prompt Texts", ""])
    for prompt_id, template in PROMPTS.items():
        lines.extend([f"### `{prompt_id}`", "", "```text", template, "```", ""])
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="glm-4.7-flash:latest")
    parser.add_argument("--host", default="127.0.0.1:11435")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=32)
    parser.add_argument("--num-ctx", type=int, default=8192)
    parser.add_argument("--num-predict", type=int, default=256)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--keep-alive", default="30m")
    parser.add_argument("--restart", action="store_true", help="Discard an existing partial output CSV.")
    args = parser.parse_args()

    key_rows = read_csv(KEY_PATH)
    key = {row["review_id"]: row for row in key_rows}
    majority = {row["review_id"]: row for row in read_csv(MAJORITY_PATH)}
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    rows: list[dict[str, Any]] = [] if args.restart or not ROWS_PATH.exists() else read_csv(ROWS_PATH)
    completed = {(row["prompt_variant"], row["review_id"]) for row in rows}
    total = len(PROMPTS) * len(key_rows)
    done = len(completed)

    for prompt_id, template in PROMPTS.items():
        for item in key_rows:
            pair = (prompt_id, item["review_id"])
            if pair in completed:
                continue
            started = time.time()
            error = ""
            raw_response = ""
            try:
                response = ollama_generate(
                    model=args.model,
                    prompt=template.format(
                        question=item["generated_question"],
                        summary=item["summary_text"],
                    ),
                    host=args.host,
                    system_prompt="You are a strict grounded QA JSON API. Output valid JSON only.",
                    temperature=args.temperature,
                    seed=args.seed,
                    num_ctx=args.num_ctx,
                    keep_alive=args.keep_alive,
                    think=False,
                    num_predict=args.num_predict,
                    timeout=args.timeout,
                )
                raw_response = str(response.get("response") or "")
                answer, support, confidence, status = parse_answer(raw_response)
            except Exception as exc:
                answer, support, confidence, status = "NOT_FOUND", "", "LOW", "error"
                error = str(exc)
            reference = item["reference_answer"]
            human = majority[item["review_id"]]["majority_answer_label"]
            old_label = label(reference, answer, original_retained)
            final_label = label(reference, answer, retained)
            rows.append({
                "prompt_variant": prompt_id,
                "review_id": item["review_id"],
                "article_id": item["article_id"],
                "method": item["method"],
                "stage_target_words": item["stage_target_words"],
                "entity_type": item["entity_type"],
                "generated_question": item["generated_question"],
                "reference_answer": reference,
                "human_majority_label": human,
                "human_answer_tie": majority[item["review_id"]]["answer_label_tie"],
                "answer": answer,
                "support": support,
                "confidence": confidence,
                "answer_status": status,
                "original_scorer_label": old_label,
                "final_scorer_label": final_label,
                "original_matches_human": str(old_label == human),
                "final_matches_human": str(final_label == human),
                "final_retention_token_f1": f"{retention_token_f1(reference, answer):.6f}",
                "latency_seconds": f"{time.time() - started:.3f}",
                "raw_response": raw_response,
                "error": error,
            })
            done += 1
            write_csv(ROWS_PATH, rows)
            print(f"[{done}/{total}] {prompt_id} {item['review_id']} -> {answer} ({final_label})", flush=True)

    REPORT_PATH.write_text(build_report(rows, key, majority), encoding="utf-8")
    print(f"Wrote {ROWS_PATH}", flush=True)
    print(f"Wrote {REPORT_PATH}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
