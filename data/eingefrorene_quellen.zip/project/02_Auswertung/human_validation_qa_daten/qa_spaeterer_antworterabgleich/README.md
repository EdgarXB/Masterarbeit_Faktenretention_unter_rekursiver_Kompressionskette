# Controlled historical QA-answerer benchmark

Status: analysis protocol frozen before the Qwen benchmark outputs were generated  
Date: 2026-09-01

## Purpose

This benchmark reruns Qwen3.8 on the exact historical test bed on which
`glm-4.7-flash:latest` was evaluated in May 2026. It provides a matched, same-input comparison for
the later decision to replace GLM as QA answerer in the six-method engineering pilot.

The comparison is **post-hoc controlled validation**, not a prospectively preregistered model
selection experiment. Qwen had already been selected after GLM failed an explicit 20-question
positive control. This benchmark may corroborate or challenge that decision, but must not be
described as if its analysis had preceded the diagnostic selection event.

## Frozen inputs and execution

- Historical run: `experiments/prompt_comparison/20260516T134205Z_qwen30_10_article_kpi_test/`
- Articles: 10
- Summary methods: Plain, Zero-shot CoT, historical Few-shot CoT
- Recursive stages: 500, 300, 150, 75 words
- Canonical questions: 20 per article
- Units per answerer: 10 × 3 × 4 × 20 = 2,400
- Historical GLM outputs are reused without modification.
- Qwen receives the same summaries, questions, order, system prompt, temperature 0, seed 32,
  `num_ctx=8192`, `num_predict=512`, `think=false`, and the archived historical answer script.
- The archived prompt requests JSON but does not enforce the later exact-support schema. This is
  intentional: changing the historical prompt would confound answerer with protocol.

## Frozen analysis

The current human-calibrated scorer is applied symmetrically to both answer files. Report:

1. retention rate (primary descriptive outcome);
2. `NOT_FOUND`/loss rate;
3. neutral reference-discordant-answer rate;
4. calibrated token F1;
5. answers per minute from summed per-unit latency (descriptive only, because runs occurred at
   different dates);
6. false-negative rate among units whose canonical reference answer occurs literally in the
   evaluated summary;
7. exact-support rate as a diagnostic, not as a fair historical pass/fail criterion because the
   old prompt did not require exact contiguous support.

All outcomes are shown overall, by stage, and by summary method. Differences use Qwen minus GLM.
Uncertainty uses 10,000 paired bootstrap resamples of the 10 article-level means with seed 32.
Facts, stages, and methods are not treated as independent observations. Results remain pilot-scale
because there are only 10 independent articles.

The analysis script was written before inspecting the new 2,400-row Qwen output.

## Human-validation subset amendment

Added while Qwen generation was running, before inspecting any Qwen answer content: all 60 prior
human-validation QA units are exact members of this benchmark (same article, method, stage,
canonical fact ID, question, and reference). They represent 25 unique canonical questions from six
articles. The analysis therefore also compares GLM and Qwen labels directly with the existing human
majority label on every non-tied item, using the same calibrated scorer for both answerers. Agreement
differences receive a paired article-level bootstrap over the six represented articles and are
reported as exploratory because this subset is small and was originally sampled for scorer, not
answerer, validation.

## Completed result

The Qwen run completed all 2,400 matched units with zero technical errors. Under the same current
human-calibrated scorer applied symmetrically to both answer files, Qwen achieved 0.471 retention
versus 0.400 for GLM. The paired article-bootstrap difference was +0.071 (95% CI
[0.055, 0.087]). Qwen also reduced `NOT_FOUND` from 0.500 to 0.432 and the false-negative rate
among literal-reference-present units from 0.169 to 0.090.

The exploratory human-validation subset does not show a Qwen advantage: after excluding six tied
human-majority items, GLM agreed on 41/54 (0.759) and Qwen on 39/54 (0.722). The paired
article-bootstrap difference for agreement was -0.035 (95% CI [-0.093, 0.044]). Thus the full
historical benchmark supports Qwen as the less over-abstaining automatic answerer, while the small
human subset is compatible with no clear agreement difference and must be reported alongside it.
Detailed outputs and content hashes are in `report/`.
