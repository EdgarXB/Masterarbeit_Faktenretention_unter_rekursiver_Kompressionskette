# Qwen3.8 versus GLM on the historical QA benchmark

This is a post-hoc controlled validation on 10 independent articles and 2,400 exactly matched QA units per answerer.
It must not be described as a prospective preregistered selection experiment.

## Overall results

| Answerer | Retention | NOT_FOUND | Reference-discordant | Token F1 | Literal-present false negatives | Answers/min | Errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| GLM | 0.400 | 0.500 | 0.100 | 0.366 | 0.169 | 108.9 | 0 |
| QWEN | 0.471 | 0.432 | 0.096 | 0.429 | 0.090 | 60.9 | 0 |

## Paired article-bootstrap differences

Positive values favor Qwen for retention/F1; negative values favor Qwen for loss and false negatives.

| Metric | Qwen − GLM | 95% article-bootstrap CI |
|---|---:|---:|
| retention | 0.071 | [0.055, 0.087] |
| loss | -0.067 | [-0.093, -0.040] |
| reference_discordant | -0.004 | [-0.027, 0.018] |
| token_f1 | 0.063 | [0.051, 0.075] |
| literal_false_negative | -0.087 | [-0.133, -0.042] |

## Agreement with prior human validation

All 60 human-validation units are exact benchmark members; tied human-majority items are excluded from agreement.

| Answerer | Agreements | Comparable items | Agreement |
|---|---:|---:|---:|
| GLM | 41 | 54 | 0.759 |
| QWEN | 39 | 54 | 0.722 |

Paired article-bootstrap agreement difference (Qwen − GLM): -0.035 [95% CI -0.093, 0.044].

## Interpretation limits

- The independent sample size is 10 articles; the 2,400 QA units are repeated observations, not 2,400 independent samples.
- Runtime is descriptive because the answerers were run at different dates.
- Historical support text was not required to be an exact quote, so exact-support rate is diagnostic only.
- The benchmark supports an answerer-role choice; it does not establish any summarization-method effect.
