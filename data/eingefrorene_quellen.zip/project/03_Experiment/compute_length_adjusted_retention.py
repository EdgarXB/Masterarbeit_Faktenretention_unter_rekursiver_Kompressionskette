#!/usr/bin/env python3
"""Compute the frozen secondary length-adjusted QA-retention metric."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


FORMULA = "retention_all_missing_zero / (1 + word_window_violation_rate)"


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, records: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def interval(values: np.ndarray, samples: int, rng: np.random.Generator) -> tuple[float, float]:
    draws = rng.choice(values, size=(samples, len(values)), replace=True).mean(axis=1)
    low, high = np.quantile(draws, [0.025, 0.975])
    return float(low), float(high)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--qa-article", type=Path, required=True)
    parser.add_argument("--length-detailed", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=32)
    args = parser.parse_args()

    qa = rows(args.qa_article)
    length = rows(args.length_detailed)
    length_by_key = {
        (row["article_id"], row["method"], row["stage_target_words"]): row for row in length
    }
    detail: list[dict[str, object]] = []
    for row in qa:
        key = (row["article_id"], row["method"], row["stage_target_words"])
        if key not in length_by_key:
            raise RuntimeError(f"missing length unit: {key}")
        length_row = length_by_key[key]
        retention = float(row["retention_all_missing_zero"])
        violation = float(length_row["word_window_violation_rate"])
        detail.append({
            "article_id": row["article_id"],
            "dataset_index": length_row["dataset_index"],
            "method": row["method"],
            "stage_target_words": int(row["stage_target_words"]),
            "retention_all_missing_zero": retention,
            "word_window_violation_rate": violation,
            "word_window_success": length_row["word_window_success"],
            "length_adjusted_retention": retention / (1.0 + violation),
        })
    if len(detail) != len(qa) or len(detail) != len(length):
        raise RuntimeError(f"join cardinality mismatch: qa={len(qa)} length={len(length)} joined={len(detail)}")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_dir / "length_adjusted_retention_detailed.csv", detail)
    rng = np.random.default_rng(args.seed)
    grouped: dict[tuple[str, int], list[float]] = defaultdict(list)
    by_article_method: dict[tuple[str, str], list[float]] = defaultdict(list)
    for row in detail:
        grouped[(str(row["method"]), int(row["stage_target_words"]))].append(float(row["length_adjusted_retention"]))
        by_article_method[(str(row["article_id"]), str(row["method"]))].append(float(row["length_adjusted_retention"]))
    stage_records = []
    for (method, stage), values_list in sorted(grouped.items()):
        values = np.asarray(values_list, dtype=float)
        low, high = interval(values, args.bootstrap_samples, rng)
        stage_records.append({"method": method, "stage_target_words": stage, "n_articles": len(values), "mean_length_adjusted_retention": float(values.mean()), "ci95_low": low, "ci95_high": high})
    write_csv(args.output_dir / "length_adjusted_retention_by_method_stage.csv", stage_records)

    overall_groups: dict[str, list[float]] = defaultdict(list)
    for (_, method), values in by_article_method.items():
        overall_groups[method].append(float(np.mean(values)))
    overall_records = []
    for method, values_list in sorted(overall_groups.items()):
        values = np.asarray(values_list, dtype=float)
        low, high = interval(values, args.bootstrap_samples, rng)
        overall_records.append({"method": method, "n_articles": len(values), "mean_length_adjusted_retention": float(values.mean()), "ci95_low": low, "ci95_high": high})
    write_csv(args.output_dir / "length_adjusted_retention_by_method.csv", overall_records)
    (args.output_dir / "length_adjusted_retention_manifest.json").write_text(
        json.dumps({"formula": FORMULA, "role": "secondary descriptive metric", "bootstrap_unit": "article", "bootstrap_samples": args.bootstrap_samples, "seed": args.seed, "detailed_units": len(detail)}, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"PASS: computed frozen length-adjusted retention for {len(detail)} article-method-stage units")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
