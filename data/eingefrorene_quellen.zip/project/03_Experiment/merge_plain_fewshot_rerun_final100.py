#!/usr/bin/env python3
"""Replace historical Plain/Few-Shot rows with the new rerun outputs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from run_plain_fewshot_rerun_final100 import INPUT, METHODS, OUT, PROJECT, TARGETS, sha_bytes


ROOT = Path(__file__).resolve().parent
OLD = ROOT / "experiments/six_method_final_100/run/recursive_results.csv"
NEW = PROJECT / "recursive_results.csv"
RERUN_ONLY = PROJECT / "rerun_only.csv"


def read(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def write(path: Path, fields: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    fields, old_rows = read(OLD)
    _, sources = read(INPUT)
    if len(old_rows) != 600 or len(sources) != 100:
        raise RuntimeError("unexpected base/source cardinality")
    retained = [row for row in old_rows if row["method"] not in METHODS]
    if len(retained) != 400:
        raise RuntimeError("expected 400 retained historical rows")
    results: list[dict[str, str]] = []
    for method in METHODS:
        for source in sources:
            artifact_path = OUT / "articles" / method / f"test__{source['dataset_index']}.json"
            artifact = json.loads(artifact_path.read_text(encoding="utf-8"))
            if not artifact["complete"] or artifact["source_sha256"] != source["article_sha256"]:
                raise RuntimeError(f"incomplete or mismatched artifact: {artifact_path}")
            stages = artifact["stages"]
            if [stage["target_words"] for stage in stages] != list(TARGETS):
                raise RuntimeError(f"invalid stage sequence: {artifact_path}")
            row = {field: "" for field in fields}
            for name in ("article_id", "dataset", "config", "split", "dataset_index",
                         "article_sha256", "article", "highlights"):
                row[name] = source[name]
            row.update({
                "method": method, "model_name": "thesis-seed:v1",
                "prompt_variant": method, "collection_phase": "plain_fewshot_rerun_20260930",
                "original_word_count": str(stages[0]["input_word_count"]),
            })
            for stage in stages:
                target = stage["target_words"]
                selected = stage["selected"]
                row[f"summary_{target}"] = selected["response"]
                row[f"summary_{target}_word_count"] = str(selected["response_word_count"])
                row[f"summary_{target}_initial_word_count"] = str(selected["response_word_count"])
                row[f"summary_{target}_initial_window_success"] = str(selected["word_window_success"])
                row[f"summary_{target}_final_window_success"] = str(selected["word_window_success"])
                row[f"summary_{target}_complete_sentence_success"] = str(selected["ends_with_complete_sentence"])
                row[f"summary_{target}_attempts"] = "1"
            results.append(row)
    if len(results) != 200 or len({(row["dataset_index"], row["method"]) for row in results}) != 200:
        raise RuntimeError("new rerun cardinality mismatch")
    combined = retained + results
    if len(combined) != 600 or len({(row["dataset_index"], row["method"]) for row in combined}) != 600:
        raise RuntimeError("merged cardinality mismatch")
    write(RERUN_ONLY, fields, results)
    write(NEW, fields, combined)
    manifest = {
        "base_results_sha256": sha_bytes(OLD.read_bytes()),
        "new_collection_manifest_sha256": sha_bytes((OUT / "collection_manifest.json").read_bytes()),
        "rerun_only_sha256": sha_bytes(RERUN_ONLY.read_bytes()),
        "merged_results_sha256": sha_bytes(NEW.read_bytes()),
        "retained_historical_rows": 400,
        "replaced_plain_rows": 100,
        "replaced_few_shot_rows": 100,
        "historical_plain_or_few_shot_rows_in_new_table": 0,
    }
    (PROJECT / "result_merge_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print("PASS: 400 retained historical + 100 new Plain + 100 new Few-Shot rows")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
