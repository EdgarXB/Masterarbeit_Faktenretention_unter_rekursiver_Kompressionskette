#!/usr/bin/env python3
"""Merge 16,000 new Plain/Few-Shot QA rows with unaffected historical QA."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "experiments/six_method_final_100"
PROJECT = ROOT / "experiments/plain_fewshot_rerun_20260930"
METHODS = {"plain", "few_shot_cot"}


def read(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def write(path: Path, fields: list[str], rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    fields, old = read(BASE / "qa/summary_question_answers.csv")
    new_fields, replacement = read(PROJECT / "qa_new/summary_question_answers.csv")
    if fields != new_fields:
        raise RuntimeError("QA schema mismatch")
    retained = [row for row in old if row["summary_prompt_variant"] not in METHODS]
    if len(old) != 48000 or len(retained) != 32000:
        raise RuntimeError(f"unexpected historical QA cardinality: old={len(old)} retained={len(retained)}")
    replacement_by_key = {}
    key = lambda row: (row["answer_model_name"], row["summary_prompt_variant"],
                       row["article_id"], row["stage_target_words"], row["canonical_fact_id"])
    for row in replacement:
        if row["summary_prompt_variant"] not in METHODS:
            raise RuntimeError("unexpected method in replacement QA")
        replacement_by_key[key(row)] = row
    replacement = list(replacement_by_key.values())
    if len(replacement) != 16000:
        raise RuntimeError(f"expected 16000 unique replacement QA rows, got {len(replacement)}")
    combined = retained + replacement
    if len(combined) != 48000 or len({key(row) for row in combined}) != 48000:
        raise RuntimeError("merged QA cardinality mismatch")
    output = PROJECT / "qa/summary_question_answers.csv"
    write(output, fields, combined)
    manifest = {
        "base_qa_sha256": sha(BASE / "qa/summary_question_answers.csv"),
        "new_qa_sha256": sha(PROJECT / "qa_new/summary_question_answers.csv"),
        "merged_qa_sha256": sha(output),
        "retained_historical_units": 32000,
        "new_plain_units": sum(row["summary_prompt_variant"] == "plain" for row in replacement),
        "new_few_shot_units": sum(row["summary_prompt_variant"] == "few_shot_cot" for row in replacement),
    }
    (PROJECT / "qa/merge_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print("PASS: 32,000 retained historical + 16,000 new Plain/Few-Shot QA units")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
