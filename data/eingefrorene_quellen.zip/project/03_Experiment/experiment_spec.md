# Experiment Specification  
## Faktenretention unter progressiver Kompression

---

## 1. Ziel des Experiments

Ziel dieses Experiments ist die Untersuchung der **Faktenretention und Halluzinationsentwicklung** bei rekursiver Textkompression durch Large Language Models (LLMs).

Dabei wird analysiert:

- Wie sich faktische Information über mehrere Kompressionsstufen verändert  
- Ob ein systematischer Übergang von Faktenverlust zu Halluzination existiert  
- Wie verschiedene Chain-of-Thought (CoT) Prompting-Strategien diesen Prozess beeinflussen  

---

## 2. Experimentelles Design

### 2.1 Überblick

- Datensatz: CNN/DailyMail
- Stichprobe: 100 Artikel mit exakt ~800 Wörtern
- Rekursive Kompression:
  - 800 → 500 → 300 → 150 → 75 Wörter
- Feste Rekursionstiefe: 4 Stufen
- Jede Stufe basiert auf der vorherigen Zusammenfassung

---

### 2.2 Behandlungen (Methoden)

Folgende 6 Methoden werden im finalen Experiment verglichen:

1. Lead-k (extraktive Baseline)
2. Plain LLM Summarization (abstraktive Baseline)
3. Zero-Shot CoT
4. Few-Shot CoT
5. Auto-CoT
6. Automatic CoT

Wichtige Abgrenzung:

- Auto-CoT und Automatic CoT sind zwei getrennte Methoden.
- Auto-CoT nutzt automatisch erzeugte CoT-Demonstrationen oder Beispiele.
- Automatic CoT erzeugt fuer den aktuellen Eingabetext einen reasoning trace und nutzt diesen fuer die Zusammenfassung.
- Neben Zero-Shot und Few-Shot CoT werden nur Auto-CoT und Automatic CoT als weitere CoT-Methoden untersucht.

---

### 2.3 Kontrollvariablen

- Gleiches eingefrorenes Summarizer-Modell `thesis-seed:v1` fuer alle abstraktiven Methoden
- Eingefrorene modell- und rollenspezifische Samplingparameter gemaess `experiments/model_freeze/20260820T224700Z/model_freeze.json`
- Fixer Haupt-Seed `32`
- Identischer Basis-Prompt (abgesehen von CoT-Variation)
- Gleiche Rekursionstiefe
- Identische Artikel pro Methode

---

### 2.4 Wortlängensteuerung

- Zielwortanzahl mit Toleranz: ±5%

---

## 3. Datenaufbereitung

### 3.1 Artikel-Selektion

- Auswahl von Artikeln mit ~800 Wörtern
- Sprache: Englisch

---

### 3.2 Extraktion atomarer Fakten

- Fakten
- Fragen
- Referenzantworten
- Entitätstypen
- Finaler Standard: `thesis-gemma:v1` erzeugt und rankt Fakten/Fragen.
- `thesis-glm:v1` beantwortet die kanonischen Fragen aus den Zusammenfassungen.
- Die Rollen sind durch `experiments/model_freeze/20260820T224700Z/model_freeze.json` festgelegt; weitere Modelle werden nicht in die finale Pipeline aufgenommen.

---

## 4. Rekursive Pipeline

800 → 500 → 300 → 150 → 75

---

## 5. Evaluation

- Forward-QA → Retention
- Intrinsische Halluzination
- Extrinsische Halluzination
- Abgeschlossener Human-Test der Fragegenerierung, Fragebeantwortung und Retention/Loss/Unsupported-Labels
- Abgeschlossener Human-Test der Salienz und Rangfolge atomarer Fakten

Beide Human-Validation-Experimente wurden bereits durchgefuehrt. Die erste Studie validierte 60 QA-Items und fuehrte zur Kalibrierung des Scorers. Die zweite Studie validierte die Salienz und Rangfolge der Faktenauswahl; die derzeit dokumentierte Auswertung umfasst vier Reviewer und 168 formale Konsensfakten.

---

## 6. Metriken

- ROUGE-1/2/L F1 als lexikalische Inhaltsueberlappung
- BERTScore F1 als semantische Aehnlichkeit bei Paraphrasen
- QA-basierte Fact-Retention, Loss Rate und Unsupported/Hallucination Rate
- SummaC als externe NLI-basierte Konsistenzpruefung zwischen Quelle und Zusammenfassung
- Entity Retention Rate nach Entitaetstyp
- Length/Window Success Rate fuer die Wortlaengensteuerung
- Compression Rate als tatsaechliches Kompressionsverhaeltnis je Stufe

---

## 7. Reproduzierbarkeit

- Versionierte lokale Modellaliase mit verifizierten Digests
- Fixer Haupt-Seed `32` und vollstaendige Request-Parameter in jedem Run-Manifest
- Gepaarte Auswertung auf identischen Artikeln; stochastische Generierung wird nicht faelschlich als vollstaendig deterministisch bezeichnet

---

## 8. Zeitplanung

- Finale Abgabe: 4. November 2026
- Stand 18. Mai 2026: etwa 5,5 Monate verbleibend
- Naechste Prioritaet: die validierte Evaluationspipeline in einem groesseren Frozen-Pilot anwenden und Auto-CoT sowie Automatic CoT implementieren.
