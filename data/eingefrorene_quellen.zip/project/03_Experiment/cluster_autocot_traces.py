#!/usr/bin/env python3
import argparse
import csv
import json
import math
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score


def count_words(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text or ""))


def short(text: str, max_chars: int = 220) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3] + "..."


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Embed Qwen Auto-CoT traces with S-BERT, run KMeans, and plot clusters."
    )
    parser.add_argument("--traces", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2")
    parser.add_argument("--clusters", type=int, default=4)
    parser.add_argument(
        "--embed-field",
        choices=["thinking", "response", "input", "thinking_response", "task_thinking_response"],
        default="task_thinking_response",
        help="Trace text used for S-BERT embeddings.",
    )
    parser.add_argument("--random-state", type=int, default=32)
    return parser.parse_args()


def load_traces(path: Path) -> list[dict]:
    rows = []
    with path.open(encoding="utf-8") as f:
        for idx, line in enumerate(f, start=1):
            if not line.strip():
                continue
            row = json.loads(line)
            row["_trace_index"] = idx
            rows.append(row)
    return rows


def embedding_text(row: dict, mode: str) -> str:
    target = row.get("target_words") or row.get("stage_target_words") or ""
    article_id = row.get("article_id", "")
    prompt_input = row.get("prompt_input") or ""
    thinking = row.get("thinking") or ""
    response = row.get("response") or ""
    if mode == "thinking":
        return thinking
    if mode == "response":
        return response
    if mode == "input":
        return f"target={target}\narticle_id={article_id}\ninput={prompt_input}"
    if mode == "thinking_response":
        return f"thinking={thinking}\nsummary={response}"
    return (
        f"compression_target={target}\n"
        f"article_id={article_id}\n"
        f"input={short(prompt_input, 1200)}\n"
        f"thinking={thinking}\n"
        f"summary={response}"
    )


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    traces_path = Path(args.traces)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    traces = load_traces(traces_path)
    if not traces:
        raise SystemExit(f"No traces found in {traces_path}")
    if args.clusters < 2 or args.clusters > len(traces):
        raise SystemExit("--clusters must be between 2 and number of traces")

    texts = [embedding_text(row, args.embed_field) for row in traces]
    model = SentenceTransformer(args.model)
    embeddings = model.encode(
        texts,
        batch_size=16,
        show_progress_bar=True,
        normalize_embeddings=True,
    )
    embeddings = np.asarray(embeddings, dtype=np.float32)

    kmeans = KMeans(
        n_clusters=args.clusters,
        random_state=args.random_state,
        n_init=20,
    )
    labels = kmeans.fit_predict(embeddings)
    distances = kmeans.transform(embeddings)
    nearest_dist = distances[np.arange(len(traces)), labels]

    selected_indices = {}
    for cluster_id in range(args.clusters):
        cluster_indices = np.where(labels == cluster_id)[0]
        nearest = min(cluster_indices, key=lambda i: distances[i, cluster_id])
        selected_indices[cluster_id] = int(nearest)

    pca = PCA(n_components=2, random_state=args.random_state)
    points = pca.fit_transform(embeddings)
    centers_2d = pca.transform(kmeans.cluster_centers_)
    silhouette = silhouette_score(embeddings, labels, metric="euclidean")

    detail_rows = []
    for i, row in enumerate(traces):
        cluster_id = int(labels[i])
        detail_rows.append(
            {
                "trace_index": row.get("_trace_index"),
                "cluster": cluster_id,
                "is_centroid_trace": "yes" if selected_indices[cluster_id] == i else "",
                "distance_to_cluster_center": f"{nearest_dist[i]:.6f}",
                "pca_x": f"{points[i, 0]:.6f}",
                "pca_y": f"{points[i, 1]:.6f}",
                "article_id": row.get("article_id", ""),
                "dataset_index": row.get("dataset_index", ""),
                "stage_target_words": row.get("stage_target_words", ""),
                "attempt_index": row.get("attempt_index", ""),
                "phase": row.get("phase", ""),
                "thinking_word_count": count_words(row.get("thinking", "")),
                "response_word_count": count_words(row.get("response", "")),
                "thinking_excerpt": short(row.get("thinking", "")),
                "response_excerpt": short(row.get("response", "")),
            }
        )

    detail_csv = output_dir / "sbert_kmeans_trace_clusters.csv"
    write_csv(
        detail_csv,
        detail_rows,
        [
            "trace_index",
            "cluster",
            "is_centroid_trace",
            "distance_to_cluster_center",
            "pca_x",
            "pca_y",
            "article_id",
            "dataset_index",
            "stage_target_words",
            "attempt_index",
            "phase",
            "thinking_word_count",
            "response_word_count",
            "thinking_excerpt",
            "response_excerpt",
        ],
    )

    summary_rows = []
    for cluster_id in range(args.clusters):
        idxs = [i for i, label in enumerate(labels) if label == cluster_id]
        selected = selected_indices[cluster_id]
        stage_counts = {}
        for i in idxs:
            stage = str(traces[i].get("stage_target_words", ""))
            stage_counts[stage] = stage_counts.get(stage, 0) + 1
        summary_rows.append(
            {
                "cluster": cluster_id,
                "num_traces": len(idxs),
                "stage_counts": "; ".join(f"{k}:{v}" for k, v in sorted(stage_counts.items())),
                "centroid_trace_index": traces[selected].get("_trace_index"),
                "centroid_article_id": traces[selected].get("article_id", ""),
                "centroid_dataset_index": traces[selected].get("dataset_index", ""),
                "centroid_stage_target_words": traces[selected].get("stage_target_words", ""),
                "centroid_distance": f"{distances[selected, cluster_id]:.6f}",
                "centroid_response_words": count_words(traces[selected].get("response", "")),
                "centroid_thinking_words": count_words(traces[selected].get("thinking", "")),
                "centroid_response_excerpt": short(traces[selected].get("response", ""), 260),
            }
        )

    summary_csv = output_dir / "sbert_kmeans_cluster_summary.csv"
    write_csv(
        summary_csv,
        summary_rows,
        [
            "cluster",
            "num_traces",
            "stage_counts",
            "centroid_trace_index",
            "centroid_article_id",
            "centroid_dataset_index",
            "centroid_stage_target_words",
            "centroid_distance",
            "centroid_response_words",
            "centroid_thinking_words",
            "centroid_response_excerpt",
        ],
    )

    stages = sorted({str(row.get("stage_target_words", "")) for row in traces})
    markers = ["o", "s", "^", "D", "P", "X"]
    marker_for_stage = {stage: markers[i % len(markers)] for i, stage in enumerate(stages)}

    plt.figure(figsize=(12, 8))
    cmap = plt.get_cmap("tab10")
    for stage in stages:
        idxs = [i for i, row in enumerate(traces) if str(row.get("stage_target_words", "")) == stage]
        plt.scatter(
            points[idxs, 0],
            points[idxs, 1],
            c=[cmap(labels[i] % 10) for i in idxs],
            marker=marker_for_stage[stage],
            s=70,
            alpha=0.78,
            edgecolors="white",
            linewidths=0.6,
            label=f"stage {stage}",
        )

    for cluster_id, selected in selected_indices.items():
        plt.scatter(
            points[selected, 0],
            points[selected, 1],
            marker="*",
            s=380,
            c=[cmap(cluster_id % 10)],
            edgecolors="black",
            linewidths=1.2,
        )
        plt.annotate(
            f"C{cluster_id}\nA{traces[selected].get('article_id')}:{traces[selected].get('stage_target_words')}",
            (points[selected, 0], points[selected, 1]),
            xytext=(8, 8),
            textcoords="offset points",
            fontsize=9,
            weight="bold",
        )

    plt.scatter(
        centers_2d[:, 0],
        centers_2d[:, 1],
        marker="x",
        s=180,
        c="black",
        linewidths=2,
        label="KMeans centers",
    )
    plt.title(
        f"S-BERT + KMeans on Qwen3:30B CoT traces "
        f"(k={args.clusters}, silhouette={silhouette:.3f})"
    )
    plt.xlabel(f"PCA 1 ({pca.explained_variance_ratio_[0] * 100:.1f}% var.)")
    plt.ylabel(f"PCA 2 ({pca.explained_variance_ratio_[1] * 100:.1f}% var.)")
    plt.grid(alpha=0.2)
    stage_handles = [
        Line2D(
            [0],
            [0],
            marker=marker_for_stage[stage],
            color="black",
            markerfacecolor="lightgray",
            linestyle="",
            markersize=9,
            label=f"stage {stage}",
        )
        for stage in stages
    ]
    cluster_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="none",
            markerfacecolor=cmap(cluster_id % 10),
            markeredgecolor="white",
            linestyle="",
            markersize=9,
            label=f"cluster {cluster_id}",
        )
        for cluster_id in range(args.clusters)
    ]
    center_handle = Line2D(
        [0],
        [0],
        marker="*",
        color="black",
        markerfacecolor="white",
        linestyle="",
        markersize=13,
        label="selected centroid trace",
    )
    first_legend = plt.legend(
        handles=cluster_handles + [center_handle],
        title="Color = cluster",
        loc="upper right",
        fontsize=9,
    )
    plt.gca().add_artist(first_legend)
    plt.legend(handles=stage_handles, title="Marker = stage", loc="upper left", fontsize=9)
    plt.tight_layout()
    plot_path = output_dir / "sbert_kmeans_trace_clusters.png"
    plt.savefig(plot_path, dpi=180)

    report = output_dir / "sbert_kmeans_report.md"
    report.write_text(
        "\n".join(
            [
                "# S-BERT KMeans Trace Clustering",
                "",
                f"Trace input: `{traces_path}`",
                f"Embedding model: `{args.model}`",
                f"Embedding field: `{args.embed_field}`",
                f"Number of traces: `{len(traces)}`",
                f"KMeans clusters: `{args.clusters}`",
                f"Random state: `{args.random_state}`",
                f"Silhouette score: `{silhouette:.4f}`",
                f"PCA explained variance: `{pca.explained_variance_ratio_[0]:.4f}`, `{pca.explained_variance_ratio_[1]:.4f}`",
                "",
                "## Outputs",
                "",
                f"- Detail CSV: `{detail_csv.name}`",
                f"- Cluster summary CSV: `{summary_csv.name}`",
                f"- Visualization: `{plot_path.name}`",
                "",
                "## Centroid Trace Candidates",
                "",
                "```csv",
                ",".join(summary_rows[0].keys()) if summary_rows else "",
                *[
                    ",".join(str(row.get(k, "")).replace("\n", " ").replace(",", ";") for k in summary_rows[0].keys())
                    for row in summary_rows
                ],
                "```",
                "",
            ]
        ),
        encoding="utf-8",
    )

    print(f"Wrote {detail_csv}")
    print(f"Wrote {summary_csv}")
    print(f"Wrote {plot_path}")
    print(f"Wrote {report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
