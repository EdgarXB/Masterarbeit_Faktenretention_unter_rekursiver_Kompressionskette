#!/usr/bin/env python3
"""Export the frozen stage-specific Auto-CoT and Automate-CoT user prompts."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from iterative_summarize import count_words
from select_automatecot_demonstrations import build_fewshot_prompt


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "experiments/autocot_automatecot_100"
OUTPUT = PROJECT / "final_prompts"
TARGETS = (500, 300, 150, 75)
NEW_INPUT_PLACEHOLDER = "{{NEW_INPUT}}"
DEMO_FILES = {
    "auto_cot": PROJECT / "auto_cot_selection/auto_cot_demonstrations.json",
    "automate_cot": PROJECT / "automate_cot_selection/automate_cot_demonstrations.json",
}


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def now_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, object] = {
        "created_at_utc": now_utc(),
        "status": "final demonstration-only prompt export",
        "new_input_placeholder": NEW_INPUT_PLACEHOLDER,
        "prompt_layer": (
            "model-agnostic user/content prompt before the thesis-seed-specific seed_raw wrapper"
        ),
        "methods": {},
    }
    method_manifest: dict[str, object] = {}
    for method, demo_path in DEMO_FILES.items():
        bank = json.loads(demo_path.read_text(encoding="utf-8"))
        assert set(bank) == {str(target) for target in TARGETS}
        stages: dict[str, object] = {}
        for target in TARGETS:
            demos = bank[str(target)]
            assert len(demos) == 5
            assert len({row["candidate_id"] for row in demos}) == 5
            prompt = build_fewshot_prompt(NEW_INPUT_PLACEHOLDER, target, demos)
            assert prompt.count("DEMONSTRATION ") == 5
            assert prompt.count(NEW_INPUT_PLACEHOLDER) == 1
            output_path = OUTPUT / f"{method}_{target}.txt"
            encoded = (prompt + "\n").encode("utf-8")
            output_path.write_bytes(encoded)
            stages[str(target)] = {
                "path": str(output_path.relative_to(PROJECT)),
                "sha256": sha256_bytes(encoded),
                "prompt_word_count_without_new_input": count_words(prompt),
                "ordered_demonstration_ids": [row["candidate_id"] for row in demos],
                "demonstration_count": len(demos),
            }
        method_manifest[method] = {
            "source_demonstration_bank": str(demo_path.relative_to(PROJECT)),
            "source_demonstration_bank_sha256": sha256_bytes(demo_path.read_bytes()),
            "stages": stages,
        }
    manifest["methods"] = method_manifest
    manifest_path = OUTPUT / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"Exported {len(DEMO_FILES) * len(TARGETS)} prompts to {OUTPUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
