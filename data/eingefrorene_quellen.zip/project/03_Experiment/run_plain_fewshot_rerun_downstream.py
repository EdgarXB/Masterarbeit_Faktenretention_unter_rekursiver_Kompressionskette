#!/usr/bin/env python3
"""Complete metrics and QA analysis for the new Plain/Few-Shot final-100 rerun."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PYTHON = ROOT / ".venv-metrics/bin/python"
BASE = ROOT / "experiments/six_method_final_100"
PROJECT = ROOT / "experiments/plain_fewshot_rerun_20260930"
DATA = ROOT / "experiments/autocot_automatecot_100/data/final_test_100.csv"
BERTSCORE = "/home/edgar/.cache/huggingface/hub/models--distilroberta-base/snapshots/fb53ab8802853c8e4fbdbcd0529f21fc6f459b2b"
HOST = "127.0.0.1:11435"


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    print("RUN", args[0], flush=True)
    return subprocess.run([str(PYTHON), *args], cwd=ROOT, check=check, text=True)


def unload(model: str) -> None:
    request = urllib.request.Request(
        f"http://{HOST}/api/generate",
        data=json.dumps({"model": model, "keep_alive": 0}).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=60):
            pass
    except urllib.error.HTTPError as exc:
        if exc.code != 404:
            raise


def write_status(status: str, phase: str, **extra: object) -> None:
    payload = {"status": status, "updated_at_utc": now(), "phase": phase, **extra}
    (PROJECT / "pipeline_status.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )


def run_qa() -> None:
    args = (
        "answer_summary_questions.py",
        "--facts", str(BASE / "facts/canonical_facts.csv"),
        "--summary-file", str(PROJECT / "rerun_only.csv"),
        "--output-dir", str(PROJECT / "qa_new"),
        "--experiment-run-id", "plain_fewshot_rerun_20260930",
        "--model", "thesis_qwen38_qa_v1=thesis-qwen38-qa:v1",
        "--temperature", "0", "--seed", "32", "--num-ctx", "8192",
        "--api-retries", "3", "--host", HOST, "--resume",
        "--accept-terminal-grounding-missing",
    )
    for pass_number in range(1, 4):
        print(f"QA completion pass {pass_number}/3", flush=True)
        result = run(*args, check=False)
        manifest_path = PROJECT / "qa_new/manifest.json"
        if manifest_path.exists() and json.loads(manifest_path.read_text(encoding="utf-8")).get("complete"):
            return
        if result.returncode == 0:
            raise RuntimeError("QA command returned success without a complete manifest")
    manifest = json.loads((PROJECT / "qa_new/manifest.json").read_text(encoding="utf-8"))
    raise RuntimeError(f"QA incomplete after three resume passes: {manifest}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if not args.run:
        print("Ready: merge summaries, recompute full metrics, run 16,000 new QA units, merge QA, and rebuild reports.")
        return 0
    if not (PROJECT / "run/completion.json").exists():
        raise RuntimeError("summary generation is not complete")
    write_status("running", "merge_summaries")
    try:
        run("merge_plain_fewshot_rerun_final100.py")

        write_status("running", "content_metrics")
        unload("thesis-seed:v1")
        run(
            "evaluate_autocot_automatecot_metrics.py",
            "--results", str(PROJECT / "recursive_results.csv"),
            "--output-dir", str(PROJECT / "metrics"),
            "--bertscore-model", BERTSCORE, "--summac-device", "cuda",
            "--bootstrap-samples", "10000", "--seed", "32",
        )

        write_status("running", "qa_16000")
        run_qa()
        unload("thesis-qwen38-qa:v1")
        run("prepare_plain_fewshot_rerun_qa.py")

        write_status("running", "qa_scoring_and_reports")
        run(
            "score_model_selection_batch.py", "--articles", str(DATA),
            "--summary-file", str(PROJECT / "recursive_results.csv"),
            "--fact-summary", str(BASE / "facts/fact_extraction_summary.csv"),
            "--answers", str(PROJECT / "qa/summary_question_answers.csv"),
            "--output-dir", str(PROJECT / "qa_report"), "--with-bertscore",
            "--bertscore-model", BERTSCORE, "--with-summac", "--summac-device", "cuda",
        )
        run(
            "analyze_autocot_automatecot_qa.py",
            "--detailed", str(PROJECT / "qa_report/qa_retention_detailed.csv"),
            "--output-dir", str(PROJECT / "qa_report"),
            "--bootstrap-samples", "10000", "--seed", "32",
        )
        run(
            "compute_length_adjusted_retention.py",
            "--qa-article", str(PROJECT / "qa_report/qa_article_level.csv"),
            "--length-detailed", str(PROJECT / "metrics/metrics_detailed.csv"),
            "--output-dir", str(PROJECT / "combined_metrics"),
            "--bootstrap-samples", "10000", "--seed", "32",
        )
        completion = {
            "status": "complete", "completed_at_utc": now(),
            "new_summary_rows": 200, "new_summary_calls": 800,
            "new_qa_units": 16000, "canonical_facts_reused": 2000,
            "summaries_sha256": sha(PROJECT / "recursive_results.csv"),
            "qa_sha256": sha(PROJECT / "qa/summary_question_answers.csv"),
        }
        (PROJECT / "downstream_completion.json").write_text(
            json.dumps(completion, indent=2) + "\n", encoding="utf-8"
        )
        write_status("complete", "complete")
        print("PASS: Plain/Few-Shot rerun and complete downstream evaluation finished", flush=True)
        return 0
    except Exception as exc:
        write_status("failed", "failed", error=str(exc))
        raise


if __name__ == "__main__":
    raise SystemExit(main())
