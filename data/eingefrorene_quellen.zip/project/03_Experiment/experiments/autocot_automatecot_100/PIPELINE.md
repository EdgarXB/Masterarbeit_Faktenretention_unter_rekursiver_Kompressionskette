# Reproducible Auto-CoT / Automate-CoT Pipeline

This directory contains the frozen data, audit trail, demonstrations, and final outputs for a
100-article comparison with five demonstrations per compression transition. Methodological
decisions and all findings belong in `RESEARCH_LOG.md`; machine events belong in
`pipeline_execution.jsonl`.

Status clarification: the demonstration-construction portion is complete. The originally planned
100-article comparison was later stopped on request and is not an experimental result. Steps 6–10
below describe the frozen downstream plan, not a completed comparison.

## Fixed stages and roles

| Role | Official CNN/DailyMail split | N | May influence demonstrations? |
|---|---:|---:|---|
| Candidate construction | train | 130 minimum, 240 amended maximum | yes |
| Automate-CoT policy selection | validation | 30 | yes, optimization and internal end diagnosis |
| Final paired evaluation | test | 100 | no |

Each article starts at 795--805 words. Recursive transitions are
`~800->500`, `500->300`, `300->150`, and `150->75`. Five separate demonstrations are used at each
transition. Inputs for later-stage demonstrations are generated recursive intermediates, not
naturally short articles. A “word” is a Unicode `\b\w+\b` regex token throughout; the accepted
intervals are 475--525, 285--315, 142--158, and 71--79 respectively.

## Step-by-step execution

1. Verify the three frozen files and cross-role SHA-256 disjointness:

   ```bash
   .venv-metrics/bin/python validate_autocot_automatecot_artifacts.py --phase splits
   ```

2. Generate frozen Seed zero-shot-CoT recursive rollouts for at least 130 training candidates and
   30 policy-selection articles from the official validation split with `num_ctx=524288`. The original deterministic 200-item training
   reserve was prospectively extended by 40 train-only items after v14 exhausted at 103/110
   eligible 75-word candidates, before any validation or final generation. After item 130,
   generation stops at the first article for which every transition has
   at least 110 structurally hard-eligible Automate-CoT candidates and at least 25 Auto-CoT-
   eligible short-rationale candidates.
3. Construct Auto-CoT banks: chunk-embed each full stage input with the pinned MiniLM snapshot,
   cluster each transition into five groups, and choose the nearest hard-eligible centroid item.
4. Construct Automate-CoT pools: apply structural hard-validity checks, score input-summary
   consistency with SummaCConv, and retain 100 of at least 110 candidates per transition. Novel numeric tokens are
   recorded as a diagnostic but do not duplicate SummaC as a binary factuality filter.
5. Learn five ordered unique Automate-CoT demonstrations per transition with the
   variance-reduced policy-gradient procedure. The selection loss is one minus hard-valid,
   human-highlight ROUGE-L. Unlike original Automate-CoT, no second independent 100-item
   policy-validation set is used: the same 27–30 stage-valid selection inputs produce both the
   gradients and the internal end diagnostic. These values are therefore not an independent
   generalization estimate.
6. For any future main evaluation, run both methods independently through all four recursive
   transitions for each frozen test article with exactly one summary call per method, article and
   stage. There is no length revision, best-of selection, content retry, or automatic transport
   resend. By explicit prospective researcher decision, Few-Shot-CoT, Auto-CoT and Automate-CoT
   all use the raw Seed wrapper with `cot=False`; this common runtime setting does not rewrite the
   completed pilot. The scientific justification remains asymmetric: Automate-CoT has two small
   exploratory wrapper ablations, whereas parity for Auto-CoT and Few-Shot-CoT is a design choice.
7. Unload Seed. Compute highlight ROUGE/BERTScore, SummaC against both original source and
   immediate recursive input, numeric diagnostics versus both
   the original article and immediate recursive input, initial and
   binary length compliance, absolute and relative target error,
   `word_window_violation_rate` as the target-normalized distance to the nearest accepted window
   boundary, and article-paired bootstrap confidence intervals.
8. Generate 20 canonical atomic facts/questions per source article using frozen Gemma under the
   final 24-candidate-to-20-valid-question rule. Unload Gemma.
9. Answer every canonical question from every stage summary using the frozen
   `thesis-qwen38-qa:v1` answerer. Every answered item must return an exact contiguous supporting
   quote from the summary; `NOT_FOUND` requires empty support. Qwen is used only in this QA role,
   never in demonstration pruning or optimization. Reference-discordant answers are reported as a
   judge-dependent diagnostic, not as a direct hallucination estimate. Persistent exact-grounding
   failures remain explicit technical missing values with the frozen sensitivity analysis.
10. Validate final counts, exact recursive handoffs, model digest, native context, demo uniqueness,
    and absence of test leakage.

## Additional frozen five-shot Few-Shot-CoT condition

For a new main experiment, a researcher-supplied five-shot Few-Shot-CoT package is now frozen in
`few_shot_cot/` and exported as `final_prompts/few_shot_cot_{500,300,150,75}.txt`. Each stage has
five ordered Input–Reasoning–Output demonstrations. The five distinct origin articles are from the
candidate train split and are hash-disjoint from selection validation, the final 100-article test
set, and the completed 30-article pilot set. Every demonstration output satisfies its ±5% window,
ends in a complete sentence, and equals the next stage's input within its chain.

At runtime, load only the prompt matching the current target and replace its single
`{{NEW_INPUT}}` placeholder. `few_shot_cot_runtime.render_few_shot_prompt()` performs this operation
with a fail-closed prompt-hash check. The supplied prompt itself requests a visible reasoning trace;
this content-level CoT instruction remains active while the model-specific raw wrapper is fixed to
`cot=False`. No
main runner has yet been declared final for the expanded comparison, so the old two-method
orchestrator below must not be treated as authorization to launch the new 100-article experiment.

The restartable orchestrator for steps 2--9 is:

```bash
.venv-metrics/bin/python -u run_full_autocot_automatecot_experiment.py \
  --host 127.0.0.1:11435
```

If the already-running candidate job has completed, resume downstream with:

```bash
.venv-metrics/bin/python -u run_full_autocot_automatecot_experiment.py \
  --host 127.0.0.1:11435 \
  --skip-candidate-rollouts
```

## Primary outputs

- `candidate_rollouts/`: zero-shot-CoT candidate traces and stage inputs.
- `auto_cot_selection/auto_cot_demonstrations.json`: 4 x 5 Auto-CoT demonstrations.
- `automate_cot_pruning/`: complete pruning scores/audit and 4 x 100 pools.
- `automate_cot_selection/automate_cot_demonstrations.json`: 4 x 5 ordered demonstrations.
- `few_shot_cot/five_shot_demonstrations.json`: 4 x 5 researcher-supplied Few-Shot-CoT demonstrations.
- `final_prompts/few_shot_cot_*.txt`: four directly renderable stage prompts with one input placeholder.
- `final_run/recursive_results.csv`: 100 articles x 2 methods with four summaries each.
- `metrics/`: detailed metrics, aggregates, and paired bootstrap contrasts.
- `facts/`, `qa/`, `qa_report/`: independent Gemma fact set and final GLM QA evaluation.
- `validation_final.json`: final completeness/leakage/invariant validation.
- `environment_manifest.json`: package versions, model freeze and file hashes.

Do not interpret partial files as final results. The final experiment is complete only when
`validate_autocot_automatecot_artifacts.py --phase final` passes.
