# Finale Auto-CoT-/Automate-CoT-Prompts

Dieser Ordner enthält die acht finalen User-/Content-Prompts mit vollständig eingebetteten
Demonstrationen.

## Dateien

| Methode | 800→500 | 500→300 | 300→150 | 150→75 |
|---|---|---|---|---|
| Few-Shot-CoT | `few_shot_cot_500.txt` | `few_shot_cot_300.txt` | `few_shot_cot_150.txt` | `few_shot_cot_75.txt` |
| Auto-CoT | `auto_cot_500.txt` | `auto_cot_300.txt` | `auto_cot_150.txt` | `auto_cot_75.txt` |
| Automate-CoT | `automate_cot_500.txt` | `automate_cot_300.txt` | `automate_cot_150.txt` | `automate_cot_75.txt` |

## Verwendung

1. Eine Methode für den Lauf festlegen (`few_shot_cot`, `auto_cot` oder `automate_cot`).
2. Für die aktuelle Zielstufe die gleichnamige Datei laden.
3. `{{NEW_INPUT}}` genau einmal durch den aktuellen Text ersetzen.
4. Den Prompt an das Modell senden und den Text nach `FINAL_SUMMARY:` als Stufenausgabe nutzen.
5. Diese Ausgabe als `NEW_INPUT` der nächsten Stufe verwenden.

Nicht alle vier Banken gleichzeitig in einen Prompt einsetzen: Jede Bank ist für genau einen
rekursiven Übergang konstruiert. Auto-CoT und Automate-CoT verwenden dieselbe Instruktionsschablone;
der methodische Unterschied liegt in Auswahl und Reihenfolge der Demonstrationen.

`manifest.json` enthält vollständige SHA-256-Hashes, geordnete Demonstrations-IDs,
Quellbankhashes und Promptwortzahlen. Die Dateien können reproduzierbar mit
`export_final_cot_prompts.py` (Auto/Automate) beziehungsweise
`operationalize_user_fewshot_prompts.py` (Few-Shot-CoT) neu erzeugt werden. Die neue
Few-Shot-CoT-Bank ist für einen künftigen Lauf eingefroren; sie verändert den abgeschlossenen
30-Artikel-Piloten nicht.
