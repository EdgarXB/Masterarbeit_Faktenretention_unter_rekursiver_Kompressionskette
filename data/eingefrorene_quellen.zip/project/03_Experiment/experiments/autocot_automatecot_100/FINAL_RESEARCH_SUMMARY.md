# Finale Research-Synthese: Auto-CoT und summarization-adaptiertes Automate-CoT

Stand: 30. August 2026  
Gegenstand: Konstruktion von jeweils fünf stufenspezifischen Demonstrationen für die rekursive
Kompression `~800 → 500 → 300 → 150 → 75` Wörter  
Status: **Demonstrationskonstruktion abgeschlossen und validiert; die anschließend begonnene
100-Artikel-Vergleichsevaluation wurde auf ausdrücklichen Nutzerwunsch beendet und ist kein
Ergebnisbestandteil.**

Abbildungen, druckfertige Bildunterschriften, Interpretationsgrenzen und die Zuordnung zwischen
Markdown-Dokumentation und vollständigen Rohartefakten stehen in [`FIGURES.md`](FIGURES.md).

## 1. Kurzfassung

Ziel war die wissenschaftlich nachvollziehbare Konstruktion zweier Few-shot-CoT-Promptbanken für
mehrstufige Nachrichtenzusammenfassung. Die erste Bank folgt Auto-CoT: Eingaben werden semantisch
geclustert und pro Cluster wird ein zentrumsnahes, strukturell gültiges Zero-shot-CoT-Beispiel
gewählt. Die zweite Bank folgt dem Optimierungsprinzip von Automate-CoT, musste aber für offene
Zusammenfassungen angepasst werden: Da es keine einzelne exakt richtige Zielantwort gibt, wurden
Kandidaten zunächst anhand struktureller Bedingungen und ihrer SummaC-Konsistenz mit der
unmittelbaren Eingabe geprunt. Anschließend lernte eine geordnete, duplikatfreie Fünferauswahl mit
einem varianzreduzierten Policy-Gradient-Verfahren auf einem getrennten Validationssplit. Der
Reward war hard-gated, stemmed ROUGE-L gegenüber menschlichen CNN/DailyMail-Highlights. GLM-QA
oder ein anderes generatives LLM-as-a-Judge wurde weder für Pruning noch für Optimierung benutzt.

Das Ergebnis sind acht unmittelbar verwendbare Prompts: Auto-CoT und Automate-CoT jeweils für
500, 300, 150 und 75 Zielwörter. Jeder Prompt enthält fünf vollständige Demonstrationen mit
realistischem rekursivem Eingabetext, Zero-shot-CoT-Reasoning und finaler Zusammenfassung. Die
Eingabestelle ist durch `{{NEW_INPUT}}` markiert. Beide Methoden verwenden dieselbe
Instruktionsschablone; nur Auswahl und—bei Automate-CoT—gelernte Reihenfolge der Demonstrationen
unterscheiden sich. Damit wird der Methodenvergleich nicht durch abweichende Instruktionen
konfundiert.

Die Demonstrationsartefakte bestehen 104 projektweite Preflight-Prüfungen und einen zusätzlichen
unabhängigen Audit aller 40 Demonstrationen. Geprüft wurden unter anderem Train-only-Herkunft,
Split-Trennung, fünf einzigartige Beispiele je Bank und Stufe, korrekte rekursive Eingabe- und
Ausgabelängen, vollständige Satzenden, nichtleere Reasoning-Traces, Auto-CoT-Clusterabdeckung und
Automate-CoT-Positionsordnung.

## 2. Wissenschaftliche Grundlage und Begriffsabgrenzung

### 2.1 Auto-CoT

Auto-CoT nach Zhang et al. konstruiert Demonstrationen automatisch, indem es Aufgabeninputs
einbettet, clustert, Beispiele nach ihrer Distanz zum Clusterzentrum ordnet und für geeignete
Repräsentanten Zero-shot-CoT-Rationales erzeugt. Entscheidend ist, dass die **Aufgabeninputs** und
nicht die bereits generierten Rationales geclustert werden. Andernfalls könnte die Auswahl primär
Schreibstile des Modells statt inhaltlich unterschiedlicher Aufgaben abbilden. Quelle:
[Zhang et al., 2023, ICLR](https://arxiv.org/abs/2210.03493); die offizielle Implementierung wurde
lokal bei Commit `ec9caa32a69cfd7203c33df76d31cb48e726d6a7` auditiert.

Die vorliegende Adaption behält diese Logik bei, verwendet aber separate Cluster pro
Kompressionsübergang und summary-spezifische Eignungskriterien. Fünf Cluster wurden gewählt, weil
fünf Demonstrationen verlangt waren. Lange Eingaben wurden vollständig abgebildet: Der gepinnte
Encoder `all-MiniLM-L6-v2` verarbeitet nicht überlappende 160-Wort-Chunks; deren normalisierte
Embeddings werden gemittelt und nochmals L2-normalisiert. Dadurch wird nicht nur der Artikelanfang
repräsentiert.

Die Bezeichnung **summarization-adaptiertes Auto-CoT** ist präziser als „originalgetreues
Auto-CoT“. Algorithmus 2 und die offizielle Implementierung des Originals wählen ebenfalls nicht
bedingungslos den geometrisch nächsten Punkt: Kandidaten werden nach Zentrumsdistanz durchlaufen
und der erste Kandidat gewählt, dessen Frage höchstens 60 Tokens, dessen Rationale höchstens fünf
Schritte lang und formal abgeschlossen und dessen vorhergesagte Antwort nichtleer ist; bei
arithmetischen Aufgaben wird zusätzlich geprüft, ob die Antwort im Rationale erscheint
([Paper, Algorithmus 2](https://openreview.net/pdf?id=5NTt8GFjUHkr),
[offizieller Code, Zeilen 114–149](https://github.com/amazon-science/auto-cot/blob/ec9caa32a69cfd7203c33df76d31cb48e726d6a7/run_demo.py#L114-L149)).
Unsere Pipeline bewahrt somit das Prinzip „zentrumsgeordnet, dann heuristisch geeignet“, ersetzt
die konkrete Eignungsdefinition aber substanziell:

| Komponente | Original Auto-CoT | Vorliegende Umsetzung | Einordnung |
|---|---|---|---|
| Repräsentation und Clustering | kurze Fragen, Sentence-BERT und K-Means | vollständige rekursive Inputs, 160-Wort-Chunkaggregation, 384D-K-Means separat je Stufe | kernkompatible Aufgabenadaption |
| Clusterzahl | aufgabenspezifisch 4–8 | genau 5 je Stufe | durch verlangte fünf Demonstrationen bestimmt |
| Auswahl | aufsteigende Zentrumsdistanz | aufsteigende 384D-Zentrumsdistanz | originaler Auswahlkern |
| Inputheuristik | Frage höchstens 60 Tokens | stufenspezifisches Inputfenster | ursprüngliches Gate ersetzt |
| Rationaleheuristik | höchstens fünf Schritte, formaler Abschluss | nichtleer, mindestens 25 substantielle und höchstens 512 Wörter | zusätzliche, nicht äquivalente Operationalisierung |
| Antwortheuristik | nichtleer; teils Antwort im Rationale | nichtleere Summary, enges Zielwortfenster und vollständiger Satz | deutlich strengere Summary-Adaption |

Die 512-Wort-Grenze ist insbesondere **keine direkte Replikation** der Fünf-Schritte-Heuristik:
Wörter und Reasoning-Schritte messen verschiedene Eigenschaften. Ebenso existiert das enge
Outputwortfenster im Original nicht. Diese Gates gewährleisten verwendbare 800→500→300→150→75-
Demonstrationen, konditionieren die Auswahl aber zugleich auf formale Längenbefolgung und können
damit semantische Repräsentativität gegen Formatkonformität eintauschen.

### 2.2 Automate-CoT

Automate-CoT nach Shum et al. augmentiert aus gelabelten Daten CoT-Kandidaten, verwirft Kandidaten
mit falscher Endantwort und optimiert eine geordnete Demonstrationskombination durch Black-box-
Optimierung mit varianzreduziertem Policy-Gradient-Schätzer. Das Originalverfahren wurde für
Aufgaben mit diskret oder exakt prüfbarer Antwort entwickelt. Quelle:
[Shum et al., 2023, Findings of EMNLP](https://aclanthology.org/2023.findings-emnlp.811/); die
offizielle Implementierung wurde lokal bei Commit
`14974bb6493e1f1f8f5ea876bfecc033b68525dd` auditiert.

Eine offene Zusammenfassung besitzt keine einzelne exakte Endantwort. Das hier implementierte
Verfahren wird deshalb bewusst **summarization-adaptiertes Automate-CoT** genannt. Die
Exact-match-Prüfung des Originals wurde nicht nur umbenannt, sondern durch eine explizite
zweistufige Operationalisierung ersetzt:

1. strukturell gültige Kandidaten werden nach source-conditioned SummaC-Konsistenz geprunt;
2. eine geordnete Fünferfolge wird auf getrennten Validation-Eingaben anhand hard-gated
   menschlicher Highlight-ROUGE-L-Utility optimiert.

Die fünf Positionen besitzen separate kategoriale Verteilungen. Beim Sampling und bei der finalen
greedy Auswahl werden bereits verwendete Kandidaten maskiert, sodass tatsächlich fünf
unterschiedliche Demonstrationen entstehen. Diese Eindeutigkeitsbedingung ist eine dokumentierte
Adaption; die offizielle Implementierung verhindert Duplikate nicht explizit.

Auch hier bezeichnet „summarization-adaptiert“ keine direkte Replikation. Das Paper definiert
Automate-CoT als **Augment–Prune–Select**: pro gelabelter Frage wird im Hauptexperiment eine
Rationalekette erzeugt (`k=1`), nur Ketten mit zur Ground Truth passender Endantwort gelangen in
den Pool, und unabhängige positionsspezifische kategoriale Verteilungen werden mit einem
varianzreduzierten Policy-Gradient-Schätzer optimiert
([Shum et al., 2023, §§3.1–3.2](https://aclanthology.org/2023.findings-emnlp.811.pdf)). Das
vorliegende Verfahren erhält diese Dreiteilung und den diskreten VR-PGE-Auswahlkern, ersetzt aber
mehrere zentrale Operationalisierungen:

| Komponente | Original Automate-CoT | Vorliegende Umsetzung | Einordnung |
|---|---|---|---|
| Augmentierung | überwiegend few-shot; `k=1` Kette je Frage, Zero-shot als untersuchte Variante | Zero-shot-CoT, formale Längensteuerung mit bis zu zwölf Generationsversuchen, danach eine gespeicherte Kette je Artikel und Stufe | Zero-shot ist paperkompatibel; Mehrversuchssteuerung ist zusätzliche Adaption |
| Pruningkriterium | normalisierte Endantwort stimmt exakt mit gelabelter Antwort überein | Strukturgates plus Ranking nach source-conditioned SummaC; Highlight-ROUGE-L nur als exakter Tie-Breaker | zentrale, notwendige Ersetzung für offene Zusammenfassung |
| Kandidatenpool | 100 als Haupteinstellung | 100 je Zielstufe | direkt vergleichbare Poolgröße |
| Demonstrationszahl | aufgabenabhängig 4–8 | 5 je Zielstufe | innerhalb des Originalbereichs |
| Positionsmodell | unabhängige kategoriale Verteilung je Promptposition | kategoriale Verteilung je Promptposition | originaler Auswahlkern |
| Duplikate | unabhängiges Sampling; keine explizite Eindeutigkeitsmaske | sequentielle Maske erzwingt fünf verschiedene Kandidaten | zusätzliche Stabilitätsbedingung |
| Policy-Loss | Antworttoken-Cross-Entropy aus API-Logprobs; Auswahl anhand Validationsgenauigkeit | `1 −` hard-gated, stemmed Highlight-ROUGE-L-F1 | zentrale Summary-Adaption; andere Zielgröße |
| Daten für Select | 100 Policy-Trainings- und 100 separate Validationsbeispiele | 27–30 stufengültige Beispiele desselben 30er-Splits dienen direkt der Policy-Optimierung und der internen Endauswertung | ressourcenbedingte Abweichung mit höherem Overfittingrisiko |
| Optimierer | Paper: AdamW; offizieller Code: Adam plus CosineAnnealing; fünf Epochen, `lr=1e-3`, Batch 10 | Adam plus CosineAnnealing; fünf Epochen, `lr=1e-3`, Batch 10, zehn VR-PGE-Samples | an offizieller Implementierung orientiert |

Der getrennte CNN/DailyMail-Testsplit blieb vollständig unangetastet, sodass keine Testleakage
vorliegt. Der 30er-Split ist methodisch aber genauer als **Policy-Selection-Split** zu verstehen,
nicht als unabhängige Validationsschätzung: Seine Beispiele erzeugen die Gradienten und bewerten
anschließend die finale argmax-Kombination. Die berichteten Utilities sind daher optimistisch
selektionsbehaftete interne Diagnostik. Gegenüber dem Original fehlen insbesondere eine separate
100er-Policy-Trainingsmenge, eine davon unabhängige 100er-Validation und ein
Endantwort-Exact-Match-Kriterium. Die Umsetzung ist somit als Automate-CoT-inspirierte,
summarization-spezifische Adaption wissenschaftlich vertretbar, aber nicht als Replikation des
Originalverfahrens.

### 2.3 Warum kein GLM-LLM-as-a-Judge für die Auswahl verwendet wurde

Die Sorge, mit GLM eine Metrik zu optimieren, die anschließend wieder von GLM berechnet wird, ist
methodisch berechtigt. Eine solche Schleife würde die Demoauswahl an die Präferenzen und Fehler
desselben Judges anpassen und erschwert die Interpretation einer späteren GLM-QA-Auswertung.
Zudem sind LLM-Judges unter anderem für Positions- und Darstellungsbias anfällig
([Shi et al., 2025](https://aclanthology.org/2025.ijcnlp-long.18/)). Daher wurde GLM vollständig
aus Pruning und Policy-Reward ausgeschlossen (`glm_qa_used=false`).

Das bedeutet nicht, dass die verwendeten Alternativen modellfrei oder objektiv vollständig sind:

- ROUGE ist eine deterministische lexikalische Referenzüberlappung
  ([Lin, 2004](https://aclanthology.org/W04-1013/));
- SummaC nutzt ein NLI-Modell und ist damit eine gelernte, nichtgenerative Konsistenzmetrik
  ([Laban et al., 2022](https://doi.org/10.1162/tacl_a_00453));
- BERTScore wäre ebenfalls learned/model-based und wurde deshalb nicht als vermeintlich
  „modellfreie“ Auswahlmetrik dargestellt
  ([Zhang et al., 2020](https://arxiv.org/abs/1904.09675)).

SummaC und ROUGE wurden komplementär eingesetzt: SummaC für input-summary consistency beim
Pruning, ROUGE-L gegen unabhängige menschliche Highlights für Salienz im Policy-Reward. Keine der
Metriken wird als vollständiges Maß menschlich beurteilter Zusammenfassungsqualität interpretiert.

## 3. Datenrollen und Schutz vor Leakage

Die Daten stammen aus der revisionsgepinnten CNN/DailyMail-Version
`96df5e686bee6baa90b8bee7c28b81fa3fa6223d`. Die offiziellen Splits hatten getrennte Rollen:

| Rolle | Split | Umfang | Einfluss auf Demonstrationen |
|---|---:|---:|---|
| Kandidatengenerierung | train | 207 tatsächlich verarbeitet, Reserve bis 240 | ja |
| Policy-Optimierung | validation | 30 | nur Automate-CoT-Auswahl |
| ursprünglich geplante Evaluation | test | 100 eingefroren | nein |

Alle Quellen enthielten nach dem einheitlichen Unicode-Regex-Wortzähler 795–805 Wörter und
nichtleere menschliche Highlights. Artikeltexte wurden per SHA-256 dedupliziert; Kandidaten-,
Validation- und Testrollen sind per Artikelhash disjunkt. Der Testsplit hatte keinen Einfluss auf
Clustering, Pruning, Promptwortlaut, Hyperparameter oder Policy-Auswahl. Die später auf Wunsch
beendete Testevaluation ist ausdrücklich nicht Teil der hier berichteten Demonstrationsergebnisse.

## 4. Warum rekursive Zwischenstufen statt natürlich kurzer Artikel verwendet wurden

Für den Übergang `300 → 150` wäre es technisch einfacher gewesen, natürlich etwa 300 Wörter lange
Artikel auszuwählen. Das wurde verworfen. Im realen Einsatz ist der 300-Wort-Input bereits eine
modellgenerierte Zusammenfassung einer vorangegangenen 500-Wort-Stufe. Natürlich kurze Artikel
unterscheiden sich in Informationsdichte, Textstruktur, Redundanz und möglicher Fehlerhistorie von
solchen rekursiven Zwischenprodukten. Ihre Verwendung hätte einen systematischen Distribution
Shift zwischen Demonstration und Deployment erzeugt.

Deshalb wurden die 795–805-Wort-Trainartikel mit dem eingefrorenen Seed-Modell rekursiv durch
`800 → 500 → 300 → 150 → 75` verarbeitet. Jede stufenspezifische Demonstration erhält als Input
den tatsächlich generierten Output der vorherigen Stufe. Eingaben späterer Kandidaten sind nur
auswahlfähig, wenn sie im Wortfenster der vorherigen Zielstufe liegen. Das schützt die semantische
Bedeutung eines nominalen `300 → 150`-Beispiels.

Die einheitlichen akzeptierten Intervalle sind:

| Ziel | Erwarteter Input | Akzeptierter Output |
|---:|---:|---:|
| 500 | 795–805 | 475–525 |
| 300 | 475–525 | 285–315 |
| 150 | 285–315 | 142–158 |
| 75 | 142–158 | 71–79 |

Ein „Wort“ ist in allen Splits, Gates, Prompts und Audits ein Treffer des Unicode-RegEx
`\b\w+\b`. Diese Definition ist nicht linguistisch alternativlos, aber vollständig konsistent und
reproduzierbar.

## 5. Modell- und Laufzeitkonfiguration

Generator war das eingefrorene `thesis-seed:v1`, Seed-OSS 36.2B Q4_K_M, Digest
`7a66a2f466bf48fdafa7004a7975a7f5fac6e667a6de7d01751aacb98b3f387c`. Anders als im früheren
8k-Pilot wurde das native Kontextlimit 524.288 gesetzt. Ein realer Preflight bestätigte die
Ladbarkeit dieses Kontexts. Wegen der Speicher- und Laufzeitkosten wurde auf dem dedizierten
Ollama-Server Flash Attention, genau ein paralleler Request, genau ein geladenes Modell und ein
q4_0-KV-Cache eingesetzt. q4_0 ist eine Machbarkeitsentscheidung und kann gegenüber höherer
KV-Präzision Qualität verändern; Aussagen gelten daher für genau dieses implementierte System.
Zur Beziehung zwischen Kontext und Speicher sowie KV-Quantisierung siehe die
[Ollama-Kontextdokumentation](https://docs.ollama.com/context-length) und
[Ollama-FAQ](https://docs.ollama.com/faq).

Die Prompts selbst nutzen das Kontextfenster nicht annähernd vollständig. 524.288 bezeichnet die
Kapazität, nicht die tatsächliche Promptlänge. Die finalen Demonstrationsprompts liegen ohne neue
Eingabe zwischen 3.061 und 10.440 Regex-Wörtern.

## 6. Kandidatengenerierung und Längensteuerung

Jeder Kandidat enthält den stufenspezifischen Input, einen Zero-shot-CoT-Reasoning-Trace und die
finale Zusammenfassung. Die ersten Trainingsdiagnosen zeigten, dass eine einmalige Aufforderung
die engen ±5%-Fenster häufig verfehlte. Mehrfach identische Requests lösten das Problem nicht.
Zusätzliche Retention-Ratio- und Satzbudgetformulierungen verschlechterten den ersten
Trainingsfall und wurden vor Validation/Test verworfen.

Final verwendet wurde eine geschlossene, rein formale Längensteuerung:

- Versuch 1 ist eine normale Generierung am wahren Ziel;
- Versuch 2 ist eine normale Revision am wahren Ziel;
- ab Versuch 3 wird nur das operationale Instruktionsziel proportional angepasst:
  `C_next = round(C × T / W)`, begrenzt auf `0,35T…1,75T`;
- der wahre Akzeptanzbereich um `T` bleibt unverändert;
- der vorige Kandidatentext wird nicht erneut in den Prompt kopiert, da Diagnosen Copy-Anchoring
  und byte-identische Wiederholungen trotz anderer Kontrollziele zeigten;
- maximal zwölf Versuche; keine mechanische Trunkierung oder Padding.

Seed-spezifische Budgetmarker wurden vor der Beurteilung des Reasonings entfernt. Ein Reasoning
gilt erst ab 25 substanziellen Wörtern als nichtdegeneriert. Auto-CoT behält zusätzlich eine
konservative Obergrenze von 512 Reasoning-Wörtern als originalmethodennahe Short-rationale-
Heuristik; Automate-CoT übernimmt diese Auto-spezifische Obergrenze nicht. Ein
Reflection-Intervall von 512 ersetzte das zunächst verwendete Intervall 128, weil das kurze
Intervall wiederholt nur Budgetbuchhaltung statt substanzieller CoT-Traces erzeugte.

## 7. Finale Auto-CoT-Konstruktion

Für jede Stufe wurden alle 207 realisierten Aufgabeninputs mit dem gepinnten MiniLM-Snapshot
chunkweise eingebettet und mit K-Means (`K=5`, `random_state=32`, `n_init=20`) geclustert. Pro
Cluster wurde der nächstgelegene Kandidat gewählt, der die stufenspezifischen
Input-/Outputfenster, nichtleeren substanziellen Reasoning-Trace,
Auto-CoT-Reasoningobergrenze und vollständigen Satzabschluss erfüllt. Alle Cluster enthielten
mindestens einen geeigneten Kandidaten.

Die niedrigen Cosine-Silhouette-Werte zeigen überlappende, nicht scharf separierte semantische
Gruppen. Sie widerlegen die Auswahl nicht, begrenzen aber eine Behauptung klarer natürlicher
Cluster:

| Ziel | Kandidateninputs | Cosine-Silhouette | Finale IDs, je ein Clusterrepräsentant |
|---:|---:|---:|---|
| 500 | 207 | 0,107426 | `train:11239:500`, `train:17748:500`, `train:4963:500`, `train:7253:500`, `train:20941:500` |
| 300 | 207 | 0,102479 | `train:23084:300`, `train:15317:300`, `train:13531:300`, `train:4963:300`, `train:10522:300` |
| 150 | 207 | 0,096381 | `train:4963:150`, `train:4270:150`, `train:20941:150`, `train:17748:150`, `train:10522:150` |
| 75 | 207 | 0,090985 | `train:3679:75`, `train:20941:75`, `train:12772:75`, `train:4693:75`, `train:13700:75` |

Innerhalb jeder Zielstufe sind die fünf Demonstrationen unterschiedliche Kandidaten aus fünf
verschiedenen Clustern; kein einzelner Auto-CoT-Prompt enthält denselben Ursprungsartikel
mehrfach. Diese Eindeutigkeit gilt jedoch nicht global über alle vier Stufen. Die 20
stufenspezifischen Auto-CoT-Demonstrationen basieren auf 14 unterschiedlichen Ursprungsartikeln.
Vier Trainingsartikel wurden in mehreren, separat geclusterten Stufen ausgewählt:

| Trainingsartikel | Ausgewählte Zielstufen |
|---:|---|
| 4963 | 500, 300 und 150 |
| 20941 | 500, 150 und 75 |
| 17748 | 500 und 150 |
| 10522 | 300 und 150 |

Eine stufenübergreifende Wiederverwendung war zulässig, weil jede Zielstufe als eigene
bedingte Aufgabe geclustert wurde und die rekursiv erzeugten Eingabetexte desselben
Ursprungsartikels zwischen den Stufen verschieden sind. Die fünf ausgewählten Beispiele wurden
im finalen Auto-CoT-Prompt reproduzierbar nach der numerischen Cluster-ID 0–4 angeordnet. Diese
Reihenfolge wurde nicht anhand von Referenzen oder Validierungsleistung optimiert; anders als bei
Automate-CoT ist sie keine gelernte Demonstrationsreihenfolge. Das Wort `ordered` in der
gemeinsamen Promptschablone bezeichnet bei Auto-CoT daher nur die festgelegte Darbietungsfolge.

Die Auswahl bewahrt den clustering-basierten Kern von Auto-CoT, ist aber keine originalgetreue
Replikation. Von 20 Demonstrationen waren nur sechs zugleich die absolut zentrumsnächsten
Kandidaten; die übrigen 14 waren jeweils die nächsten **geeigneten** Kandidaten. Die Ränge der
gewählten Kandidaten innerhalb der nach 384D-Zentrumsdistanz sortierten Cluster waren:

| Ziel | Auswahlränge in Clusterreihenfolge 0–4 |
|---:|---|
| 500 | 2, 1, 3, 3, 1 |
| 300 | 2, 2, 1, 2, 1 |
| 150 | 2, 3, 1, 2, 1 |
| 75 | 4, 2, 7, 13, 6 |

Besonders an der 75-Wort-Stufe verschiebt das enge Formatregime die Auswahl deutlich vom
ungefilterten geometrischen Zentrum weg. Die exakten übersprungenen IDs, Distanzen und
Ausschlussgründe stehen im `ordered_centroid_audit` des Auswahlreports. Dies ist kein Fehler der
PCA-Grafik: Auswahlabstände wurden in 384 Dimensionen berechnet, während PCA nur visualisiert.
Gleichwohl entsteht ein dokumentierter Selection Bias zugunsten längenkonformer, formal
abgeschlossener und innerhalb der Rationalegrenzen liegender Kandidaten.

## 8. Finale summarization-adaptierte Automate-CoT-Konstruktion

### 8.1 Nichtgeneratives Pruning

Kandidaten mussten nichtleeren Input, substanzielles Reasoning und nichtleere Zusammenfassung,
korrektes Eingabe- und Ausgabefenster sowie vollständigen Satzabschluss besitzen. Numerische
Neuheiten wurden protokolliert, aber nach einem frühen Train-only-Audit nicht als binäres Gate
verwendet: Ein lexikalischer Zahlenunterschied kann Erfindung, aber auch gültige Umrechnung oder
Normalisierung sein und hätte bei 500 Wörtern 80% der ersten fünf Kandidaten entfernt. Ein solcher
manueller Filter hätte die vorgesehene SummaC-Rolle dominiert.

Von den hard-eligible Kandidaten wurden pro Stufe exakt die 100 höchsten
SummaCConv-Konsistenzwerte gegenüber dem **unmittelbaren rekursiven Input** behalten. Stemmed
Highlight-ROUGE-L und danach `candidate_id` brechen nur exakte SummaC-Gleichstände.

| Ziel | Generiert | Hard-eligible | Tatsächlich durch Ranking ausgeschlossen | Pool | kleinster gehaltener SummaC | größter ausgeschlossener SummaC |
|---:|---:|---:|---:|---:|---:|---:|
| 500 | 207 | 196 | 96 | 100 | 0,256364 | 0,256241 |
| 300 | 207 | 185 | 85 | 100 | 0,225548 | 0,225534 |
| 150 | 207 | 140 | 40 | 100 | 0,215315 | 0,215128 |
| 75 | 207 | 110 | 10 | 100 | 0,208173 | 0,208120 |

Damit war SummaC nicht nur nominell vorhanden: Selbst an der knappsten 75-Wort-Stufe wurden zehn
strukturell zulässige Kandidaten verworfen. Die hierfür ursprünglich geplante 200er-Trainreserve
endete bei nur 103 geeigneten 75-Wort-Kandidaten. Vor Validation und Test wurde die Reserve
prospektiv auf 240 erweitert, ohne Gates zu senken; das unveränderte 110er-Ziel wurde bei Artikel
207 erreicht. Die ursprüngliche v14-Gate-Nichterfüllung bleibt im Audit erhalten.

### 8.2 Policy-Optimierung

Auf 30 eingefrorenen Artikeln des als `validation` bezeichneten CNN/DailyMail-Splits waren aufgrund des allein vorab definierten
Eingabelängengates 30/27/29/27 Inputs für 500/300/150/75 nutzbar. Für jede der fünf geordneten
Positionen bestand eine kategoriale Verteilung über den 100er-Pool. Pro Update wurden zehn
duplikatfreie Fünferfolgen ausgewertet. Der varianzreduzierte Leave-mean-out-Gradient, Adam mit
Lernrate `1e-3`, Gradient-Clipping bei 3, fünf Epochen und Batches von zehn entsprechen der
auditierten Grundstruktur des offiziellen Optimierers. Jede Stufe erhielt 15 Updates. Insgesamt
entstanden 5.753 inhaltsadressierte, restartfähige Generation-Cacheeinträge.

Utility war stemmed Highlight-ROUGE-L F1, aber nur wenn der Output nichtleer, im Wortfenster und
satzvollständig war; andernfalls Utility 0. Diese harte Null erzeugte insbesondere bei kurzen
Stufen eine sparse Reward-Landschaft:

| Ziel | Validation n | interne finale Utility | Hard-valid-Rate | gelernte Reihenfolge |
|---:|---:|---:|---:|---|
| 500 | 30 | 0,019107 | 0,2667 | `9633`, `18023`, `8496`, `10522`, `14119` |
| 300 | 27 | 0,022140 | 0,2222 | `4219`, `13143`, `25017`, `3206`, `8034` |
| 150 | 29 | 0,003567 | 0,0345 | `15004`, `10352`, `11138`, `25017`, `7856` |
| 75 | 27 | 0,004115 | 0,0370 | `23615`, `6726`, `11138`, `5601`, `3679` |

Diese Zahlen sind **interne Selektionswerte**, keine unverzerrten Testschätzungen: Dieselben
Selection-Stems erzeugten die Policy-Gradienten und bewerteten die finale argmax-Kombination; eine
zweite, davon unabhängige Policy-Validation wie im Original wurde aus Ressourcengründen nicht
verwendet. Die sehr niedrigen Werte bei 150 und 75 dokumentieren
die Schwierigkeit harter Längenbefolgung und dürfen weder verschwiegen noch nachträglich durch
weichere Gates verbessert werden.

## 9. Architektur der finalen Prompts

Jede der acht Dateien folgt derselben Struktur:

```text
Task: Learn the compression behavior from the five ordered demonstrations, then summarize
the new input in approximately <TARGET> words. Think step by step before the final answer.
The accepted length interval is <LOW>-<HIGH> words. Preserve the most important facts
supported by the new input, do not invent facts, and end with a complete sentence.
Output plain prose only after the exact label FINAL_SUMMARY:. Do not put text after it.

DEMONSTRATION 1 — compress to approximately <TARGET> words
INPUT:
...
STEP-BY-STEP REASONING:
...
FINAL_SUMMARY:
...

[Demonstrationen 2–5]

NEW INPUT:
{{NEW_INPUT}}
```

Zur Verwendung wird ausschließlich `{{NEW_INPUT}}` durch den aktuellen Stufeninput ersetzt. Für
die 500er-Stufe ist das der etwa 800-Wort-Artikel; für 300/150/75 ist es jeweils der ausgewählte
Output der unmittelbar vorherigen Stufe. Die Bank darf nicht anhand der Länge des aktuellen
Outputs frei gemischt werden: `auto_cot_150.txt` beziehungsweise `automate_cot_150.txt` gehört
genau zum Übergang eines 285–315-Wort-Inputs auf 142–158 Wörter.

Die Dateien sind model-agnostische User-/Content-Prompts vor dem Seed-spezifischen Raw-Template.
Für einen anderen Generator können sie als normale User-Prompts verwendet werden; dann ist aber
nicht automatisch belegt, dass dessen `thinking`-/`FINAL_SUMMARY`-Verhalten dem eingefrorenen
Seed-System entspricht.

## 10. Finale Promptartefakte

| Methode | Ziel | Datei | Promptwörter ohne neuen Input | SHA-256-Präfix |
|---|---:|---|---:|---|
| Auto-CoT | 500 | `final_prompts/auto_cot_500.txt` | 9.021 | `72691048…` |
| Auto-CoT | 300 | `final_prompts/auto_cot_300.txt` | 6.070 | `19bb6492…` |
| Auto-CoT | 150 | `final_prompts/auto_cot_150.txt` | 3.533 | `35ab245a…` |
| Auto-CoT | 75 | `final_prompts/auto_cot_75.txt` | 3.328 | `feffb516…` |
| Automate-CoT | 500 | `final_prompts/automate_cot_500.txt` | 10.440 | `1ea9d184…` |
| Automate-CoT | 300 | `final_prompts/automate_cot_300.txt` | 6.626 | `bfc1df5f…` |
| Automate-CoT | 150 | `final_prompts/automate_cot_150.txt` | 4.122 | `b506203e…` |
| Automate-CoT | 75 | `final_prompts/automate_cot_75.txt` | 3.061 | `31160ebf…` |

Vollständige Hashes, geordnete Demonstrations-IDs und Quellbankhashes stehen in
`final_prompts/manifest.json`. Die zugrundeliegenden strukturierten Banken bleiben in
`auto_cot_selection/auto_cot_demonstrations.json` und
`automate_cot_selection/automate_cot_demonstrations.json` erhalten.

## 11. Validierung und Reproduzierbarkeit

Der finale Demo-Preflight bestand 104/104 Checks. Ein zusätzlicher unabhängiger Audit bestätigte
für alle 40 Demonstrationen:

- ausschließlich `train` als Herkunft;
- vier erwartete Stufen und exakt fünf eindeutige IDs je Stufe;
- bei Auto-CoT 20 stufenspezifische Demonstrationen aus 14 unterschiedlichen Ursprungsartikeln,
  wobei kein einzelner Stufenprompt einen Ursprungsartikel doppelt enthält;
- Input innerhalb des jeweils vorherigen Stufenfensters;
- Output innerhalb des Zielwortfensters;
- `word_window_success=true` und vollständiger Satzabschluss;
- nichtleerer Reasoning-Trace und nichtleere Zusammenfassung;
- bei Auto-CoT genau ein Repräsentant aus jedem Cluster 0–4;
- bei Automate-CoT die geordneten Positionen 1–5;
- acht Promptdateien mit genau fünf Demonstrationsblöcken und genau einem
  `{{NEW_INPUT}}`-Platzhalter.

Die Quellbankhashes sind:

- Auto-CoT: `7fb383b77088077fe816ab42077f28adb1ba9ce8c55561d173732c703304de75`;
- Automate-CoT: `16fd762b51a2a86d76ce42cc3191798fde21271ba57d4f8a778a7eb5a87a6f98`.

Die lokale GPU-Inferenz war trotz identischem Prompt, Seed und Modell-Digest nicht immer bitweise
deterministisch. Reproduzierbarkeit bedeutet deshalb hier: identische Konfiguration,
inhaltsadressierte Artefakte, vollständige Prompts/Outputs/Hashes und nachvollziehbare
Entscheidungsregeln—nicht die Garantie byte-identischer Neugenerierung.

## 12. Zentrale Befunde und Limitationen

1. **Stufenspezifität ist inhaltlich begründet.** Rekursive Zwischenoutputs sind keine
   austauschbaren natürlich kurzen Artikel. Separate Banken reduzieren Distribution Shift und
   widersprüchliche Längensignale.
2. **Auto-CoT liefert Diversität, aber keine Qualitätsoptimierung.** Clustering stellt semantische
   Abdeckung her; die niedrigen Silhouetten zeigen jedoch nur schwache Clustertrennung. Ein
   zentrumsnahes Beispiel ist nicht automatisch das faktentreueste.
   Die Eindeutigkeit der Demonstrationen gilt pro Stufenbank, nicht global über alle Banken;
   stufenübergreifend wiederverwendete Ursprungsartikel reduzieren die Zahl unabhängiger
   Artikelursprünge von 20 auf 14, ohne innerhalb eines einzelnen Prompts ein Duplikat zu erzeugen.
3. **Automate-CoT benötigt für Summarization eine neue Zieldefinition.** SummaC-Pruning plus
   menschliche Highlight-ROUGE-L ist transparent und vom späteren LLM-Judge getrennt, bleibt aber
   ein Proxy-Design und keine exakte Entsprechung der diskreten Originalantwortprüfung.
4. **Kurze Ziele erzeugen sparse Rewards.** Die internen Hard-valid-Raten von rund 3–4% bei 150
   und 75 Wörtern zeigen, dass Längenbefolgung die Policy-Utility stark dominiert. Das erschwert
   die Policy-Suche und sollte als Limitation berichtet werden.
5. **Metriken sind partiell.** ROUGE misst Referenzüberlappung; SummaC schätzt NLI-Konsistenz;
   keine Metrik beweist Vollständigkeit, Faktentreue oder menschliche Präferenz.
6. **q4_0-KV und ein Modell begrenzen Generalisierung.** Die Banken sind für den eingefrorenen
   Seed-Stack erzeugt. Andere Modelle oder Cachepräzisionen können anders auf dieselben
   Demonstrationen reagieren.
7. **Keine vergleichende Testwirkung behaupten.** Die 100-Artikel-Evaluation wurde ausdrücklich
   aus dem final benötigten Scope entfernt. Ein einzelnes vollständiges Auto-CoT-Testartefakt und
   partielle Checkpoints sind technische Smoke-Evidence, aber keine Wirksamkeitsstudie und dürfen
   nicht statistisch interpretiert werden.

## 13. Formulierungsvorschlag für den Methodenteil der Arbeit

> Für jeden rekursiven Kompressionsübergang (ca. 800→500, 500→300, 300→150 und 150→75 Wörter)
> wurde eine separate Fünferbank konstruiert. Auto-CoT wurde nach dem clustering-basierten Prinzip
> von Zhang et al. (2023) adaptiert: Vollständige Stufeninputs wurden mittels chunkaggregierter,
> gepinnter MiniLM-Embeddings repräsentiert, mit K-Means in fünf Gruppen geteilt und pro Cluster
> der zentrumsnächste strukturell gültige Zero-shot-CoT-Kandidat gewählt. Für das
> summarization-adaptierte Automate-CoT wurden strukturell gültige Kandidaten zunächst nach
> SummaC-Konsistenz mit dem unmittelbaren rekursiven Input gerankt und auf 100 Kandidaten je Stufe
> geprunt. Eine geordnete, duplikatfreie Fünferfolge wurde anschließend auf einem getrennten
> CNN/DailyMail-Validationssplit durch einen varianzreduzierten Policy-Gradient-Schätzer optimiert.
> Als Utility diente hard-gated, stemmed ROUGE-L gegenüber menschlichen Highlights; Ausgaben
> außerhalb des Längenfensters oder ohne vollständigen Satz erhielten Utility null. Ein
> generatives LLM-as-a-Judge wurde weder für Pruning noch für Optimierung eingesetzt, um direkte
> Judge-Optimierung zu vermeiden. Spätere Stufendemonstrationen verwendeten modellgenerierte
> rekursive Zwischenoutputs statt natürlich kurzer Artikel, um die Deployment-Verteilung
> abzubilden.

Dieser Absatz kann übernommen werden, sollte aber zusammen mit den Limitationen aus Abschnitt 12
und den exakten Modell-/Datenangaben zitiert werden.

## 14. Artefaktübersicht

- Finale Promptdateien: `final_prompts/`
- Promptmanifest: `final_prompts/manifest.json`
- Strukturierte Auto-CoT-Bank: `auto_cot_selection/auto_cot_demonstrations.json`
- Auto-CoT-Auswahlbericht: `auto_cot_selection/auto_cot_selection_report.json`
- Strukturierte Automate-CoT-Bank: `automate_cot_selection/automate_cot_demonstrations.json`
- Automate-CoT-Policybericht: `automate_cot_selection/automate_cot_selection_report.json`
- SummaC-Pruningreport und 100er-Pools: `automate_cot_pruning/`
- Vollständiger chronologischer Audit Trail: `RESEARCH_LOG.md`
- Reproduzierbare Pipelinebeschreibung: `PIPELINE.md`
- BibTeX-Quellen: `references.bib`
- Eingefrorene Daten-/Leakage-Manifeste: `data/` und `validation_splits.json`

## 15. Was ausdrücklich nicht als Ergebnis gilt

Die nach Demonstrationsabschluss begonnene 100-Artikel-Evaluation wurde am 28. August 2026 auf
ausdrücklichen Nutzerwunsch beendet, weil für den aktuellen Arbeitsschritt ausschließlich die
fertigen Demonstrationen und Prompts benötigt werden. Vorhanden sind ein vollständiges
Auto-CoT-Methodenartefakt, eine CSV-Zeile und zwei partielle Stufencheckpoints. Diese Dateien
bleiben aus Provenienzgründen erhalten, sind aber unvollständig, ungepaart und von jeder
vergleichenden Ergebnisinterpretation ausgeschlossen. Es werden insbesondere keine Aussagen
getroffen, dass Auto-CoT oder Automate-CoT bessere Zusammenfassungen erzeugt.

## 16. Nachgelagerte Pilotarchitektur: Manual-Few-shot-CoT

Für einen separaten, noch nicht ausgeführten 30-Artikel-Engineering-Pilot mit sechs Methoden wurde
researcher-curated Few-shot-CoT vorab als 2-shot CoT pro rekursiver Stufe festgelegt. Zwei Train-only-Artikel
werden jeweils als vollständige 800→500→300→150→75-Kette kuratiert. Dadurch erhält jede Stufe zwei
Input–Reasoning–Output-Demonstrationen; insgesamt sind acht Paare innerhalb von nur zwei kohärenten
Ketten zu erstellen und zu prüfen. Die Ursprünge 6853 und 7763 wurden deterministisch nach
struktureller Eignung auf allen vier Stufen und nach Ausschluss aller Auto-/Automate-Ursprünge
ausgewählt, bevor Pilotoutcomes existierten.

Diese Operationalisierung bleibt Few-shot, reduziert aber den manuellen Aufwand gegenüber fünf
unabhängigen Beispielen je Stufe erheblich. Auto-CoT und Automate-CoT behalten ihre Fünferbanken.
Die somit unterschiedliche Demonstrationszahl ist eine offenzulegende Limitation und möglicher
Konfundierungsfaktor; sie wird nicht nachträglich outcomeabhängig angeglichen. Vollständig
synthetische Ersatzketten werden nicht nachträglich erzeugt. Stattdessen dienen die bereits vor dem
Pilot vorhandenen strukturell gültigen Zero-shot-CoT-Ketten als Entwürfe, wodurch jede Ausgabe
exakt die Eingabe der Folgestufe bildet. Alle Inhalte müssen vorab menschlich auf Quellenstützung,
Wortfenster und vollständigen Satzabschluss geprüft werden. Die Methode wird deshalb ausdrücklich
als „2-shot researcher-curated Few-shot-CoT (AI-drafted, human-verified)“ und nicht als rein
menschlich verfasstes Manual-CoT dokumentiert.

Die Datenerhebung dieses Piloten erfolgt vorab festgelegt in zwei Phasen. Phase A erhebt Lead-k,
Plain, Zero-shot-CoT, Auto-CoT und Automate-CoT. Phase B ergänzt Few-shot-CoT auf denselben
Artikeln sowie einen zeitgleichen Plain-Anker zur Diagnose möglicher Backend-/Zeiteffekte. Der
Anker ist keine zusätzliche Hauptmethode und wird getrennt ausgewertet. Phase-A-Outcomes dürfen
nicht in die Few-shot-Prüfung einfließen; die gemeinsame sechsfach gepaarte Analyse bleibt bis zum
Abschluss beider Phasen gesperrt.

Nach expliziter Nutzerkorrektur gilt für den Pilot strikt ein Modellaufruf je Methode, Artikel und
Stufe. Es erfolgen keine Längenrevisionen, Inhaltswiederholungen oder Best-of-n-Auswahlen. Auch
Ausgaben außerhalb des Zielwortfensters oder ohne vollständigen Satz werden unverändert gespeichert,
markiert und rekursiv weiterverwendet. Ein kurz gestarteter Mehrversuchslauf wurde vollständig
abgebrochen und von allen Analyseartefakten isoliert; Phase A beginnt unter neuer Signatur von vorn.
Auch automatische Transportwiederholungen sind deaktiviert (`api_retries=1`); ein Infrastrukturfehler
stoppt die Erhebung, statt einen zweiten Request für dieselbe Stufe auszulösen.

Phase A wurde anschließend vollständig erhoben: 480/480 Modellaufrufe, 150/150 Methoden-Artikel-
Artefakte und 150 aggregierte Zeilen. Der finale Audit bestand 11 Checks; zusätzlich bestanden 7/7
Regressionstests. Unter dem Single-pass-Protokoll waren 28 der 600 aggregierten Methoden-Stufen leer.
Diese Fälle wurden nicht wiederholt oder ersetzt, sondern als technische Outcomes mit Wortzahl 0 und
negativen Erfolgsflags beibehalten. Eine zunächst verbliebene Validatorregel, die leere Texte ablehnte,
wurde nach der Generierung an das eingefrorene Protokoll angepasst; Modelloutputs und Ergebnisdaten
blieben unverändert.

Diese erste Single-pass-Phase-A wurde nach technischer Diagnose als superseded eingestuft. In den 240
Auto-/Automate-Stufen traten 36 harte Generationslängenabbrüche auf; 28 verdrängten den finalen
Antwortteil vollständig. Die sichtbare Reflexionsmeldung bei ungefähr 512 Tokens war nur eine weiche,
modellgenerierte Budgetkontrolle, während `num_predict=2400` Thinking und Antwort gemeinsam begrenzte.
Ein Protokollnachtrag vom 31. August 2026 erhöht deshalb für die vollständige Neudatenerhebung das
Soft-Reasoning-Budget auf 1.024 und den harten Gesamtdeckel auf 4.096 Tokens; das Reflexionsintervall
bleibt 512. Single-pass, Prompts, Demonstrationsbanken und -reihenfolgen, Daten, Modell, Sampling und
alle Wortfenster bleiben unverändert. Alte und neue Phase-A-Ergebnisse dürfen nicht gepoolt werden.
Der vollständige Ersatzlauf begann nach 8/8 Regressionstests und 10/10 Preflightchecks unter der neuen,
signaturgebundenen Konfiguration; die frühere Sammlung bleibt verlustfrei in einem ausdrücklich als
`superseded` benannten Verzeichnis erhalten.

Für die ergänzende Demonstrationsbedingung wurde anschließend auf Nutzerentscheidung genau eine Datei
mit vier automatisch erzeugten Beispielen eingefroren: eine zusammenhängende Train-only-Kette aus
Ursprung 6853 mit je einem Beispiel für 500, 300, 150 und 75 Wörter. Jedes Beispiel erscheint nur im
Prompt seiner Stufe. Damit ist die Bedingung trotz der historischen Kennung `few_shot_cot` technisch
stage-matched one-shot CoT und wird entsprechend berichtet. Phase B erhebt diese Bedingung gemeinsam
mit einem zeitgleichen Plain-Anker auf den 30 Pilotartikeln.

Die Pilotpipeline umfasst anschließend auch die vollständige Messkette: 20 kanonische Fragen pro
Artikel, Beantwortung aus jeder Methoden-Stufe, QA-Retention/Loss/Reference-discordance, Entity-
Retention, ROUGE, BERTScore, SummaC gegen Quelle und rekursiven Input, Längenkontrolle, numerische
Neuheit, Artikel-Bootstrap, gepaarte Kontraste, Metrikkorrelationen und Divergenzfälle. Leere
Single-pass-Ausgaben bleiben in sämtlichen Nennern: QA setzt sie deterministisch auf `NOT_FOUND`, und
die Qualitätsmetriken werden operational mit 0 plus explizitem Leerheitsindikator erfasst.

Während der nachgelagerten Fragenbeantwortung wurde zusätzlich eine rein technische
Repräsentationsabweichung des eingefrorenen QA-Modells festgestellt. Nicht auffindbare Antworten
wurden teilweise als leeres Antwortfeld mit leerem Beleg statt als literales `NOT_FOUND` serialisiert;
exakt kopierte Belegpassagen erhielten teilweise zusätzliche äußere Anführungszeichen. Beides wird
vor der formalen Validierung deterministisch kanonisiert: Die leere Antwort wird nur bei ebenfalls
leerem Support zu `NOT_FOUND`, und Quote-Wrapper werden nur entfernt, wenn der innere Text danach
exakt in der jeweiligen Summary nachweisbar ist. Malformed JSON, fehlende Schlüssel, ungültige
Confidence und tatsächlich nicht geerdete Supporttexte bleiben Fehler. Diese Amendment-Regel ändert
weder eine Summary noch eine Frage oder Retentionsdefinition und stellt keinen weiteren
Summarygenerierungsversuch dar.

Der anschließende Plausibilitätsaudit zeigte jedoch, dass GLM selbst mit dieser Normalisierung
systematisch überabstinent blieb: In einer 500-Wort-Positivkontrolle waren alle 20 gefragten Fakten
explizit vorhanden, GLM erkannte aber nur sechs und gab vierzehnmal `NOT_FOUND` aus. Dieser Lauf ist
daher vollständig als superseded ausgeschlossen; technische Restfehler werden nicht nachträglich
zu Methodenoutcomes umklassifiziert.

Für den Pilot wurde ausschließlich die QA-Rolle neu eingefroren. Der unabhängige Answerer
`thesis-qwen38-qa:v1` (Qwen3.8-27B; Digest `d80421…268b3`) erreichte auf derselben Positivkontrolle
20/20 beantwortete und exakt geerdete Einheiten im ersten Versuch. Auf der korrespondierenden
75-Wort-Negativkontrolle antwortete er sechs Fragen und setzte vierzehn auf `NOT_FOUND`; dabei wies
er auch einen Referenztoken zurück, der nur in einem sachlich anderen Kontext vorkam. Daher wird
kein einfacher Referenzstring-Match als Retentionsoverride verwendet. Seed bleibt alleiniger
Summarizer, Gemma alleiniger Fragengenerator und Qwen wird nur als Summary-QA-Answerer eingesetzt.
Persistente Schema- oder Groundingfehler bleiben weiterhin harte unvollständige Einheiten.

Zur zusätzlichen Absicherung wurde Qwen3.8 anschließend auf dem exakten historischen
10-Artikel-Benchmark ausgeführt, auf dem zuvor GLM getestet worden war. Der Vergleich umfasst je
Answerer 2.400 identische Methoden-, Artikel-, Stufen- und Frageneinheiten; beide Läufe enthalten
keine technischen Fehler. Unter demselben, symmetrisch angewandten human-kalibrierten Scorer lag
Qwens Retention bei 0,471 und GLMs bei 0,400. Die gepaarte artikelweise Bootstrap-Differenz betrug
+0,071 (95%-KI [0,055; 0,087]); zugleich sank die `NOT_FOUND`-Rate von 0,500 auf 0,432 und die
Falsch-negativ-Rate bei wörtlich vorhandener Referenz von 0,169 auf 0,090.

Diese Evidenz ist dennoch nicht einseitig: Von den 60 exakt im Benchmark enthaltenen Einheiten der
früheren Human Validation waren 54 nach Ausschluss gebundener Mehrheitsurteile vergleichbar. GLM
stimmte in 41/54 Fällen (0,759), Qwen in 39/54 Fällen (0,722) mit der menschlichen Mehrheit
überein; die gepaarte Differenz von -0,035 hatte ein 95%-KI von [-0,093; 0,044]. Das kleine, zur
Scorervalidierung gezogene Subset belegt somit keinen Human-Agreement-Vorteil für Qwen. Die Wahl
Qwens für die QA-Rolle stützt sich auf die fehlerfreie Positiv-/Negativkontrolle, das exakte
Grounding unter dem finalen Prompt und die deutlich geringere Überabstention im vollständigen
Benchmark. Der Vergleich ist ausdrücklich eine post-hoc kontrollierte Validierung und keine
prospektiv präregistrierte Modellauswahl.

## Ergebnis des vollständigen 30-Artikel-Piloten

Der technische Pilot wurde vollständig über 30 Artikel, sechs Methoden und vier rekursive
Kompressionsstufen ausgeführt. Damit liegen 720 Summaryeinheiten vor. Jeder generative
Methoden-Artikel-Stufen-Fall verwendete genau einen Summaryaufruf; insbesondere gab es keine
Längenrevisionen, Qualitätsretries oder Best-of-n-Auswahl. Auf Artikelebene wurden 20 gemeinsame,
quellgeerdete kanonische Fragen erzeugt. Jede Frage wurde anschließend auf den 24 passenden
Methoden-Stufen-Summaries ihres Artikels geprüft. Das ergibt 14.400 vorgesehene QA-Einheiten.

Qwen lieferte für 14.340 Einheiten eine Antwortrepräsentation, deren Support das strikte Gate eines
exakten zusammenhängenden Summaryspans bestand. Bei 60 Einheiten (0,42 %) blieb nach allen drei
vorab konfigurierten technischen Seeds ein Supporttext zurück, der paraphrasiert, durch
Auslassungszeichen verkürzt oder anderweitig nicht bytegenau in der Summary enthalten war. Diese
60 Fälle wurden nicht nachträglich als Verlust, Retention oder referenzabweichende Antwort
interpretiert. Nach Abschluss der Erhebung und vor Einsicht in Methodenoutcomes wurde eine als
post-hoc gekennzeichnete Missing-Data-Regel ergänzt: Complete-Case-Punktschätzer auf den 14.340
validen Einheiten sowie Sensitivitätsgrenzen, die sämtliche fehlenden Retentionswerte einmal auf
null und einmal auf eins setzen.

Die artikel-stufen-gewichtete QA-Retention betrug 0,407 für Lead-k, 0,490 für Plain, 0,534 für
Zero-shot-CoT, 0,508 für die vierteilige AI-generierte Bank mit jeweils einer stufengleichen
Demonstration, 0,531 für Auto-CoT und 0,538 für Automate-CoT. Die jeweiligen
All-missing-zero/All-missing-one-Grenzen waren 0,407–0,408, 0,487–0,493, 0,532–0,536,
0,505–0,510, 0,528–0,533 und 0,535–0,540. Die geringe Breite zeigt, dass die 0,42 % technische
Missingness die deskriptiven Gesamtwerte nur wenig verschieben kann; sie hebt jedoch nicht das
Risiko selektiver Missingness auf.

Automate-CoT hatte deskriptiv die höchste Retention, zugleich aber nur 0,050
Wortfenster-Erfüllung und mit 0,108 die höchste Leeroutputrate. Auto-CoT erreichte 0,083
Wortfenster-Erfüllung und 0,075 Leeroutputrate. Im direkten artikelgepaarten Vergleich
Automate-CoT minus Auto-CoT lagen die Retentionsdifferenzen bei +0,023 (500 Wörter), +0,024
(300), +0,007 (150) und -0,024 (75). Die 95%-Bootstrapintervalle [-0,012; 0,060],
[-0,009; 0,057], [-0,038; 0,049] und [-0,142; 0,089] umfassten jeweils null. Das Ergebnis darf
daher nicht als Beleg einer eindeutigen Überlegenheit von Automate-CoT formuliert werden. Es zeigt
vielmehr einen kleinen deskriptiven Retentionsvorteil im Gesamtaggregat bei gleichzeitig deutlich
schwächerer formaler Längenkontrolle und hoher Unsicherheit des direkten Methodenunterschieds.

Der finale Pipelineaudit bestand alle acht Anforderungsblöcke. Neben den vollständigen Summary-,
Frage- und QA-Schlüsseln prüft er die stufenspezifischen Demonstrationsprompt-Hashes, exaktes
Grounding aller 14.340 analysierten Antworten, die unveränderte deterministische Verlustregel für
leere Summaries, die 60 ausschließlich als Missing Values repräsentierten Einheiten und sämtliche
Bootstrap-, Korrelations-, Sensitivitäts- und Manifestdateien. Der maschinenlesbare Hauptbericht
liegt unter `experiments/six_method_pilot_30/qa_report/PILOT_REPORT.md`.

## Explorative Automate-CoT-Ablation des Thinking-Modus

Nach dem Pilot wurde auf den ersten fünf Artikeln explorativ geprüft, ob dieselben
Automate-CoT-Demonstrationen bei deaktiviertem Seed-Thinking stabilere Ausgaben erzeugen. Vor den
neuen Outputs wurden Artikel, Parameter und Auswertung festgelegt. Modell/Digest, Seed, Sampling,
Token- und Kontextbudget, Single-pass-Regel, Promptschablone und Demonstrationsbank blieben
unverändert; nur der rohe Wrapper wechselte von `cot=True` zu `cot=False`. Die vollständigen
500-Wort-Prompts waren in 5/5 Paaren byteidentisch. Spätere Prompttexte unterschieden sich nur
aufgrund des jeweils rekursiv erzeugten vorherigen Outputs.

No-thinking erhöhte die Wortfenstertreffer lediglich von 1/20 auf 2/20. Der mittlere absolute
relative Wortfehler sank jedoch von 0,385 auf 0,316 (explorative gepaarte Differenz -0,069;
95%-Bootstrapintervall [-0,103; -0,042]). Der stärkste Effekt war technisch: Die Thinking-Baseline
hatte drei `done_reason=length`-Abbrüche und drei leere Outputs, während No-thinking 20/20 reguläre
Stopps, keine leeren Ausgaben und 20/20 vollständige Satzenden erreichte. Die exakte Längenkontrolle
blieb trotzdem ungelöst; sämtliche fünf 75-Wort-Ausgaben waren ohne Thinking zu lang und enthielten
im Mittel 122,8 Wörter.

QA-Retention lag bei 0,498 mit und 0,522 ohne Thinking. Die gepaarte Differenz +0,023 war mit einem
95%-Intervall von [-0,034; 0,080] nicht eindeutig. Höhere ROUGE-L-, BERTScore- und SummaC-Werte
ohne Thinking werden teilweise dadurch erklärt, dass die drei leeren Thinking-Ausgaben jeweils
null erhielten. Wegen nur fünf Artikeln, post-hoc Design und nicht zeitgleicher Erhebung der
Thinking-Baseline ist dies keine neue Hauptergebnisschätzung. Die Ablation zeigt lediglich, dass
deaktiviertes Thinking Abbrüche verhindert und den durchschnittlichen Längenfehler reduziert, aber
allein keine zuverlässige ±5%-Wortfenstersteuerung herstellt. Ein belastbarer Protokollwechsel
erfordert einen zeitgleich interleavten Kalibrierungslauf auf bislang ungenutzten Artikeln.

## Explorative Automate-CoT-Ablation mit bedingter Längenrevision

Auf denselben fünf Artikeln wurde anschließend geprüft, ob genau eine informierte Revision nach
einem Wortfensterfehler die Längenkontrolle repariert. Vor der Generierung wurde festgelegt: Der
zweite Prompt nennt Zielintervall und gezählte Wörter des ersten Outputs; die Revision wird immer
übernommen und speist die nächste rekursive Stufe. Ein passender Erstoutput wird nicht erneut
aufgerufen. Es gibt weder Best-of-Auswahl noch einen weiteren Versuch. Die unrevidierten
Vergleichsausgaben stammen aus den bestehenden Ablationsläufen und wurden nicht contemporaneous
neu erzeugt.

Die Wortfenstertreffer lagen bei 1/20 für Thinking, 2/20 für No-thinking und jeweils 4/20 für
Thinking+Revision sowie No-thinking+Revision. Thinking+Revision benötigte 38 Summaryaufrufe und
rettete 2/18 verfehlte Erstoutputs; No-thinking+Revision benötigte 37 Aufrufe und rettete 1/17.
Damit führten nur 3/35 zielgerichtete Revisionen (8,6 %) einen vorherigen Fehltreffer ins Fenster.
Der absolute relative Wortfehler sank gegenüber der jeweiligen unrevidierten Variante von 0,385
auf 0,291 beziehungsweise von 0,316 auf 0,293. Eine einmalige Längenrevision verbessert das
Aggregat somit leicht, stellt aber mit weiterhin 80 % Fehltreffern keine zuverlässige Lösung dar.

No-thinking erwies sich erneut als technisch stabiler. Beide No-thinking-Bedingungen hatten weder
leere Outputs noch Längenabbrüche und endeten in 20/20 Fällen mit vollständigem Satz;
Thinking+Revision behielt einen leeren Output und drei `done_reason=length`-Abbrüche. Die
QA-Retention betrug in der Reihenfolge Thinking, No-thinking, Thinking+Revision und
No-thinking+Revision 0,498, 0,522, 0,556 und 0,477. Der höchste deskriptive Wert gehört damit
Thinking+Revision, doch die Richtung kehrt sich ohne Thinking um. Bei nur fünf post-hoc Artikeln,
historischen Baselines, unterschiedlichen realisierten Längen und rekursiv divergierenden
Folgeinputs lässt sich daraus weder ein stabiler Revisionseffekt noch ein Gesamtsieger ableiten.

Das Experiment bestätigt daher die Skepsis gegenüber Retry-Lösungen: Selbst der stärkere Fall
eines nicht identischen, wortzahl-informierten Korrekturprompts rettete nur 8,6 % der verfehlten
Erstausgaben. Für ein belastbares Hauptexperiment sollten Revisionen nicht nachträglich als
Standard eingeführt werden. Falls strikte ±5%-Konformität ein primäres Ziel bleibt, ist eine andere
Längensteuerungsarchitektur beziehungsweise eine separat und prospektiv kalibrierte Intervention
nötig. Der Abschlussaudit bestand für 80 Stufeneinheiten und 1.600 QA-Einheiten; sämtliche
Artefakte liegen unter `experiments/automate_revision_ablation_5/`.

## Explorative Delta-informierte direkte Editing-Ablation

Eine weitere, vor der neuen Generierung eingefrorene Ablation prüfte auf den Pilotartikeln 6–10
eine stärkere Revision: Nach einem Fehltreffer erhielt das Modell sowohl Quelle und vorherige
Summary als auch deren deterministisch gemessene Wortzahl und die explizite Zahl zu entfernender
oder hinzuzufügender Wörter. Alle vier Bedingungen wurden neu erzeugt und artikelweise in der
Reihenfolge rotiert. Da die Intervention nach Einsicht in den Hauptpiloten entwickelt wurde und die
Artikel Teil dieses Piloten waren, ist die Analyse trotz vorab eingefrorener Ausführungsregel
post-hoc explorativ und keine unabhängige Holdout-Bestätigung.

Thinking, No-thinking, Thinking+Delta-Editing und No-thinking+Delta-Editing erzielten 1/20, 1/20,
6/20 und 2/20 Fenstertreffer. Nur 4/36 ausgelöste Edits retteten einen Miss. Der scheinbar größere
Fenstergewinn mit Thinking ging mit vier leeren Outputs, fünf Längenabbrüchen, einem Anstieg des
absoluten relativen Wortfehlers von 0,345 auf 0,443, einem SummaC-Rückgang von 0,273 auf 0,218 und
einem QA-Rückgang von 0,550 auf 0,416 einher. Ohne Thinking sank der Wortfehler moderat von 0,328
auf 0,283, aber die Fensterquote stieg nur um einen Fall; QA sank von 0,596 auf 0,562.

Die Intervention liefert damit keinen belastbaren praktischen Gewinn. Selbst explizite
Wortdifferenz plus direkte Bearbeitung erzeugt keine zuverlässige ±5%-Konformität und kann mit
Thinking die technische Stabilität sowie Inhaltsqualität verschlechtern. Zusätzlich waren
byteidentische Erststufenprompts trotz identischem Seed nicht durchgehend ausgabedeterministisch;
bei `n=5` und rekursiv divergierenden Folgeinputs bleibt die Effektattribution unsicher. Der
bestandene Audit umfasst 80 Stufeneinheiten und 1.600 QA-Einheiten. Das Delta-Editing sollte nicht
in das Hauptexperiment aufgenommen werden; die vollständigen Artefakte liegen unter
`experiments/automate_delta_edit_ablation_5/`.

## Prospektive Inferenzentscheidung und graduelle Längenmetrik

Für ein nachfolgendes Hauptexperiment wird Automate-CoT deshalb mit deaktiviertem rohem
Thinking-Wrapper und ohne Revision eingesetzt. Jede Stufe behält ihren einzigen Erstoutput und
reicht ihn rekursiv weiter. Diese prospektive Engineeringentscheidung stützt sich auf die in beiden
kleinen Ablationen konsistent bessere technische Stabilität von No-thinking, nicht auf nachgewiesene
universelle Qualitätsüberlegenheit. Sie verändert den abgeschlossenen Pilot nicht und gilt nicht
automatisch für Auto-CoT, da dort keine entsprechende Inferenzablation durchgeführt wurde.

Da binäre ±5%-Erfüllung kleine und große Verfehlungen gleich behandelt, wird sie durch eine primäre
kontinuierliche Fensterdistanz ergänzt:

`word_window_violation_rate = max(accepted_min − actual, actual − accepted_max, 0) / target`.

Der Wert ist für jede zulässige Ausgabe null und wächst proportional zur Entfernung vom nächsten
Fensterrand; kleiner ist besser. Zusätzlich werden die absolute Zielabweichung in Wörtern und deren
target-normalisierte Form berichtet. Damit wird beispielsweise eine Abweichung um 30 Wörter besser
bewertet als eine Abweichung um 200 Wörter, ohne die vier unterschiedlich großen Zielstufen
unvergleichbar zu machen. Leere Outputs bleiben mit deterministisch berechnetem Fehler im Nenner.

Die nicht-mutierende Nachberechnung für alle 720 Pilotstufen ergab mittlere normalisierte
Fensterverletzungen von 0,000 für Lead-k, 0,179 für Zero-shot-CoT, 0,216 für Plain, 0,299 für die
stage-matched AI-Beispielbedingung, 0,342 für Auto-CoT und 0,368 für Automate-CoT. Diese Werte sind
deskriptive Längenmetriken, keine kombinierte Gesamtqualitätswertung; Inhaltsqualität und Retention
bleiben separat zu berichten. Vollständige Definitionen, Stufenwerte und artikelgeclusterte
Bootstrapintervalle liegen unter `experiments/six_method_pilot_30/length_adherence/`.

## Prospektive 5-shot-Few-Shot-CoT-Bank

Am 3. September 2026 wurde eine vom Forscher bereitgestellte kombinierte Textdatei als neue
5-shot-Few-Shot-CoT-Bedingung für ein späteres Hauptexperiment eingefroren. Daraus entstanden vier
direkt ausführbare Prompts für 500, 300, 150 und 75 Wörter. Jeder enthält fünf geordnete
Input–Reasoning–Output-Demonstrationen und genau einen Laufzeitplatzhalter. Damit ist die neue
Bedingung terminologisch echtes Few-shot-CoT und unterscheidet sich von der historischen
stage-matched One-shot-Bedingung des abgeschlossenen 30-Artikel-Piloten.

Alle 20 Zieltexte erfüllen ihr ±5%-Wortfenster und enden mit einem vollständigen Satz. Die fünf
Ursprungstexte sind unterschiedliche CNN/DailyMail-Trainartikel (Indizes 17748, 7253, 4963, 8496
und 9633), die per Artikelhash von Selection-Validation, finalem 100er-Test und Pilotartikeln
disjunkt sind. Innerhalb jeder Kette ist jeder Output bytegenau der Input der Folgestufe. Die
strukturierte Bank, ein separates Manifest und die gemeinsamen finalen Promptmetadaten binden alle
Artefakte und Reihenfolgen per SHA-256; ein Laufzeit-Renderer prüft die eingefrorenen Hashes vor
dem Einsetzen neuer Artikel.

Die Promptinstruktion verlangt sichtbares schrittweises Reasoning und nennt Entitäten,
Zeitbezüge, Ereignisse, Kausalbezüge und Wortbudgetpriorisierung als Analyseschritte. Dies ist eine
offenzulegende Eigenschaft des Methodenpakets und keine neutrale, ungeführte Demonstrationswirkung.
Die technische Validierung bestätigt Struktur, Länge, Rekursion, Herkunft und Splittrennung, aber
nicht Urheberschaft oder unabhängige faktische Prüfung. Entsprechend wird die Bank als
`user_supplied_frozen` und nicht als nachweislich human-written oder human-verified bezeichnet.
Sie ist prospektiv eingefroren, verändert keinerlei Pilotresultat und startet noch keinen neuen
100-Artikel-Lauf.

## Gemeinsame No-thinking-Hülle und Few-Shot-Funktionstest

Für das künftige Hauptexperiment wurde anschließend explizit festgelegt, dass Few-Shot-CoT,
Auto-CoT und Automate-CoT sämtlich mit dem Seed-Raw-Wrapper `cot=False`, Single-pass und ohne
Revision ausgeführt werden. Das vereinheitlicht die technische Laufzeithülle, nicht die
methodenspezifischen Promptinhalte. Bei Few-Shot-CoT bleibt die sichtbare Reasoning-Anweisung im
Content-Prompt erhalten; `no_thinking` entfernt nur den zusätzlichen modellinternen Raw-Think-
Modus. Die Automate-CoT-Entscheidung ist durch zwei kleine explorative Ablationen motiviert, die
Übertragung auf Auto-CoT und Few-Shot-CoT dagegen eine prospektive Paritätsentscheidung.

Ein Funktionslauf verwendete zwei bereits im Pilot untersuchte Artikel und damit keinen Artikel
des finalen 100er-Testsets. Alle acht rekursiven Einzelaufrufe waren technisch erfolgreich:
nichtleere Outputs, vollständige Satzenden, reguläres `done_reason=stop`, keine Tokenabbrüche sowie
exakt reproduzierbare Prompts und Übergaben. Die Wortzahlen waren 446/244/190/96 und
362/218/171/103. Kein Output traf das enge ±5%-Fenster; die mittlere normalisierte Fensterdistanz
betrug 0,186. Der Test bestätigt somit die Funktionsfähigkeit der Pipeline, nicht ausreichende
Längensteuerung oder eine Qualitätswirkung. Aufgrund von `n=2` wird daraus weder ein
Methodenvergleich noch eine nachträgliche Retry-Regel abgeleitet.
