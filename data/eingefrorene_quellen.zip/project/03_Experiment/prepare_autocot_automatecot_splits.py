#!/usr/bin/env python3
"""Prepare immutable, disjoint CNN/DailyMail splits for the CoT experiment."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


BASE_URL = "https://datasets-server.huggingface.co/rows"
DATASET = "abisee/cnn_dailymail"
CONFIG = "3.0.0"
FIELDS = [
    "article_id",
    "dataset",
    "config",
    "split",
    "dataset_index",
    "word_count",
    "article_sha256",
    "article",
    "highlights",
]


def now_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def count_words(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text or ""))


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def fetch_page(split: str, offset: int, length: int) -> dict:
    params = {
        "dataset": DATASET,
        "config": CONFIG,
        "split": split,
        "offset": offset,
        "length": length,
    }
    request = Request(
        f"{BASE_URL}?{urlencode(params)}",
        headers={"User-Agent": "autocot-automatecot-thesis-experiment/1.0"},
    )
    with urlopen(request, timeout=90) as response:
        return json.loads(response.read().decode("utf-8"))


def cached_parquet_paths(cache_dir: Path, split: str) -> list[Path]:
    resolved: list[tuple[str, Path]] = []
    for metadata_path in cache_dir.glob("*.json"):
        try:
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        url = str(metadata.get("url") or "")
        if f"/{split}-" not in url or not url.endswith(".parquet"):
            continue
        data_path = metadata_path.with_suffix("")
        if data_path.exists():
            resolved.append((url, data_path))
    return [path for _, path in sorted(resolved)]


def collect_local(
    *,
    cache_dir: Path,
    split: str,
    count: int,
    min_words: int,
    max_words: int,
    start_offset: int,
    max_offset: int,
) -> tuple[list[dict[str, str]], dict[str, object]]:
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise RuntimeError(
            "Local-cache mode requires pyarrow; run this script with the project .venv Python"
        ) from exc

    paths = cached_parquet_paths(cache_dir, split)
    if not paths:
        raise RuntimeError(f"No cached parquet shards found for split={split} in {cache_dir}")

    selected: list[dict[str, str]] = []
    selected_hashes: set[str] = set()
    global_index = 0
    rows_seen = 0
    for parquet_path in paths:
        table = pq.read_table(parquet_path, columns=["article", "highlights"])
        articles = table.column("article").to_pylist()
        highlights_list = table.column("highlights").to_pylist()
        for article_value, highlights_value in zip(articles, highlights_list):
            dataset_index = global_index
            global_index += 1
            if dataset_index < start_offset:
                continue
            if dataset_index > max_offset:
                break
            rows_seen += 1
            article = str(article_value or "").strip()
            highlights = str(highlights_value or "").strip()
            words = count_words(article)
            if article and highlights and min_words <= words <= max_words:
                article_hash = sha256_text(article)
                if article_hash in selected_hashes:
                    continue
                selected_hashes.add(article_hash)
                selected.append(
                    {
                        "article_id": str(len(selected) + 1),
                        "dataset": DATASET,
                        "config": CONFIG,
                        "split": split,
                        "dataset_index": str(dataset_index),
                        "word_count": str(words),
                        "article_sha256": article_hash,
                        "article": article,
                        "highlights": highlights,
                    }
                )
                print(
                    f"{split}: selected {len(selected)}/{count}, "
                    f"dataset_index={dataset_index}, words={words}",
                    flush=True,
                )
                if len(selected) == count:
                    return selected, {
                        "mode": "local_cached_parquet",
                        "start_offset": start_offset,
                        "last_dataset_index": dataset_index,
                        "rows_seen": rows_seen,
                        "parquet_paths": [str(path) for path in paths],
                    }
        if global_index > max_offset:
            break
    raise RuntimeError(
        f"{split}: found {len(selected)} of {count} requested local articles in "
        f"[{min_words}, {max_words}] words while scanning indices "
        f"{start_offset}..{max_offset}"
    )


def collect(
    *,
    split: str,
    count: int,
    min_words: int,
    max_words: int,
    start_offset: int,
    max_offset: int,
    page_size: int,
    sleep_seconds: float,
) -> tuple[list[dict[str, str]], dict[str, int]]:
    selected: list[dict[str, str]] = []
    selected_hashes: set[str] = set()
    offset = start_offset
    rows_seen = 0
    pages_read = 0
    while len(selected) < count and offset <= max_offset:
        payload = fetch_page(split, offset, page_size)
        pages_read += 1
        page_rows = payload.get("rows") or []
        if not page_rows:
            break
        for wrapped in page_rows:
            rows_seen += 1
            row = wrapped.get("row") or {}
            article = (row.get("article") or "").strip()
            highlights = (row.get("highlights") or "").strip()
            words = count_words(article)
            if article and highlights and min_words <= words <= max_words:
                article_hash = sha256_text(article)
                if article_hash in selected_hashes:
                    continue
                selected_hashes.add(article_hash)
                selected.append(
                    {
                        "article_id": str(len(selected) + 1),
                        "dataset": DATASET,
                        "config": CONFIG,
                        "split": split,
                        "dataset_index": str(wrapped.get("row_idx")),
                        "word_count": str(words),
                        "article_sha256": article_hash,
                        "article": article,
                        "highlights": highlights,
                    }
                )
                print(
                    f"{split}: selected {len(selected)}/{count}, "
                    f"dataset_index={wrapped.get('row_idx')}, words={words}",
                    flush=True,
                )
                if len(selected) == count:
                    break
        offset += page_size
        if sleep_seconds:
            time.sleep(sleep_seconds)
    if len(selected) != count:
        raise RuntimeError(
            f"{split}: found {len(selected)} of {count} requested articles in "
            f"[{min_words}, {max_words}] words while scanning offsets "
            f"{start_offset}..{max_offset}"
        )
    return selected, {
        "start_offset": start_offset,
        "last_page_offset": offset - page_size,
        "rows_seen": rows_seen,
        "pages_read": pages_read,
    }


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--candidate-count", type=int, default=130)
    parser.add_argument("--validation-count", type=int, default=30)
    parser.add_argument("--test-count", type=int, default=100)
    parser.add_argument("--min-words", type=int, default=795)
    parser.add_argument("--max-words", type=int, default=805)
    parser.add_argument("--train-start-offset", type=int, default=3000)
    parser.add_argument("--max-offset", type=int, default=100000)
    parser.add_argument("--page-size", type=int, default=100)
    parser.add_argument("--sleep-seconds", type=float, default=0.05)
    parser.add_argument(
        "--local-cache-dir",
        help="Read revision-pinned cached Parquet shards here instead of the Dataset Viewer API.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 1 <= args.page_size <= 100:
        raise SystemExit("--page-size must be between 1 and 100")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    specs = [
        ("candidate_train", "train", args.candidate_count, args.train_start_offset),
        ("selection_validation", "validation", args.validation_count, 0),
        ("final_test_100", "test", args.test_count, 0),
    ]
    files: list[dict[str, object]] = []
    all_hashes: dict[str, str] = {}
    for name, split, count, start_offset in specs:
        if args.local_cache_dir:
            rows, scan = collect_local(
                cache_dir=Path(args.local_cache_dir),
                split=split,
                count=count,
                min_words=args.min_words,
                max_words=args.max_words,
                start_offset=start_offset,
                max_offset=args.max_offset,
            )
        else:
            rows, scan = collect(
                split=split,
                count=count,
                min_words=args.min_words,
                max_words=args.max_words,
                start_offset=start_offset,
                max_offset=args.max_offset,
                page_size=args.page_size,
                sleep_seconds=args.sleep_seconds,
            )
        path = output_dir / f"{name}.csv"
        write_csv(path, rows)
        for row in rows:
            article_hash = row["article_sha256"]
            if article_hash in all_hashes:
                raise RuntimeError(
                    f"Article leakage: {name} duplicates {all_hashes[article_hash]} "
                    f"({article_hash})"
                )
            all_hashes[article_hash] = name
        files.append(
            {
                "role": name,
                "split": split,
                "count": len(rows),
                "path": str(path),
                "sha256": sha256_file(path),
                "dataset_indices": [int(row["dataset_index"]) for row in rows],
                "scan": scan,
            }
        )

    manifest = {
        "created_at_utc": now_utc(),
        "dataset": DATASET,
        "config": CONFIG,
        "selection_rule": {
            "min_words_inclusive": args.min_words,
            "max_words_inclusive": args.max_words,
            "requires_nonempty_highlights": True,
            "order": "ascending dataset row index from the declared start offset",
        },
        "leakage_check": "no duplicate SHA-256 article text across the three files",
        "files": files,
    }
    manifest_path = output_dir / "split_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote immutable split manifest: {manifest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
