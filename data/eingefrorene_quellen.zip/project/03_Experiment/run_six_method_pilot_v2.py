#!/usr/bin/env python3
"""Restartable single-pass summary generation for the frozen six-method v2 pilot."""

from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from all_loaded_models_microtest import seed_raw
from iterative_summarize import bounds_for_target, count_words, extract_text, extract_thinking, ollama_generate


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "experiments/six_method_pilot_30_v2"
INPUT = PROJECT / "data/pilot_validation_30.csv"
PROMPT_PROJECT = ROOT / "experiments/autocot_automatecot_100"
PROMPT_MANIFEST = PROMPT_PROJECT / "final_prompts/manifest.json"
OUT = PROJECT / "run"
TARGETS = (500, 300, 150, 75)
METHODS = ("lead_k", "plain", "zero_shot_cot", "few_shot_cot", "auto_cot", "automate_cot")
GENERATIVE_METHODS = METHODS[1:]
RAW_WRAPPER_COT = {
    "plain": False,
    "zero_shot_cot": True,
    "few_shot_cot": False,
    "auto_cot": False,
    "automate_cot": False,
}
MODEL = "thesis-seed:v1"
MODEL_DIGEST = "7a66a2f466bf48fdafa7004a7975a7f5fac6e667a6de7d01751aacb98b3f387c"
SEED = 32
TEMPERATURE = 1.1
TOP_P = 0.95
REPEAT_PENALTY = 1.0
NUM_CTX = 524288
NUM_PREDICT = 4096
REASONING_BUDGET = 1024
REFLECTION_INTERVAL = 512
HOST = "127.0.0.1:11435"


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_json_atomic(path: Path, payload: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def append_jsonl_durable(path: Path, payload: Any) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def complete_sentence(text: str) -> bool:
    return bool(re.search(r'[.!?]["\'\)\]”’»›]*\s*$', (text or "").strip()))


def lead_k(text: str, target: int) -> str:
    matches = list(re.finditer(r"\b\w+\b", text or ""))
    if len(matches) <= target:
        return (text or "").strip()
    return text[: matches[target - 1].end()].strip()


def method_order(position: int) -> list[str]:
    shift = (position - 1) % len(GENERATIVE_METHODS)
    return list(GENERATIVE_METHODS[shift:] + GENERATIVE_METHODS[:shift])


def direct_prompt(text: str, target: int, cot: bool) -> str:
    low, high = bounds_for_target(target, 5.0)
    reasoning = " Think step by step before the final answer." if cot else ""
    return (
        f"Task: Summarize the new input in approximately {target} words.{reasoning}\n"
        f"The accepted length interval is {low}-{high} words. Preserve the most important facts "
        "supported by the new input, do not invent facts, and end with a complete sentence.\n"
        "Output plain prose only after the exact label FINAL_SUMMARY:. Do not put text after it.\n\n"
        f"NEW INPUT:\n{text.strip()}"
    )


def load_prompt_manifest() -> dict[str, Any]:
    return json.loads(PROMPT_MANIFEST.read_text(encoding="utf-8"))


def resolve_prompt_path(stored_path: str) -> Path:
    path = Path(stored_path)
    return ROOT / path if path.parts and path.parts[0] == "experiments" else PROMPT_PROJECT / path


def demonstration_prompt(method: str, text: str, target: int, manifest: dict[str, Any]) -> str:
    stage = manifest["methods"][method]["stages"][str(target)]
    path = resolve_prompt_path(stage["path"])
    if sha256_file(path) != stage["sha256"]:
        raise RuntimeError(f"prompt hash mismatch: {path}")
    template = path.read_text(encoding="utf-8")
    if template.count("{{NEW_INPUT}}") != 1:
        raise RuntimeError(f"expected one placeholder: {path}")
    return template.replace("{{NEW_INPUT}}", text.strip(), 1)


def prompt_for(method: str, text: str, target: int, manifest: dict[str, Any]) -> str:
    if method == "plain":
        return direct_prompt(text, target, False)
    if method == "zero_shot_cot":
        return direct_prompt(text, target, True)
    return demonstration_prompt(method, text, target, manifest)


def run_stage(method: str, source: str, target: int, manifest: dict[str, Any], run_signature: str, article_key: str) -> dict[str, Any]:
    prompt = prompt_for(method, source, target, manifest)
    cot = RAW_WRAPPER_COT[method]
    started = time.monotonic()
    raw = ollama_generate(
        model=MODEL,
        prompt=seed_raw(prompt, cot, reflection_interval=REFLECTION_INTERVAL, thinking_budget=REASONING_BUDGET),
        host=HOST,
        temperature=TEMPERATURE,
        top_p=TOP_P,
        repeat_penalty=REPEAT_PENALTY,
        seed=SEED,
        num_ctx=NUM_CTX,
        keep_alive="30m",
        num_predict=NUM_PREDICT,
        raw=True,
        timeout=1800,
    )
    response = extract_text(raw).strip()
    thinking = extract_thinking(raw).strip()
    words = count_words(response)
    low, high = bounds_for_target(target, 5.0)
    attempt = {
        "attempt_index": 1,
        "sampling_seed": SEED,
        "prompt_sha256": sha256_text(prompt),
        "raw_wrapper_cot": cot,
        "response": response,
        "thinking": thinking,
        "response_word_count": words,
        "word_window_success": low <= words <= high,
        "word_window_violation_words": max(low - words, words - high, 0),
        "word_window_violation_rate": max(low - words, words - high, 0) / target,
        "ends_with_complete_sentence": complete_sentence(response),
        "done_reason": raw.get("done_reason"),
        "eval_count": raw.get("eval_count"),
        "latency_seconds": time.monotonic() - started,
    }
    append_jsonl_durable(
        OUT / "attempts.jsonl",
        {"run_signature": run_signature, "article_key": article_key, "method": method, "target_words": target, **attempt},
    )
    return {
        "target_words": target,
        "input_text": source,
        "input_word_count": count_words(source),
        "selected_attempt_index": 1,
        "selection_reason": "single-pass output; no retry or selection",
        "selected": attempt,
        "attempts": [attempt],
    }


def main() -> int:
    with INPUT.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 30:
        raise RuntimeError("expected exactly 30 frozen pilot rows")
    manifest = load_prompt_manifest()
    OUT.mkdir(parents=True, exist_ok=True)
    for method in METHODS:
        (OUT / "articles" / method).mkdir(parents=True, exist_ok=True)
    configuration = {
        "status": "frozen before generation",
        "input_sha256": sha256_file(INPUT),
        "input_rows": 30,
        "methods": list(METHODS),
        "model": MODEL,
        "model_digest": MODEL_DIGEST,
        "seed": SEED,
        "temperature": TEMPERATURE,
        "top_p": TOP_P,
        "repeat_penalty": REPEAT_PENALTY,
        "num_ctx": NUM_CTX,
        "num_predict": NUM_PREDICT,
        "reasoning_budget_zero_shot_only": REASONING_BUDGET,
        "reflection_interval_zero_shot_only": REFLECTION_INTERVAL,
        "raw_wrapper_cot": RAW_WRAPPER_COT,
        "single_pass": True,
        "revision": False,
        "best_of": False,
        "automatic_transport_retry": False,
        "targets": list(TARGETS),
        "tolerance_pct": 5.0,
        "prompt_manifest_sha256": sha256_file(PROMPT_MANIFEST),
        "order_protocol": "five-method cyclic rotation; each generative method occurs exactly six times in every slot",
    }
    run_signature = sha256_text(json.dumps(configuration, sort_keys=True))
    collection_manifest = OUT / "collection_manifest.json"
    if collection_manifest.exists():
        old = json.loads(collection_manifest.read_text(encoding="utf-8"))
        if old["run_signature"] != run_signature:
            raise RuntimeError("incompatible existing v2 run directory")
    else:
        write_json_atomic(collection_manifest, {"created_at_utc": now(), "run_signature": run_signature, **configuration})

    total_calls = len(rows) * len(GENERATIVE_METHODS) * len(TARGETS)
    completed_before = 0
    for position, source in enumerate(rows, 1):
        key = f"validation__{source['dataset_index']}"
        lead_path = OUT / "articles/lead_k" / f"{key}.json"
        if not lead_path.exists():
            current = source["article"].strip()
            stages = []
            for target in TARGETS:
                response = lead_k(current, target)
                low, high = bounds_for_target(target, 5.0)
                words = count_words(response)
                selected = {
                    "response": response,
                    "thinking": "",
                    "response_word_count": words,
                    "word_window_success": low <= words <= high,
                    "word_window_violation_words": max(low - words, words - high, 0),
                    "word_window_violation_rate": max(low - words, words - high, 0) / target,
                    "ends_with_complete_sentence": complete_sentence(response),
                }
                stages.append({"target_words": target, "input_text": current, "input_word_count": count_words(current), "selected": selected, "attempts": [selected]})
                current = response
            write_json_atomic(lead_path, {"complete": True, "run_signature": run_signature, "method": "lead_k", "source_sha256": source["article_sha256"], "stages": stages})

        for method in method_order(position):
            path = OUT / "articles" / method / f"{key}.json"
            stages: list[dict[str, Any]] = []
            if path.exists():
                existing = json.loads(path.read_text(encoding="utf-8"))
                if existing.get("run_signature") != run_signature or existing.get("source_sha256") != source["article_sha256"]:
                    raise RuntimeError(f"resume provenance mismatch: {path}")
                stages = existing.get("stages", [])
                if existing.get("complete") is True:
                    completed_before += 4
                    continue
                if [stage["target_words"] for stage in stages] != list(TARGETS[: len(stages)]):
                    raise RuntimeError(f"invalid partial stage order: {path}")
            current = stages[-1]["selected"]["response"] if stages else source["article"].strip()
            for target in TARGETS[len(stages):]:
                stage = run_stage(method, current, target, manifest, run_signature, key)
                stages.append(stage)
                current = stage["selected"]["response"]
                write_json_atomic(path, {"complete": False, "run_signature": run_signature, "method": method, "source_sha256": source["article_sha256"], "stages": stages})
                completed_now = completed_before + sum(
                    len(json.loads(p.read_text(encoding="utf-8")).get("stages", []))
                    for p in (OUT / "articles").glob("*/*.json")
                    if p.parent.name != "lead_k"
                )
                print(
                    f"PROGRESS {completed_now}/{total_calls} article={position}/30 method={method} "
                    f"stage={target} words={stage['selected']['response_word_count']} "
                    f"window={stage['selected']['word_window_success']} done={stage['selected']['done_reason']} "
                    f"latency={stage['selected']['latency_seconds']:.1f}s",
                    flush=True,
                )
            write_json_atomic(path, {"complete": True, "run_signature": run_signature, "method": method, "source_sha256": source["article_sha256"], "stages": stages})

    artifacts = [json.loads(path.read_text(encoding="utf-8")) for path in (OUT / "articles").glob("*/*.json")]
    counts = Counter(artifact["method"] for artifact in artifacts if artifact.get("complete"))
    write_json_atomic(OUT / "completion.json", {"completed_at_utc": now(), "complete_articles_by_method": counts, "expected_articles_by_method": 30})
    print("PASS: v2 summary generation complete", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
