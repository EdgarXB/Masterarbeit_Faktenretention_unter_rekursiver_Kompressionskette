#!/usr/bin/env python3
"""Run new Plain and Few-Shot-CoT conditions on the frozen final 100 articles."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from all_loaded_models_microtest import seed_raw
from iterative_summarize import bounds_for_target, count_words, extract_text, extract_thinking, ollama_generate
from run_six_method_final_100 import (
    INPUT, MODEL, MODEL_DIGEST, NUM_CTX, NUM_PREDICT, REFLECTION_INTERVAL,
    REPEAT_PENALTY, SEED, TEMPERATURE, TOP_P, TARGETS, runtime_metadata,
)
from run_six_method_pilot_v2 import complete_sentence


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "experiments/plain_fewshot_rerun_20260930"
PLAIN_TEMPLATE_PATH = PROJECT / "plain_prompt.txt"
FEWSHOT_PACKAGE = ROOT / "experiments/few_shot_cot_shared_pool_20260930"
FEWSHOT_MANIFEST = FEWSHOT_PACKAGE / "few_shot_cot_manifest.json"
OUT = PROJECT / "run"
HOST = "127.0.0.1:11435"
METHODS = ("plain", "few_shot_cot")


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_text(value: str) -> str:
    return sha_bytes(value.encode("utf-8"))


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def load_sources() -> list[dict[str, str]]:
    with INPUT.open(encoding="utf-8", newline="") as handle:
        sources = list(csv.DictReader(handle))
    if len(sources) != 100 or len({row["article_sha256"] for row in sources}) != 100:
        raise RuntimeError("expected exactly 100 unique final-test articles")
    if not all(sha_text(row["article"].strip()) == row["article_sha256"] for row in sources):
        raise RuntimeError("final-test article hash mismatch")
    return sources


def load_plain_template() -> str:
    template = PLAIN_TEMPLATE_PATH.read_text(encoding="utf-8").strip()
    if template != "summarize in {target_word_length}":
        raise RuntimeError(f"unexpected Plain template: {template!r}")
    return template


def load_fewshot_prompts() -> dict[int, str]:
    manifest = json.loads(FEWSHOT_MANIFEST.read_text(encoding="utf-8"))
    prompts: dict[int, str] = {}
    for target in TARGETS:
        entry = manifest["prompts"][str(target)]
        data = (FEWSHOT_PACKAGE / entry["path"]).read_bytes()
        if sha_bytes(data) != entry["sha256"]:
            raise RuntimeError(f"Few-Shot prompt hash mismatch for target={target}")
        template = data.decode("utf-8")
        if template.count("{{NEW_INPUT}}") != 1 or template.count("DEMONSTRATION ") != 5:
            raise RuntimeError(f"malformed Few-Shot prompt for target={target}")
        prompts[target] = template
    return prompts


def render_prompt(method: str, current: str, target: int, plain_template: str,
                  fewshot_prompts: dict[int, str]) -> str:
    if method == "plain":
        # The user-requested Plain instruction is kept exact. The source text is
        # appended after a blank line without labels or additional directives.
        return plain_template.format(target_word_length=target) + "\n\n" + current.strip()
    return fewshot_prompts[target].replace("{{NEW_INPUT}}", current.strip(), 1)


def parse_response(method: str, raw: dict[str, Any]) -> tuple[str, str, str]:
    full_response = extract_text(raw).strip()
    reasoning = extract_thinking(raw).strip()
    response = full_response
    if method == "few_shot_cot" and "FINAL_SUMMARY:" in full_response:
        prefix, response = full_response.rsplit("FINAL_SUMMARY:", 1)
        reasoning = (reasoning + "\n" + prefix).strip()
        response = response.strip()
    return response, reasoning, full_response


def run_one(method: str, source: dict[str, str], plain_template: str,
            fewshot_prompts: dict[int, str], signature: str) -> None:
    key = f"test__{source['dataset_index']}"
    path = OUT / "articles" / method / f"{key}.json"
    stages: list[dict[str, Any]] = []
    if path.exists():
        artifact = json.loads(path.read_text(encoding="utf-8"))
        if artifact["run_signature"] != signature or artifact["source_sha256"] != source["article_sha256"]:
            raise RuntimeError(f"resume signature/source mismatch: {path}")
        stages = artifact["stages"]
        if [stage["target_words"] for stage in stages] != list(TARGETS[:len(stages)]):
            raise RuntimeError(f"invalid stage prefix: {path}")
        if artifact.get("complete"):
            return
    current = stages[-1]["selected"]["response"] if stages else source["article"].strip()
    for target in TARGETS[len(stages):]:
        prompt = render_prompt(method, current, target, plain_template, fewshot_prompts)
        started = time.monotonic()
        raw = ollama_generate(
            model=MODEL,
            prompt=seed_raw(prompt, False, reflection_interval=REFLECTION_INTERVAL, thinking_budget=1024),
            host=HOST, temperature=TEMPERATURE, top_p=TOP_P,
            repeat_penalty=REPEAT_PENALTY, seed=SEED, num_ctx=NUM_CTX,
            keep_alive="30m", num_predict=NUM_PREDICT, raw=True, timeout=1800,
        )
        response, reasoning, full_response = parse_response(method, raw)
        words = count_words(response)
        low, high = bounds_for_target(target, 5.0)
        selected = {
            "attempt_index": 1, "sampling_seed": SEED, "temperature": TEMPERATURE,
            "prompt_sha256": sha_text(prompt), "raw_wrapper_cot": False,
            "response": response, "full_raw_response": full_response, "thinking": reasoning,
            "response_word_count": words, "thinking_word_count": count_words(reasoning),
            "word_window_success": low <= words <= high,
            "empty_output": not bool(response),
            "ends_with_complete_sentence": complete_sentence(response),
            "done_reason": raw.get("done_reason"), "eval_count": raw.get("eval_count"),
            "latency_seconds": time.monotonic() - started,
        }
        stages.append({
            "target_words": target, "input_text": current, "input_word_count": count_words(current),
            "selected_attempt_index": 1, "selection_reason": "single pass; no revision or retry",
            "selected": selected, "attempts": [selected],
        })
        write_json(path, {
            "complete": False, "run_signature": signature, "method": method,
            "source_sha256": source["article_sha256"], "stages": stages,
        })
        current = response
        print(f"{method} {key} {target}: {words} words, {selected['latency_seconds']:.1f}s", flush=True)
    write_json(path, {
        "complete": True, "run_signature": signature, "method": method,
        "source_sha256": source["article_sha256"], "stages": stages,
    })


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="store_true", help="start 800 model calls")
    args = parser.parse_args()
    sources = load_sources()
    plain_template = load_plain_template()
    fewshot_prompts = load_fewshot_prompts()
    configuration = {
        "status": "new Plain and Few-Shot rerun requested after the frozen historical run",
        "test_input_sha256": sha_bytes(INPUT.read_bytes()),
        "methods": list(METHODS),
        "plain_template": plain_template,
        "plain_template_sha256": sha_bytes(PLAIN_TEMPLATE_PATH.read_bytes()),
        "plain_rendering": "exact instruction, blank line, current recursive stage input",
        "fewshot_manifest_sha256": sha_bytes(FEWSHOT_MANIFEST.read_bytes()),
        "fewshot_prompt_sha256_by_stage": {
            str(target): sha_text(fewshot_prompts[target]) for target in TARGETS
        },
        "model": MODEL, "model_digest": MODEL_DIGEST,
        "temperature": TEMPERATURE, "seed": SEED, "top_p": TOP_P,
        "repeat_penalty": REPEAT_PENALTY, "num_ctx": NUM_CTX,
        "num_predict": NUM_PREDICT, "native_thinking": False,
        "single_pass": True, "automatic_retry": False,
        "targets": list(TARGETS),
        "two_method_order": "alternating by article; each method first for 50 articles",
    }
    signature = sha_text(json.dumps(configuration, sort_keys=True))
    protocol_path = PROJECT / "protocol.json"
    if protocol_path.exists():
        old = json.loads(protocol_path.read_text(encoding="utf-8"))
        if old["run_signature"] != signature:
            raise RuntimeError("existing protocol signature mismatch")
    else:
        write_json(protocol_path, {"created_at_utc": now(), "run_signature": signature, **configuration})
    if not args.run:
        print(json.dumps({"ready": True, "calls_if_started": 800,
                          "run_signature": signature, "configuration": configuration}, indent=2))
        return 0

    OUT.mkdir(parents=True, exist_ok=True)
    for method in METHODS:
        (OUT / "articles" / method).mkdir(parents=True, exist_ok=True)
    manifest_path = OUT / "collection_manifest.json"
    if manifest_path.exists():
        if json.loads(manifest_path.read_text(encoding="utf-8"))["run_signature"] != signature:
            raise RuntimeError("collection manifest signature mismatch")
    else:
        write_json(manifest_path, {
            "created_at_utc": now(), "run_signature": signature,
            "runtime": runtime_metadata(), **configuration,
        })
    for position, source in enumerate(sources):
        order = METHODS if position % 2 == 0 else tuple(reversed(METHODS))
        for method in order:
            run_one(method, source, plain_template, fewshot_prompts, signature)
    counts = {
        method: len(list((OUT / "articles" / method).glob("test__*.json")))
        for method in METHODS
    }
    if counts != {"plain": 100, "few_shot_cot": 100}:
        raise RuntimeError(f"unexpected artifact counts: {counts}")
    write_json(OUT / "completion.json", {
        "status": "complete", "completed_at_utc": now(), "articles_per_method": counts,
        "stages": 800, "run_signature": signature,
    })
    print("PASS: 100 Plain and 100 Few-Shot-CoT recursive article runs complete", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
