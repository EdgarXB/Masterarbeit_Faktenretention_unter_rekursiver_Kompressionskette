#!/usr/bin/env python3
import argparse
import csv
import re
import sys
from pathlib import Path


def count_words(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract articles from cnn_dailymail with a target word-count range."
    )
    parser.add_argument("--dataset", default="abisee/cnn_dailymail")
    parser.add_argument("--config", default="3.0.0")
    parser.add_argument("--split", default="train")
    parser.add_argument("--min-words", type=int, default=795)
    parser.add_argument("--max-words", type=int, default=805)
    parser.add_argument("--count", type=int, default=5)
    parser.add_argument("--output", default="selected_articles.csv")
    parser.add_argument(
        "--exclusion-registry",
        default=str(
            Path(__file__).resolve().parent
            / "salience_validation_package"
            / "data"
            / "exclusion_registry.csv"
        ),
        help="CSV registry whose matching dataset indices must not be selected.",
    )
    parser.add_argument(
        "--ignore-exclusion-registry",
        action="store_true",
        help="Ignore the registry only when reproducing a historical pre-registry selection.",
    )
    return parser.parse_args()


def load_excluded_indices(
    path: Path, dataset: str, config: str, split: str
) -> set[int]:
    if not path.exists():
        return set()
    excluded = set()
    with path.open("r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if (
                row.get("dataset") == dataset
                and row.get("dataset_version") == config
                and row.get("split") == split
                and (row.get("dataset_index") or "").isdigit()
            ):
                excluded.add(int(row["dataset_index"]))
    return excluded


def main() -> int:
    args = parse_args()

    try:
        from datasets import load_dataset
    except ImportError:
        print("Missing dependency: datasets")
        print("Install with: pip install datasets")
        return 1

    print(
        f"Loading dataset {args.dataset} (config={args.config}, split={args.split})..."
    )
    ds = load_dataset(args.dataset, args.config, split=args.split)
    excluded_indices = (
        set()
        if args.ignore_exclusion_registry
        else load_excluded_indices(
            Path(args.exclusion_registry), args.dataset, args.config, args.split
        )
    )
    if excluded_indices:
        print(
            f"Excluding {len(excluded_indices)} registered article(s) from "
            f"{args.exclusion_registry}."
        )

    rows = []
    for idx, item in enumerate(ds):
        if idx in excluded_indices:
            continue
        article = (item.get("article") or "").strip()
        if not article:
            continue

        wc = count_words(article)
        if args.min_words <= wc <= args.max_words:
            rows.append(
                {
                    "article_id": len(rows) + 1,
                    "dataset": args.dataset,
                    "config": args.config,
                    "split": args.split,
                    "dataset_index": idx,
                    "word_count": wc,
                    "article": article,
                }
            )

        if len(rows) >= args.count:
            break

    if len(rows) < args.count:
        print(
            f"Only found {len(rows)} article(s) in range "
            f"[{args.min_words}, {args.max_words}] in split={args.split}."
        )
        return 1

    fieldnames = [
        "article_id",
        "dataset",
        "config",
        "split",
        "dataset_index",
        "word_count",
        "article",
    ]

    with open(args.output, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Saved {len(rows)} article(s) to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
