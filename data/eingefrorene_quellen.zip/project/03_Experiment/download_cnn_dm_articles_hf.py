#!/usr/bin/env python3
import argparse
import csv
import json
import re
import sys
import time
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


BASE_URL = "https://datasets-server.huggingface.co/rows"


def count_words(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Download CNN/DailyMail rows from Hugging Face Dataset Viewer API and filter by word count."
    )
    parser.add_argument("--dataset", default="abisee/cnn_dailymail")
    parser.add_argument("--config", default="3.0.0")
    parser.add_argument("--split", default="train")
    parser.add_argument("--min-words", type=int, default=795)
    parser.add_argument("--max-words", type=int, default=805)
    parser.add_argument("--count", type=int, default=20)
    parser.add_argument("--page-size", type=int, default=100)
    parser.add_argument("--max-offset", type=int, default=20000)
    parser.add_argument("--sleep-seconds", type=float, default=0.1)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def fetch_rows(args: argparse.Namespace, offset: int) -> dict:
    params = {
        "dataset": args.dataset,
        "config": args.config,
        "split": args.split,
        "offset": offset,
        "length": args.page_size,
    }
    url = f"{BASE_URL}?{urlencode(params)}"
    req = Request(url, headers={"User-Agent": "ollama-autocot-demo-selector/1.0"})
    with urlopen(req, timeout=60) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> int:
    args = parse_args()
    if args.page_size < 1 or args.page_size > 100:
        print("--page-size must be between 1 and 100", file=sys.stderr)
        return 2

    rows = []
    offset = 0
    total_seen = 0
    while len(rows) < args.count and offset <= args.max_offset:
        payload = fetch_rows(args, offset)
        page_rows = payload.get("rows") or []
        if not page_rows:
            break

        for page_row in page_rows:
            total_seen += 1
            dataset_index = page_row.get("row_idx")
            item = page_row.get("row") or {}
            article = (item.get("article") or "").strip()
            if not article:
                continue
            wc = count_words(article)
            if args.min_words <= wc <= args.max_words:
                rows.append(
                    {
                        "article_id": len(rows) + 1,
                        "dataset": args.dataset,
                        "config": args.config,
                        "split": args.split,
                        "dataset_index": dataset_index,
                        "word_count": wc,
                        "article": article,
                    }
                )
                print(f"selected {len(rows)}/{args.count}: dataset_index={dataset_index} words={wc}")
                if len(rows) >= args.count:
                    break

        offset += args.page_size
        if args.sleep_seconds:
            time.sleep(args.sleep_seconds)

    if len(rows) < args.count:
        print(
            f"Only found {len(rows)} article(s) in range "
            f"[{args.min_words}, {args.max_words}] after scanning {total_seen} rows.",
            file=sys.stderr,
        )
        return 1

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "article_id",
        "dataset",
        "config",
        "split",
        "dataset_index",
        "word_count",
        "article",
    ]
    with output.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Saved {len(rows)} article(s) to {output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
