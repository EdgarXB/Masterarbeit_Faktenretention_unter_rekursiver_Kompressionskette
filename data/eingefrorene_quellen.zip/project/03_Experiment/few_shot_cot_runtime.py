#!/usr/bin/env python3
"""Load and render the frozen user-supplied Few-shot-CoT stage prompts."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "experiments/autocot_automatecot_100"
MANIFEST_PATH = PROJECT / "few_shot_cot/manifest.json"
TARGETS = (500, 300, 150, 75)
PLACEHOLDER = "{{NEW_INPUT}}"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_manifest() -> dict[str, object]:
    return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


def render_few_shot_prompt(target: int, new_input: str) -> str:
    if target not in TARGETS:
        raise ValueError(f"unsupported target {target}; expected one of {TARGETS}")
    if not new_input.strip():
        raise ValueError("NEW_INPUT must not be empty")
    manifest = load_manifest()
    stage = manifest["stages"][str(target)]
    prompt_path = ROOT / stage["path"]
    if sha256_file(prompt_path) != stage["sha256"]:
        raise RuntimeError(f"frozen prompt hash mismatch: {prompt_path}")
    template = prompt_path.read_text(encoding="utf-8")
    if template.count(PLACEHOLDER) != 1:
        raise RuntimeError(f"expected exactly one placeholder: {prompt_path}")
    return template.replace(PLACEHOLDER, new_input.strip(), 1)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=int, required=True, choices=TARGETS)
    parser.add_argument("--input-file", type=Path, required=True)
    args = parser.parse_args()
    print(render_few_shot_prompt(args.target, args.input_file.read_text(encoding="utf-8")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
