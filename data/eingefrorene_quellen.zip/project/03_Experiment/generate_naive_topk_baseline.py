#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path
from typing import Dict, List

from iterative_summarize import TARGETS, count_words, word_units


FIELDNAMES = [
    "experiment_run_id",
    "batch_run_id",
    "model_run_id",
    "model_name",
    "prompt_variant",
    "prompt_template",
    "temperature",
    "top_p",
    "top_k",
    "min_p",
    "seed",
    "num_ctx",
    "article_id",
    "dataset_index",
    "original_word_count",
    "summary_500",
    "summary_500_word_count",
    "summary_300",
    "summary_300_word_count",
    "summary_150",
    "summary_150_word_count",
    "summary_75",
    "summary_75_word_count",
]


def trim_to_n_words(text: str, n: int) -> str:
    return " ".join(word_units(text)[:n])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate a naive top-k-word baseline from the source article."
    )
    parser.add_argument("--articles", default="selected_articles.csv")
    parser.add_argument("--output", required=True)
    parser.add_argument("--experiment-run-id", default="baseline")
    parser.add_argument("--batch-run-id", default="baseline__naive_topk")
    parser.add_argument("--model-run-id", default="naive_topk")
    parser.add_argument("--model-name", default="naive-topk")
    parser.add_argument(
        "--prompt-template",
        default="take the first {target_word_length} words from the source article",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    articles_path = Path(args.articles)
    output_path = Path(args.output)
    if not articles_path.exists():
        print(f"Missing articles file: {articles_path}")
        return 1

    with articles_path.open("r", encoding="utf-8", newline="") as f:
        rows_in = list(csv.DictReader(f))

    rows_out: List[Dict[str, str]] = []
    for row in rows_in:
        article = (row.get("article") or "").strip()
        article_id = (row.get("article_id") or "").strip()
        dataset_index = (row.get("dataset_index") or "").strip()
        if not article or not article_id:
            continue

        output_row: Dict[str, str] = {
            "experiment_run_id": args.experiment_run_id,
            "batch_run_id": args.batch_run_id,
            "model_run_id": args.model_run_id,
            "model_name": args.model_name,
            "prompt_variant": "naive_topk",
            "prompt_template": args.prompt_template,
            "temperature": "",
            "top_p": "",
            "top_k": "",
            "min_p": "",
            "seed": "",
            "num_ctx": "",
            "article_id": article_id,
            "dataset_index": dataset_index,
            "original_word_count": str(count_words(article)),
        }

        for target in TARGETS:
            summary = trim_to_n_words(article, target)
            output_row[f"summary_{target}"] = summary
            output_row[f"summary_{target}_word_count"] = str(count_words(summary))

        rows_out.append(output_row)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows_out)

    print(f"Saved naive baseline for {len(rows_out)} articles to {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
