#!/usr/bin/env python3
"""Freeze one AI-generated, stage-matched CoT demonstration per recursive stage."""

from __future__ import annotations

import json

from iterative_summarize import bounds_for_target, count_words
from run_autocot_automatecot_final import write_json_atomic
from six_method_pilot_common import PROJECT, TARGETS


SOURCE = PROJECT / "few_shot_cot/curation_packet.json"
OUTPUT = PROJECT / "few_shot_cot/demonstrations.json"
FROZEN_ORIGIN = "6853"


def main() -> int:
    packet = json.loads(SOURCE.read_text(encoding="utf-8"))
    bank: dict[str, list[dict[str, object]]] = {}
    previous_response = None
    for target in TARGETS:
        matches = [
            row for row in packet[str(target)]
            if str(row.get("dataset_index")) == FROZEN_ORIGIN
        ]
        assert len(matches) == 1
        source = matches[0]
        low, high = bounds_for_target(target, 5.0)
        assert str(source.get("split")) == "train"
        assert str(source.get("thinking") or "").strip()
        assert low <= count_words(str(source.get("response") or "")) <= high
        if previous_response is not None:
            assert previous_response == str(source.get("input_text") or "").strip()
        row = {
            **source,
            "candidate_id": f"ai-frozen:{FROZEN_ORIGIN}:{target}",
            "approval_status": "ai_generated_frozen",
            "provenance_note": (
                "Automatically generated train-only stage example from one coherent recursive "
                "zero-shot-CoT chain. Frozen before Phase-B generation; no human rewriting."
            ),
        }
        bank[str(target)] = [row]
        previous_response = str(row["response"]).strip()
    assert sum(len(rows) for rows in bank.values()) == 4
    write_json_atomic(OUTPUT, bank)
    print(f"Frozen four demonstrations in one file: {OUTPUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
