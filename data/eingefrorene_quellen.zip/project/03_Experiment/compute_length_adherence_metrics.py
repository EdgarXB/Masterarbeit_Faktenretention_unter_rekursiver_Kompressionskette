#!/usr/bin/env python3
"""Compute transparent continuous word-target and accepted-window distance metrics."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean, median
from typing import Any

import numpy as np

from iterative_summarize import TARGETS, bounds_for_target, count_words


METRICS = (
    "word_window_success", "absolute_word_error", "absolute_relative_word_error",
    "word_window_violation_words", "word_window_violation_rate",
)


def args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=32)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)


def bootstrap(values: list[float], samples: int, seed: int) -> tuple[float, float]:
    array = np.asarray(values, dtype=float); rng = np.random.default_rng(seed)
    estimates = [float(rng.choice(array, size=len(array), replace=True).mean()) for _ in range(samples)]
    return tuple(float(value) for value in np.quantile(estimates, [.025, .975]))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    cfg = args(); cfg.output_dir.mkdir(parents=True, exist_ok=True)
    source_rows = read_csv(cfg.results); detail = []
    for row in source_rows:
        for target in TARGETS:
            summary = str(row.get(f"summary_{target}") or "").strip()
            words = int(row.get(f"summary_{target}_word_count") or count_words(summary))
            low, high = bounds_for_target(target, 5.0)
            absolute = abs(words - target)
            violation = max(low - words, words - high, 0)
            detail.append({
                "article_id": row["article_id"], "dataset_index": row["dataset_index"],
                "method": row["method"], "stage_target_words": target, "stage_actual_words": words,
                "accepted_min_words": low, "accepted_max_words": high,
                "word_window_success": float(low <= words <= high),
                "absolute_word_error": absolute,
                "absolute_relative_word_error": absolute / target,
                "word_window_violation_words": violation,
                "word_window_violation_rate": violation / target,
            })
    write_csv(cfg.output_dir / "length_adherence_detailed.csv", detail)

    groups = defaultdict(list)
    for row in detail:
        groups[(row["method"], row["stage_target_words"])].append(row)
        groups[(row["method"], "overall")].append(row)
    aggregate = []
    for (method, stage), rows in sorted(groups.items(), key=lambda item: (str(item[0][0]), str(item[0][1]))):
        for index, metric in enumerate(METRICS):
            values = [float(row[metric]) for row in rows]
            by_article = defaultdict(list)
            for row in rows:
                by_article[row["article_id"]].append(float(row[metric]))
            article_values = [mean(article_rows) for article_rows in by_article.values()]
            low, high = bootstrap(article_values, cfg.bootstrap_samples, cfg.seed + index + (0 if stage == "overall" else int(stage)))
            aggregate.append({
                "method": method, "stage_target_words": stage, "metric": metric,
                "n_stage_units": len(values), "mean": mean(values), "median": median(values),
                "bootstrap_95_ci_low": low, "bootstrap_95_ci_high": high,
            })
    write_csv(cfg.output_dir / "length_adherence_by_method_stage.csv", aggregate)

    overall = {(row["method"], row["metric"]): row for row in aggregate if row["stage_target_words"] == "overall"}
    methods = sorted({row["method"] for row in detail})
    lines = ["# Continuous length-adherence report", "",
        "The binary ±5% window indicator is complemented by distances that preserve how far a miss lies "
        "from the target and accepted window. All outputs remain in the denominator, including empty outputs.", "",
        "| Method | Window success | Mean absolute word error | Mean absolute relative word error | Mean window violation (words) | Mean window violation rate |",
        "|---|---:|---:|---:|---:|---:|"]
    for method in methods:
        value = lambda metric: float(overall[(method, metric)]["mean"])
        lines.append(f"| {method} | {value('word_window_success'):.3f} | {value('absolute_word_error'):.1f} | "
                     f"{value('absolute_relative_word_error'):.3f} | {value('word_window_violation_words'):.1f} | "
                     f"{value('word_window_violation_rate'):.3f} |")
    lines.extend(["", "Primary interpretation: `word_window_violation_rate=0` means the output is inside the "
        "accepted interval. Outside the interval, it is the distance to the closest boundary divided by the "
        "target. Lower is better. Absolute word error instead measures distance to the exact target."])
    (cfg.output_dir / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    manifest = {
        "status": "complete", "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source": str(cfg.results), "source_sha256": sha(cfg.results), "article_rows": len(source_rows),
        "stage_units": len(detail), "targets": list(TARGETS), "accepted_window_percent": 5.0,
        "primary_continuous_metric": "word_window_violation_rate",
        "definitions": {
            "absolute_word_error": "abs(actual_words - target_words)",
            "absolute_relative_word_error": "absolute_word_error / target_words",
            "word_window_violation_words": "max(accepted_min - actual, actual - accepted_max, 0)",
            "word_window_violation_rate": "word_window_violation_words / target_words",
        },
        "direction": "zero is optimal; lower is better for all error/violation metrics",
        "bootstrap": {"unit": "article; recursive stages remain clustered within article", "samples": cfg.bootstrap_samples, "seed": cfg.seed},
        "outputs_sha256": {},
    }
    for name in ("length_adherence_detailed.csv", "length_adherence_by_method_stage.csv", "REPORT.md"):
        manifest["outputs_sha256"][name] = sha(cfg.output_dir / name)
    (cfg.output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"PASS length adherence: {len(source_rows)} rows, {len(detail)} stage units")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
