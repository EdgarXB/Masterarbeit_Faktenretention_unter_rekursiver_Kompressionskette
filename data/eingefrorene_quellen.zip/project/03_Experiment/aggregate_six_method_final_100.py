#!/usr/bin/env python3
"""Aggregate the complete final-100 atomic artifacts into one analysis-ready CSV."""

from __future__ import annotations

import csv
import json

from iterative_summarize import count_words
from run_six_method_final_100 import INPUT, METHODS, MODEL, OUT, TARGETS


def main() -> int:
    with INPUT.open(encoding="utf-8", newline="") as handle:
        sources = list(csv.DictReader(handle))
    if len(sources) != 100:
        raise RuntimeError("expected exactly 100 final-test articles")
    result = []
    for source in sources:
        key = f"test__{source['dataset_index']}"
        for method in METHODS:
            path = OUT / "articles" / method / f"{key}.json"
            if not path.exists():
                raise RuntimeError(f"missing artifact: {path}")
            artifact = json.loads(path.read_text(encoding="utf-8"))
            if artifact.get("complete") is not True or len(artifact.get("stages", [])) != 4:
                raise RuntimeError(f"incomplete artifact: {path}")
            row = {
                **{name: source[name] for name in ("article_id", "dataset", "config", "split", "dataset_index", "article_sha256", "article", "highlights")},
                "method": method,
                "model_name": "deterministic" if method == "lead_k" else MODEL,
                "prompt_variant": method,
                "collection_phase": "final_100_frozen_temperature_0",
                "original_word_count": count_words(source["article"]),
            }
            for stage in artifact["stages"]:
                target = int(stage["target_words"])
                selected = stage["selected"]
                row[f"summary_{target}"] = selected["response"]
                row[f"summary_{target}_word_count"] = selected["response_word_count"]
                row[f"summary_{target}_initial_word_count"] = selected["response_word_count"]
                row[f"summary_{target}_initial_window_success"] = selected["word_window_success"]
                row[f"summary_{target}_final_window_success"] = selected["word_window_success"]
                row[f"summary_{target}_complete_sentence_success"] = selected["ends_with_complete_sentence"]
                row[f"summary_{target}_attempts"] = 1
            result.append(row)
    fixed = ["article_id", "dataset", "config", "split", "dataset_index", "article_sha256", "article", "highlights", "method", "model_name", "prompt_variant", "collection_phase", "original_word_count"]
    fields = fixed + [f"summary_{target}{suffix}" for target in TARGETS for suffix in ("", "_word_count", "_initial_word_count", "_initial_window_success", "_final_window_success", "_complete_sentence_success", "_attempts")]
    output = OUT / "recursive_results.csv"
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(result)
    print(f"PASS: aggregated {len(result)} final method-article rows to {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

