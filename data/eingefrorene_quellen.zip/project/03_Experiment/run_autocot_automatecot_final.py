#!/usr/bin/env python3
"""Run Auto-CoT and adapted Automate-CoT recursively on the frozen test set."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from all_loaded_models_microtest import seed_raw
from generate_cot_candidate_rollouts import (
    MODEL,
    MODEL_DIGEST,
    NUM_PREDICT,
    REPEAT_PENALTY,
    SEED,
    TEMPERATURE,
    TOLERANCE_PCT,
    TOP_P,
    complete_sentence,
    append_jsonl_durable,
)
from iterative_summarize import (
    TARGETS,
    bounds_for_target,
    count_words,
    extract_text,
    extract_thinking,
    ollama_generate,
)
from select_automatecot_demonstrations import build_fewshot_prompt, demonstration_block


METHODS = ("auto_cot", "automate_cot")


def counterbalanced_method_order(methods: list[str], position: int) -> list[str]:
    ordered = list(methods)
    if len(ordered) == 2 and position % 2 == 0:
        ordered.reverse()
    return ordered


def now_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json_atomic(path: Path, payload: Any) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)


def generate(prompt: str, args: argparse.Namespace, sampling_seed: int) -> dict[str, Any]:
    last_error: Exception | None = None
    for retry in range(args.api_retries):
        try:
            return ollama_generate(
                model=MODEL,
                prompt=seed_raw(prompt, True, reflection_interval=512),
                host=args.host,
                temperature=TEMPERATURE,
                top_p=TOP_P,
                repeat_penalty=REPEAT_PENALTY,
                seed=sampling_seed,
                num_ctx=args.num_ctx,
                keep_alive=args.keep_alive,
                num_predict=NUM_PREDICT,
                raw=True,
                timeout=args.timeout,
            )
        except Exception as exc:
            last_error = exc
            if retry + 1 < args.api_retries:
                time.sleep(min(30, 2**retry))
    assert last_error is not None
    raise last_error


def revision_prompt(
    source: str,
    previous: str,
    desired_target: int,
    control_target: int,
    demos: list[dict[str, Any]],
) -> str:
    low, high = bounds_for_target(control_target, TOLERANCE_PCT)
    previous_words = count_words(previous)
    blocks = "\n\n".join(
        demonstration_block(demo, position, desired_target)
        for position, demo in enumerate(demos, 1)
    )
    return (
        "Use the demonstrations for factual prioritization and style. Then perform the revision task.\n\n"
        f"{blocks}\n\n"
        "REVISION TASK:\n"
        f"A previous independent attempt contained {previous_words} words. Generate a fresh summary "
        f"from NEW INPUT toward the operational interval {low}-{high} words; do not copy the prior attempt. "
        "Preserve the most important supported facts, do not add facts, and end with a complete "
        "sentence. Think step by step, then output plain prose only after FINAL_SUMMARY:.\n\n"
        f"NEW INPUT:\n{source}"
    )


def select_stage_attempt(attempts: list[dict[str, Any]], target: int) -> tuple[dict[str, Any], str]:
    eligible = [
        row for row in attempts
        if row["response"] and row["word_window_success"] and row["ends_with_complete_sentence"]
    ]
    if eligible:
        return eligible[0], "first attempt satisfying word window and complete-sentence constraints"
    nonempty = [row for row in attempts if row["response"]]
    if not nonempty:
        raise RuntimeError(f"All generation attempts empty for target={target}")
    return (
        min(nonempty, key=lambda row: (abs(row["response_word_count"] - target), row["attempt_index"])),
        "closest non-empty attempt; no attempt passed all hard constraints",
    )
def run_stage(
    input_text: str,
    target: int,
    demos: list[dict[str, Any]],
    args: argparse.Namespace,
    attempts_log: Path | None = None,
    article_key: str = "",
    method: str = "",
    run_instance: str = "",
) -> dict[str, Any]:
    low, high = bounds_for_target(target, TOLERANCE_PCT)
    attempts: list[dict[str, Any]] = []
    previous = ""
    control_target = target
    for attempt_index in range(1, args.max_attempts + 1):
        prompt = (
            build_fewshot_prompt(input_text, target, demos)
            if attempt_index == 1
            else revision_prompt(input_text, previous, target, control_target, demos)
        )
        started = time.monotonic()
        sampling_seed = SEED + attempt_index - 1
        raw = generate(prompt, args, sampling_seed)
        response = extract_text(raw).strip()
        thinking = extract_thinking(raw).strip()
        words = count_words(response)
        attempt = {
            "attempt_index": attempt_index,
            "sampling_seed": sampling_seed,
            "phase": "few_shot_cot" if attempt_index == 1 else "few_shot_cot_length_revision",
            "desired_target_words": target,
            "operational_control_target_words": control_target,
            "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
            "prompt_word_count": count_words(prompt),
            "response": response,
            "thinking": thinking,
            "response_word_count": words,
            "thinking_word_count": count_words(thinking),
            "word_window_success": low <= words <= high,
            "ends_with_complete_sentence": complete_sentence(response),
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "done_reason": raw.get("done_reason"),
            "usage": {
                name: raw.get(name)
                for name in (
                    "total_duration", "load_duration", "prompt_eval_count", "prompt_eval_duration",
                    "eval_count", "eval_duration",
                )
            },
        }
        attempts.append(attempt)
        if attempts_log is not None:
            append_jsonl_durable(
                attempts_log,
                {
                    "run_instance": run_instance,
                    "recorded_at_utc": now_utc(),
                    "article_key": article_key,
                    "method": method,
                    "model": MODEL,
                    "model_digest": MODEL_DIGEST,
                    "num_ctx": args.num_ctx,
                    "target_words": target,
                    "input_word_count": count_words(input_text),
                    "ordered_demo_ids": [row["candidate_id"] for row in demos],
                    **attempt,
                },
            )
        previous = response
        if response and attempt["word_window_success"] and attempt["ends_with_complete_sentence"]:
            break
        if words and attempt_index >= 2:
            control_target = round(control_target * target / words)
            control_target = max(round(target * 0.35), min(round(target * 1.75), control_target))
    selected, reason = select_stage_attempt(attempts, target)
    return {
        "target_words": target,
        "accepted_min_words": low,
        "accepted_max_words": high,
        "input_text": input_text,
        "input_word_count": count_words(input_text),
        "ordered_demo_ids": [row["candidate_id"] for row in demos],
        "selected_attempt_index": selected["attempt_index"],
        "selection_reason": reason,
        "selected": selected,
        "attempts": attempts,
    }


def aggregate(rows: list[dict[str, str]], article_dir: Path, output: Path) -> None:
    result_rows: list[dict[str, Any]] = []
    for source in rows:
        for method in METHODS:
            path = article_dir / method / f"test__{source['dataset_index']}.json"
            if not path.exists():
                continue
            record = json.loads(path.read_text(encoding="utf-8"))
            out: dict[str, Any] = {
                "article_id": source["article_id"],
                "dataset": source["dataset"],
                "config": source["config"],
                "split": source["split"],
                "dataset_index": source["dataset_index"],
                "article_sha256": source["article_sha256"],
                "article": source["article"],
                "highlights": source["highlights"],
                "method": method,
                "model_name": MODEL,
                "prompt_variant": method,
                "original_word_count": count_words(source["article"]),
            }
            for stage in record["stages"]:
                target = int(stage["target_words"])
                selected = stage["selected"]
                out[f"summary_{target}"] = selected["response"]
                out[f"summary_{target}_word_count"] = selected["response_word_count"]
                out[f"summary_{target}_initial_word_count"] = stage["attempts"][0]["response_word_count"]
                out[f"summary_{target}_initial_window_success"] = stage["attempts"][0]["word_window_success"]
                out[f"summary_{target}_final_window_success"] = selected["word_window_success"]
                out[f"summary_{target}_complete_sentence_success"] = selected["ends_with_complete_sentence"]
                out[f"summary_{target}_attempts"] = len(stage["attempts"])
            result_rows.append(out)
    fixed = [
        "article_id", "dataset", "config", "split", "dataset_index", "article_sha256",
        "article", "highlights", "method", "model_name", "prompt_variant", "original_word_count",
    ]
    fields = fixed[:]
    for target in TARGETS:
        fields.extend([
            f"summary_{target}", f"summary_{target}_word_count",
            f"summary_{target}_initial_word_count", f"summary_{target}_initial_window_success",
            f"summary_{target}_final_window_success", f"summary_{target}_complete_sentence_success",
            f"summary_{target}_attempts",
        ])
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(result_rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--auto-demos", required=True, type=Path)
    parser.add_argument("--automate-demos", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--host", default="127.0.0.1:11435")
    parser.add_argument("--num-ctx", type=int, default=524288)
    parser.add_argument("--keep-alive", default="30m")
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--api-retries", type=int, default=3)
    parser.add_argument("--max-attempts", type=int, default=12)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--methods", nargs="+", choices=list(METHODS), default=list(METHODS))
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    # This production gate runs before any held-out test generation. It independently
    # verifies split isolation and both selected demonstration banks.
    preflight = subprocess.run(
        [
            sys.executable,
            str(Path(__file__).resolve().parent / "validate_autocot_automatecot_artifacts.py"),
            "--phase", "demos",
        ],
        cwd=Path(__file__).resolve().parent,
        check=False,
    )
    if preflight.returncode:
        raise RuntimeError("Demonstration/split preflight failed; held-out test generation was not started")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    article_dir = args.output_dir / "articles"
    checkpoint_dir = args.output_dir / "stage_checkpoints"
    for method in args.methods:
        (article_dir / method).mkdir(parents=True, exist_ok=True)
        (checkpoint_dir / method).mkdir(parents=True, exist_ok=True)
    with args.input.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if args.limit is not None:
        rows = rows[:args.limit]
    demo_files = {"auto_cot": args.auto_demos, "automate_cot": args.automate_demos}
    demos = {method: json.loads(path.read_text(encoding="utf-8")) for method, path in demo_files.items()}
    started_at = now_utc()
    attempts_log = args.output_dir / "attempts.jsonl"
    for position, row in enumerate(rows, 1):
        method_order = counterbalanced_method_order(args.methods, position)
        for method in method_order:
            key = f"test__{row['dataset_index']}"
            path = article_dir / method / f"{key}.json"
            if path.exists():
                print(f"SKIP method={method} {position}/{len(rows)} key={key}", flush=True)
                continue
            demo_sha256 = sha256_file(demo_files[method])
            run_signature = {
                "article_sha256": row["article_sha256"],
                "method": method,
                "model": MODEL,
                "model_digest": MODEL_DIGEST,
                "num_ctx": args.num_ctx,
                "demo_file_sha256": demo_sha256,
                "temperature": TEMPERATURE,
                "top_p": TOP_P,
                "repeat_penalty": REPEAT_PENALTY,
                "num_predict": NUM_PREDICT,
                "seed": SEED,
                "tolerance_pct": TOLERANCE_PCT,
                "reflection_interval": 512,
                "max_attempts": args.max_attempts,
            }
            checkpoint_path = checkpoint_dir / method / f"{key}.json"
            stages: list[dict[str, Any]] = []
            if checkpoint_path.exists():
                checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
                if checkpoint.get("run_signature") != run_signature:
                    raise RuntimeError(
                        f"Incompatible stage checkpoint for method={method} key={key}; "
                        "move it aside only after auditing the signature difference"
                    )
                stages = checkpoint.get("stages", [])
                observed_targets = [stage.get("target_words") for stage in stages]
                if observed_targets != list(TARGETS[:len(stages)]):
                    raise RuntimeError(
                        f"Invalid target prefix in stage checkpoint for method={method} key={key}: "
                        f"{observed_targets}"
                    )
                print(
                    f"RESUME method={method} {position}/{len(rows)} key={key} "
                    f"completed_targets={observed_targets}", flush=True,
                )
            current = (
                stages[-1]["selected"]["response"]
                if stages else row["article"].strip()
            )
            for target in TARGETS[len(stages):]:
                print(
                    f"START method={method} {position}/{len(rows)} key={key} "
                    f"input_words={count_words(current)} target={target}", flush=True,
                )
                stage = run_stage(
                    current,
                    target,
                    demos[method][str(target)],
                    args,
                    attempts_log=attempts_log,
                    article_key=key,
                    method=method,
                    run_instance=started_at,
                )
                stages.append(stage)
                current = stage["selected"]["response"]
                write_json_atomic(
                    checkpoint_path,
                    {
                        "checkpoint_version": 1,
                        "updated_at_utc": now_utc(),
                        "run_signature": run_signature,
                        "source": row,
                        "method_order": method_order,
                        "stages": stages,
                    },
                )
                print(
                    f"END method={method} key={key} target={target} "
                    f"words={count_words(current)} attempts={len(stage['attempts'])} "
                    f"window={stage['selected']['word_window_success']}", flush=True,
                )
            write_json_atomic(
                path,
                {
                    "created_at_utc": now_utc(),
                    "source": row,
                    "method": method,
                    "model": MODEL,
                    "model_digest": MODEL_DIGEST,
                    "num_ctx": args.num_ctx,
                    "demo_file": str(demo_files[method]),
                    "demo_file_sha256": demo_sha256,
                    "generation": {
                        "temperature": TEMPERATURE, "top_p": TOP_P,
                        "repeat_penalty": REPEAT_PENALTY, "num_predict": NUM_PREDICT,
                        "seed": SEED, "tolerance_pct": TOLERANCE_PCT,
                        "retry_seeds": [SEED + offset for offset in range(args.max_attempts)],
                        "reflection_interval": 512,
                        "max_attempts": args.max_attempts,
                    },
                    "counterbalanced_method_order_for_article": method_order,
                    "stages": stages,
                },
            )
            aggregate(rows, article_dir, args.output_dir / "recursive_results.csv")
    aggregate(rows, article_dir, args.output_dir / "recursive_results.csv")
    write_json_atomic(
        args.output_dir / "manifest.json",
        {
            "started_at_utc": started_at,
            "completed_at_utc": now_utc(),
            "input": str(args.input),
            "input_sha256": sha256_file(args.input),
            "articles": len(rows),
            "methods": args.methods,
            "expected_method_article_runs": len(rows) * len(args.methods),
            "completed_method_article_runs": sum(
                len(list((article_dir / method).glob("*.json"))) for method in args.methods
            ),
            "model": MODEL,
            "model_digest": MODEL_DIGEST,
            "num_ctx": args.num_ctx,
            "method_order": "article-wise counterbalanced: odd positions use declared order; even positions reverse it",
            "reflection_interval": 512,
            "demo_files": {
                method: {"path": str(path), "sha256": sha256_file(path)}
                for method, path in demo_files.items()
                if method in args.methods
            },
            "results_sha256": sha256_file(args.output_dir / "recursive_results.csv"),
        },
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
