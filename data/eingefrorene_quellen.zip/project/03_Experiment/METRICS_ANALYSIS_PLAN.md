# Metrics and Reviewer-Validation Analysis Plan

Purpose: this is the high-level handoff for future GPT/Codex instances. It records the completed human-validation work and how the validated QA-retention metrics should be used in thesis-ready analysis tables.

Pilot implementation note (2026-08-31): the 30-article six-method pipeline now retains empty
Single-pass summaries in every denominator. Each canonical question receives a deterministic
`NOT_FOUND` for an empty summary without an answer-model call; overlap, semantic-similarity, and
consistency metrics are operationally set to zero and `empty_output=1`. This prevents complete
generation failures from improving a method's conditional-on-output score.

Project root:

```bash
/home/edgar/main/.tools/ollama
```

## 1) Current Thesis Metric Stack

The thesis studies factual retention under progressive LLM compression:

```text
~800 source words -> 500 -> 300 -> 150 -> 75
```

The core claim should not depend on one metric. Treat the metrics as complementary views:

- **QA fact-retention rate**: primary thesis metric. Source facts are converted into questions; generated summaries are queried; answers are scored as retained, lost, or unsupported/hallucinated.
- **Loss rate**: fraction of source facts that no longer appear in the summary.
- **Unsupported / hallucination rate**: fraction of answers where the summary answer is not supported by the summary/source evidence.
- **Entity retention rate**: QA retention grouped by entity type, currently `PERSON`, `ORG`, `LOCATION`, `DATE_TIME`, `NUMBER`, `EVENT`, `OBJECT`, `OTHER`.
- **ROUGE-1/2/L F1**: lexical overlap with the source article. Useful but not a factual-retention substitute.
- **BERTScore F1**: semantic similarity with the source article. Useful but can disagree with fact retention.
- **SummaC**: NLI-style consistency between source and summary. Useful as a factuality signal, but not enough alone.
- **Length-window success**: whether a summary hits the target word window.
- **Compression rate**: actual summary words divided by source article words.

Important interpretation rule:

> If ROUGE/BERTScore/SummaC improve but QA retention drops, that is not a contradiction. It is one of the most interesting thesis findings.

## 2) Completed Human-Validation Experiments

Two human-validation experiments have been conducted:

1. The 60-item QA validation assessed question quality and agreement for retained/lost/unsupported labels across seven returned reviewer files. It identified excessive lexical `unsupported` classifications and led to scorer calibration. The final analysis is stored in `human_validation_package/analysis/`.
2. The salience-validation experiment assessed the relevance and ranking of atomic facts. The currently documented analysis contains four reviewers and 168 formal consensus facts. Its existing report is preliminary only with respect to incorporating any additional frozen-manifest returns, not because the experiment was never conducted.

Human review is therefore no longer a pending prerequisite. Future runs must use the calibrated scorer and report the limitations found by both validation experiments.

## 3) Archived Reviewer CSV Inputs

The completed analyses normalized incoming reviewer files onto these conceptual fields. Apply the same mapping only if additional returns are incorporated:

- `sample_id` or stable row id
- `article_id`
- `stage_target_words`
- `summary_prompt_variant`
- `canonical_fact_id`
- `entity_type`
- `question`
- `reference_answer`
- `model_answer` or `summary_answer`
- automatic label, if included
- reviewer label
- optional reviewer confidence
- optional free-text reviewer comment

Expected reviewer label space, ideally:

- `retained`
- `lost`
- `unsupported`
- possibly `unclear` or `invalid_question`

If reviewer labels differ, normalize them explicitly and write the mapping into the generated report.

## 4) Calculations Used For Human Validation

The reviewer-validation reports were created before updating experiment conclusions. Preserve these calculations for any supplementary returns.

Minimum outputs:

- `reviewer_label_counts.csv`
- `reviewer_vs_pipeline_confusion_matrix.csv`
- `reviewer_agreement_metrics.csv`
- `reviewer_validation_report.md`

Calculate:

- Total reviewed samples.
- Label distribution from the pipeline.
- Label distribution from humans.
- Pipeline-vs-human exact agreement.
- Agreement by label: `retained`, `lost`, `unsupported`.
- Precision, recall, and F1 for each automatic label, treating human labels as reference.
- Macro-F1 across labels.
- Cohen's kappa if labels are categorical and one human label exists per sample.
- If multiple reviewers reviewed the same row, compute inter-reviewer agreement separately before comparing to the pipeline.
- Breakdown of agreement by:
  - prompt variant
  - compression stage
  - entity type
  - answer status
  - reviewer confidence, if present

Special cases to flag:

- Automatic `lost`, human `retained`: likely paraphrase or overly strict automatic scoring.
- Automatic `retained`, human `lost`: likely overly lenient answer matching.
- Automatic `unsupported`, human `retained`: support evidence may be too strict.
- Human `invalid_question`: fact/question generation problem, not summary-retention behavior.

## 5) Reviewer-Adjusted Metrics

After reviewer agreement is known, decide whether to:

- keep automatic labels unchanged,
- apply a calibrated correction,
- exclude invalid-question samples,
- or improve the scoring script before scaling.

Useful reviewer-adjusted calculations:

- QA retention after excluding `invalid_question`.
- QA retention where human labels override automatic labels for reviewed rows.
- Estimated bias correction:
  - e.g. if automatic `lost` is often actually `retained`, estimate how much retention may be underestimated.
- Confidence intervals on human agreement rates.
- Error-rate table by compression stage and entity type.

Do not silently overwrite raw automatic labels. Keep raw, human, and adjusted labels separate.

## 6) Main Experiment Metrics Once Labels Are Trusted

For the 30-article validation and later 100-article run, generate these tables:

- `qa_retention_by_prompt_stage.csv`
- `qa_retention_by_prompt_overall.csv`
- `entity_retention_by_prompt_stage.csv`
- `metric_correlation_matrix.csv`
- `prompt_rankings_by_metric.csv`
- `length_control_by_prompt_stage.csv`
- `metric_divergence_cases.csv`
- `bootstrap_confidence_intervals.csv`
- `paired_prompt_differences.csv`

Core groupings:

- by prompt variant
- by compression stage
- by prompt variant + stage
- by entity type
- by article
- by source article word count, if useful

## 7) Statistical Calculations To Add

### Bootstrap Confidence Intervals

Use article-level bootstrap resampling, not row-level only, because facts within one article are not independent.

Calculate 95 percent CIs for:

- QA retention
- loss rate
- unsupported rate
- ROUGE-L
- BERTScore F1
- SummaC
- length-window success
- compression rate

Do this per:

- prompt variant
- stage
- prompt variant + stage

### Paired Prompt Comparisons

Because prompt variants use the same articles, compare prompts by paired article-level differences.

Useful comparisons:

- plain vs zero-shot CoT
- plain vs few-shot CoT
- zero-shot CoT vs few-shot CoT
- plain vs Auto-CoT
- plain vs Automatic CoT
- Auto-CoT vs Automatic CoT

Calculate:

- mean paired difference in QA retention
- bootstrap CI for the paired difference
- optional paired permutation test p-value
- direction count: number of articles where method A beats B, ties B, loses to B

### Metric Correlations

Calculate correlations between QA retention and:

- ROUGE-1/2/L F1
- BERTScore F1
- SummaC
- length-window success
- compression rate

Use Spearman correlation by default because monotonic relationships are more plausible than strictly linear relationships.

Calculate correlations at:

- summary-row level
- article-level aggregate
- prompt-stage aggregate

Be careful: aggregate correlations can mislead, so report the level clearly.

## 8) Metric Divergence Analyses

These are especially thesis-relevant.

Find cases where:

- ROUGE-L improves but QA retention decreases.
- BERTScore improves but QA retention decreases.
- SummaC is high but QA retention is low.
- Word-window success improves but QA retention decreases.
- CoT variants improve surface metrics but lose more facts than plain prompting.

For each divergence case, output:

- article id
- prompt variant
- stage
- QA retention
- ROUGE-L
- BERTScore F1
- SummaC
- length/window status
- short note explaining the disagreement if examples are available

## 9) Entity-Level Analyses

Entity retention may become one of the strongest analysis sections.

Calculate:

- retention by entity type and stage
- retention by entity type and prompt
- retention by entity type + prompt + stage
- loss rate by entity type
- unsupported rate by entity type
- minimum sample counts per entity type

Interpretation cautions:

- Do not overinterpret entity types with small sample counts.
- Always show `n`.
- Events and locations may have low counts; use them as exploratory unless the final experiment has enough samples.

## 10) Length-Control Analyses

CoT may improve target length while not improving factual retention. Capture that clearly.

Calculate:

- window success rate
- average absolute word-count error
- signed word-count error
- compression rate
- retention per actual summary length
- retention per compression rate

Useful question:

> Are prompt variants retaining more facts because they are better, or because they produced longer summaries?

Consider a simple regression or stratified comparison later:

- QA retention ~ prompt + stage + actual word count

Keep this optional unless the data supports it.

## 11) Report Structure To Generate

When CSVs arrive, generate one compact Markdown report and companion CSVs.

Suggested report:

```text
experiments/.../report/reviewer_validation_report.md
experiments/.../report/thesis_metric_analysis_report.md
```

Suggested sections:

1. Executive summary
2. Human-review validation
3. Main QA-retention results
4. Prompt comparison
5. Compression-stage curve
6. Entity retention
7. Metric divergence
8. Length-control diagnostics
9. Statistical confidence intervals
10. Limitations and next decisions

## 12) Reuse Notes For Supplementary Validation

The main QA validation has already been analyzed. If additional reviewer returns or a supplementary validation are incorporated:

1. Inspect the reviewer CSV headers.
2. Inspect existing report CSV headers in the latest run folder.
3. Preserve raw files.
4. Extend the existing analyzers rather than manually changing experiment outputs.
5. Keep generated reports inside the relevant `report/` directory.

Likely useful existing files:

- `score_model_selection_batch.py`
- `build_presentation_kpis.py`
- `answer_summary_questions.py`
- `experiments/prompt_comparison/20260516T134205Z_qwen30_10_article_kpi_test/report/qa_retention_detailed.csv`
- `experiments/prompt_comparison/20260516T134205Z_qwen30_10_article_kpi_test/report/qa_retention_kpis.csv`
- `experiments/prompt_comparison/20260516T134205Z_qwen30_10_article_kpi_test/report/entity_retention_kpis.csv`
- `experiments/prompt_comparison/20260516T134205Z_qwen30_10_article_kpi_test/report/summary_quality_detailed.csv`

Existing primary analysis script:

```text
human_validation_package/analyze_human_validation_returns.py
```

Recommended CLI shape:

```bash
python3 analyze_reviewer_validation.py \
  --reviewer-csv path/to/reviewer_feedback.csv \
  --pipeline-csv experiments/.../report/qa_retention_detailed.csv \
  --output-dir experiments/.../report/reviewer_validation
```

The script should write:

- normalized reviewer rows
- confusion matrix
- agreement metrics
- label-specific precision/recall/F1
- disagreement examples
- Markdown report

## 13) Applied Human-Validation Decision

The completed QA validation found high generated-question usability but only moderate agreement for answer labels, dominated by lexical false-`unsupported` cases. The project therefore followed the moderate-agreement branch: disagreements were inspected, the scorer was patched, and calibration reruns were performed on the existing 60-item set.

The completed fact-salience validation separately assessed whether the automatic fact ranking aligns with human salience judgments. Its currently documented four-reviewer analysis must be reported with its preliminary qualifier.

For any supplementary validation, retain these response rules:

- **High agreement**: proceed to 30-article validation, then bootstrap CIs.
- **Moderate agreement**: inspect disagreement categories, fix scoring rules, rerun scoring on existing outputs, then run 30 articles.
- **Low agreement**: pause scaling, repair question generation or answer scoring first.
- **Many invalid questions**: improve `extract_atomic_facts.py` prompts/schema filtering before more experiment runs.
- **Many paraphrase false negatives**: improve answer equivalence scoring before final claims.
- **Many unsupported false positives/negatives**: improve support-evidence handling and unsupported-label definition.

The goal is not perfect agreement. The goal is defensible, documented reliability for the thesis's primary metric.
