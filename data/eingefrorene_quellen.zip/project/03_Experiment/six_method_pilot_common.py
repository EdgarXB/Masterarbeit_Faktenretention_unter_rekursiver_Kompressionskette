#!/usr/bin/env python3
"""Shared frozen definitions for the six-method 30-article pilot."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from iterative_summarize import bounds_for_target
from select_automatecot_demonstrations import build_fewshot_prompt, demonstration_block


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "experiments/six_method_pilot_30"
SOURCE_PROJECT = ROOT / "experiments/autocot_automatecot_100"
TARGETS = (500, 300, 150, 75)
PILOT_NUM_PREDICT = 4096
PILOT_REASONING_BUDGET = 1024
PILOT_REFLECTION_INTERVAL = 512
METHODS = ("lead_k", "plain", "zero_shot_cot", "few_shot_cot", "auto_cot", "automate_cot")
GENERATIVE_METHODS = METHODS[1:]
PHASE_A_METHODS = ("lead_k", "plain", "zero_shot_cot", "auto_cot", "automate_cot")
PHASE_A_GENERATIVE_METHODS = PHASE_A_METHODS[1:]
PHASE_B_METHODS = ("few_shot_cot", "plain_anchor")
DEMO_FILES = {
    "few_shot_cot": PROJECT / "few_shot_cot/demonstrations.json",
    "auto_cot": SOURCE_PROJECT / "auto_cot_selection/auto_cot_demonstrations.json",
    "automate_cot": SOURCE_PROJECT / "automate_cot_selection/automate_cot_demonstrations.json",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def cyclic_method_order(position: int) -> list[str]:
    """Rotate five generative methods; over 30 articles each occupies every position six times."""
    shift = (position - 1) % len(GENERATIVE_METHODS)
    return list(GENERATIVE_METHODS[shift:] + GENERATIVE_METHODS[:shift])


def phase_a_method_order(position: int) -> list[str]:
    """Deterministic four-method rotation; position imbalance is at most one over 30 articles."""
    shift = (position - 1) % len(PHASE_A_GENERATIVE_METHODS)
    return list(PHASE_A_GENERATIVE_METHODS[shift:] + PHASE_A_GENERATIVE_METHODS[:shift])


def phase_b_method_order(position: int) -> list[str]:
    """Alternate delayed Few-shot-CoT and the contemporaneous Plain anchor."""
    return list(PHASE_B_METHODS if position % 2 else reversed(PHASE_B_METHODS))


def prompt_method(method: str) -> str:
    return "plain" if method == "plain_anchor" else method


def lead_k(text: str, target: int) -> str:
    matches = list(re.finditer(r"\b\w+\b", text or ""))
    if len(matches) <= target:
        return (text or "").strip()
    return text[:matches[target - 1].end()].strip()


def direct_prompt(text: str, target: int, cot: bool) -> str:
    low, high = bounds_for_target(target, 5.0)
    reasoning = " Think step by step before the final answer." if cot else ""
    return (
        f"Task: Summarize the new input in approximately {target} words.{reasoning}\n"
        f"The accepted length interval is {low}-{high} words. Preserve the most important facts "
        "supported by the new input, do not invent facts, and end with a complete sentence.\n"
        "Output plain prose only after the exact label FINAL_SUMMARY:. Do not put text after it.\n\n"
        f"NEW INPUT:\n{text.strip()}"
    )


def prompt_for(method: str, text: str, target: int, banks: dict[str, dict[str, list[dict[str, Any]]]]) -> str:
    if method == "plain":
        return direct_prompt(text, target, False)
    if method == "zero_shot_cot":
        return direct_prompt(text, target, True)
    return build_fewshot_prompt(text, target, banks[method][str(target)])


def revision_prompt(
    method: str, source: str, previous_words: int, desired_target: int, control_target: int,
    banks: dict[str, dict[str, list[dict[str, Any]]]],
) -> str:
    low, high = bounds_for_target(control_target, 5.0)
    blocks = ""
    if method in DEMO_FILES:
        blocks = "\n\n".join(
            demonstration_block(row, index, desired_target)
            for index, row in enumerate(banks[method][str(desired_target)], 1)
        ) + "\n\n"
    cot = method != "plain"
    reasoning = " Think step by step before the final answer." if cot else ""
    return (
        f"{blocks}REVISION TASK:\nA previous independent attempt contained {previous_words} words. "
        f"Generate a fresh summary from NEW INPUT toward the operational interval {low}-{high} words; "
        "do not copy the prior attempt. Preserve the most important supported facts, do not add facts, "
        f"and end with a complete sentence.{reasoning}\n"
        "Output plain prose only after the exact label FINAL_SUMMARY:. Do not put text after it.\n\n"
        f"NEW INPUT:\n{source.strip()}"
    )


def load_banks(require_manual: bool = True) -> dict[str, dict[str, list[dict[str, Any]]]]:
    banks = {}
    for method, path in DEMO_FILES.items():
        if not path.exists():
            if method == "few_shot_cot" and not require_manual:
                continue
            raise FileNotFoundError(path)
        banks[method] = json.loads(path.read_text(encoding="utf-8"))
    return banks
