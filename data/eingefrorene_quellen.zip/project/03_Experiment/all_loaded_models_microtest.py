#!/usr/bin/env python3
import csv
import json
import re
import time
import urllib.error
from collections import Counter
from pathlib import Path

from iterative_summarize import build_prompt, count_words, extract_text, extract_thinking, ollama_generate


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "experiments/prompt_comparison/20260516T134205Z_qwen30_10_article_kpi_test/selected_articles_10.csv"
OUTDIR = ROOT / "experiments/model_microtest_20260805"
TARGET = 500
LOW, HIGH = 475, 525
HOST = "127.0.0.1:11435"
GLOBAL_SECONDS = 17 * 60
CALL_TIMEOUT = 65

MODELS = [
    "milkey/Seed-OSS-36B-Instruct:q4_K_M",
    "steelpuddles/hermes-4.3-36B:thinking-tools",
    "nemotron3:33b",
    "qwen3:30b",
    "qwen3.5:27b",
    "qwen3.6:35b",
    "glm-4.7-flash:latest",
    "gpt-oss:20b",
    "gemma4:31b",
]


def rouge_f1(reference: str, candidate: str) -> dict:
    ref = re.findall(r"[a-z0-9]+", reference.lower())
    cand = re.findall(r"[a-z0-9]+", candidate.lower())
    def ngram_f1(n: int) -> float:
        a = Counter(tuple(ref[i:i+n]) for i in range(len(ref) - n + 1))
        b = Counter(tuple(cand[i:i+n]) for i in range(len(cand) - n + 1))
        overlap = sum((a & b).values())
        if not a or not b or not overlap:
            return 0.0
        p, r = overlap / sum(b.values()), overlap / sum(a.values())
        return 2 * p * r / (p + r)
    prev = [0] * (len(cand) + 1)
    for token in ref:
        cur = [0]
        for j, other in enumerate(cand, 1):
            cur.append(prev[j-1] + 1 if token == other else max(prev[j], cur[-1]))
        prev = cur
    lcs = prev[-1]
    rl = (2 * lcs / (len(ref) + len(cand))) if ref and cand else 0.0
    return {"rouge1": ngram_f1(1), "rouge2": ngram_f1(2), "rougeL": rl}


def settings(model: str, variant: str) -> dict:
    cot = variant == "zero_shot_cot"
    base = {"top_k": None, "min_p": None, "presence_penalty": None,
            "repeat_penalty": 1.0, "num_predict": 4096 if cot else 1800}
    if "Seed-OSS" in model:
        return {**base, "temperature": 1.1, "top_p": 0.95, "think": None, "raw_seed": True,
                "num_predict": 2400}
    if "hermes" in model:
        return {**base, "temperature": 0.6, "top_p": 0.95, "top_k": 20, "think": cot}
    if model.startswith("nemotron3:"):
        if cot:
            return {**base, "temperature": 0.6, "top_p": 0.95, "think": True}
        return {**base, "temperature": 0.2, "top_p": 1.0, "top_k": 1, "think": False}
    if model.startswith("qwen3:"):
        if cot:
            return {**base, "temperature": 0.6, "top_p": 0.95, "top_k": 20,
                    "min_p": 0.0, "think": True}
        return {**base, "temperature": 0.7, "top_p": 0.8, "top_k": 20,
                "min_p": 0.0, "think": False}
    if model.startswith(("qwen3.5:", "qwen3.6:")):
        if cot:
            return {**base, "temperature": 1.0, "top_p": 0.95, "top_k": 20,
                    "min_p": 0.0, "presence_penalty": 1.5, "think": True}
        return {**base, "temperature": 0.7, "top_p": 0.8, "top_k": 20,
                "min_p": 0.0, "presence_penalty": 1.5, "think": False}
    if model.startswith("glm-4.7-flash"):
        return {**base, "temperature": 1.0, "top_p": 0.95, "think": cot}
    if model.startswith("gpt-oss:"):
        return {**base, "temperature": 1.0, "top_p": 1.0,
                "think": "medium" if cot else "low"}
    if model.startswith("gemma4:"):
        return {**base, "temperature": 1.0, "top_p": 0.95, "top_k": 64, "think": cot}
    raise ValueError(model)


def seed_raw(
    prompt: str, cot: bool, reflection_interval: int = 128, thinking_budget: int = 512,
) -> str:
    if cot:
        if thinking_budget <= 0 or reflection_interval <= 0:
            raise ValueError("thinking_budget and reflection_interval must be positive")
        system = (
            "You are an intelligent assistant with reflective ability. In the process of thinking and "
            f"reasoning, you need to strictly follow the thinking budget, which is {thinking_budget}. "
            f"That is, you need to complete your thinking within {thinking_budget} tokens and start "
            "answering the user's questions. You "
            f"will reflect on your thinking process every {reflection_interval} tokens, stating how many "
            "tokens have been used and how many are left."
        )
        suffix = "<seed:bos>assistant\n"
    else:
        system = (
            "You are an intelligent assistant that can answer questions in one step without the need for "
            "reasoning and thinking, that is, your thinking budget is 0. Next, please skip the thinking "
            "process and directly start answering the user's questions."
        )
        suffix = (
            "<seed:bos>assistant\n<seed:think>\n<seed:cot_budget_reflect>The current thinking "
            "budget is 0, so I will directly start answering the question.</seed:cot_budget_reflect>\n"
            "</seed:think>"
        )
    return f"<seed:bos>system\n{system}<seed:eos><seed:bos>user\n{prompt}<seed:eos>{suffix}"


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    with INPUT.open(encoding="utf-8", newline="") as handle:
        article = next(csv.DictReader(handle))["article"].strip()
    started_all = time.monotonic()
    rows = []
    for model in MODELS:
        for variant, template in [
            ("plain", "summarize in {target_word_length}"),
            ("zero_shot_cot", "summarize in {target_word_length}, think step by step"),
        ]:
            if time.monotonic() - started_all >= GLOBAL_SECONDS:
                rows.append({"model": model, "variant": variant, "status": "global_timeout"})
                continue
            cfg = settings(model, variant)
            prompt = build_prompt(article, TARGET, 5.0, template)
            if model.startswith("qwen3:") and variant == "plain":
                prompt = "/no_think\n" + prompt
            if cfg.pop("raw_seed", False):
                prompt = seed_raw(prompt, variant == "zero_shot_cot")
                raw = True
            else:
                raw = False
            t0 = time.monotonic()
            status = "ok"
            error = ""
            try:
                data = ollama_generate(
                    model=model, prompt=prompt, host=HOST, temperature=cfg["temperature"],
                    top_p=cfg["top_p"], top_k=cfg["top_k"], min_p=cfg["min_p"],
                    presence_penalty=cfg["presence_penalty"], repeat_penalty=cfg["repeat_penalty"],
                    seed=32, num_ctx=8192, keep_alive="90s", think=cfg["think"],
                    num_predict=cfg["num_predict"], raw=raw, timeout=CALL_TIMEOUT,
                )
                response = extract_text(data)
                thinking = extract_thinking(data)
                done_reason = data.get("done_reason", "")
            except Exception as exc:
                response, thinking, done_reason = "", "", ""
                status, error = "timeout_or_error", f"{type(exc).__name__}: {exc}"
            elapsed = time.monotonic() - t0
            wc, twc = count_words(response), count_words(thinking)
            scores = rouge_f1(article, response) if response else None
            row = {
                "model": model, "variant": variant, "status": status,
                "seconds": round(elapsed, 2), "response_words": wc,
                "thinking_words": twc, "word_window": LOW <= wc <= HIGH,
                "rouge1": round(scores["rouge1"], 4) if scores else None,
                "rouge2": round(scores["rouge2"], 4) if scores else None,
                "rougeL": round(scores["rougeL"], 4) if scores else None,
                "done_reason": done_reason, "error": error,
                "settings": cfg, "thinking": thinking, "response": response,
            }
            rows.append(row)
            print(json.dumps({k: row[k] for k in ["model", "variant", "status", "seconds",
                  "response_words", "thinking_words", "word_window", "rouge1", "rouge2", "rougeL",
                  "done_reason"]}, ensure_ascii=False), flush=True)
            with (OUTDIR / "results.json").open("w", encoding="utf-8") as handle:
                json.dump(rows, handle, ensure_ascii=False, indent=2)
    print(f"TOTAL_SECONDS={time.monotonic() - started_all:.2f}", flush=True)


if __name__ == "__main__":
    main()
