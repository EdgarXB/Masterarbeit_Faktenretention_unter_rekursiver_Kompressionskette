#!/usr/bin/env python3
"""Resume-safe metrics, fact extraction and QA evaluation for the final 100 articles."""

from __future__ import annotations

import hashlib
import json
import subprocess
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PYTHON = ROOT / ".venv-metrics/bin/python"
PROJECT = ROOT / "experiments/six_method_final_100"
DATA = ROOT / "experiments/autocot_automatecot_100/data/final_test_100.csv"
RESULTS = PROJECT / "run/recursive_results.csv"
BERTSCORE_MODEL = "/home/edgar/.cache/huggingface/hub/models--distilroberta-base/snapshots/fb53ab8802853c8e4fbdbcd0529f21fc6f459b2b"


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(*args: str) -> None:
    print(f"\n=== {args[0]} ===", flush=True)
    subprocess.run([str(PYTHON), *args], cwd=ROOT, check=True)


def unload(model: str) -> None:
    request = urllib.request.Request(
        "http://127.0.0.1:11435/api/generate",
        data=json.dumps({"model": model, "keep_alive": 0}).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=60):
        pass


def main() -> int:
    if not RESULTS.exists():
        raise RuntimeError("final summary aggregation is incomplete")
    run("validate_six_method_final_100.py", "--require-complete")
    frozen = json.loads((PROJECT / "frozen_downstream_protocol.json").read_text(encoding="utf-8"))
    protocol = {
        "status": "frozen before final summary generation",
        "articles_sha256": sha256_file(DATA),
        "summary_rows": 600,
        "canonical_facts_per_article": 20,
        "candidate_fact_pool_per_article": 24,
        "expected_canonical_facts": 2000,
        "expected_summary_qa_units": 48000,
        "fact_generator": "thesis-gemma:v1",
        "fact_generator_digest": "6316f0629137b426c9d9b853ffc4c8209589f30ee39aebede6285096c0ff47e7",
        "fact_temperature": 0.0,
        "fact_seed": 32,
        "fact_num_ctx": 8192,
        "fact_max_attempts": 5,
        "qa_answerer": "thesis-qwen38-qa:v1",
        "qa_answerer_digest": "d80421b9191aff0d4d8ea0911068452f11f3963e3e282c6b9d778932c4b268b3",
        "qa_temperature": 0.0,
        "qa_seed": 32,
        "qa_num_ctx": 8192,
        "qa_api_retries_for_transport": 3,
        "qa_exact_contiguous_support_required": True,
        "persistent_grounding_failures": "explicit technical missing values",
        "bootstrap_samples": 10000,
        "bootstrap_seed": 32,
        "bootstrap_unit": "article",
        "length_adjusted_retention_formula": "retention_all_missing_zero / (1 + word_window_violation_rate)",
        "length_adjusted_retention_role": "secondary descriptive metric",
    }
    if protocol != frozen:
        mismatches = sorted(key for key in set(protocol) | set(frozen) if protocol.get(key) != frozen.get(key))
        raise RuntimeError(f"frozen downstream protocol mismatch: {mismatches}")
    protocol_path = PROJECT / "downstream_protocol.json"
    if protocol_path.exists():
        old = json.loads(protocol_path.read_text(encoding="utf-8"))
        if old.get("frozen_protocol") != frozen or old.get("summaries_sha256") != sha256_file(RESULTS):
            raise RuntimeError("downstream protocol or summary hash mismatch")
    else:
        protocol_path.write_text(json.dumps({"created_at_utc": now(), "summaries_sha256": sha256_file(RESULTS), "frozen_protocol": frozen}, indent=2) + "\n", encoding="utf-8")

    if not (PROJECT / "metrics/metrics_manifest.json").exists():
        unload("thesis-seed:v1")
        run("evaluate_autocot_automatecot_metrics.py", "--results", str(RESULTS), "--output-dir", str(PROJECT / "metrics"), "--bertscore-model", BERTSCORE_MODEL, "--summac-device", "cuda", "--bootstrap-samples", "10000", "--seed", "32")
    else:
        print("SKIP complete content metrics", flush=True)

    run("extract_atomic_facts.py", "--articles", str(DATA), "--output-dir", str(PROJECT / "facts"), "--experiment-run-id", "six_method_final_100", "--model", "thesis_gemma_v1=thesis-gemma:v1", "--preferred-canonical-model", "thesis-gemma:v1", "--facts-per-article", "20", "--candidate-pool-size", "24", "--temperature", "0", "--seed", "32", "--num-ctx", "8192", "--max-attempts", "5", "--host", "127.0.0.1:11435", "--resume")
    run("answer_summary_questions.py", "--facts", str(PROJECT / "facts/canonical_facts.csv"), "--summary-file", str(RESULTS), "--output-dir", str(PROJECT / "qa"), "--experiment-run-id", "six_method_final_100", "--model", "thesis_qwen38_qa_v1=thesis-qwen38-qa:v1", "--temperature", "0", "--seed", "32", "--num-ctx", "8192", "--api-retries", "3", "--host", "127.0.0.1:11435", "--resume", "--accept-terminal-grounding-missing")
    unload("thesis-qwen38-qa:v1")
    run("score_model_selection_batch.py", "--articles", str(DATA), "--summary-file", str(RESULTS), "--fact-summary", str(PROJECT / "facts/fact_extraction_summary.csv"), "--answers", str(PROJECT / "qa/summary_question_answers.csv"), "--output-dir", str(PROJECT / "qa_report"), "--with-bertscore", "--bertscore-model", BERTSCORE_MODEL, "--with-summac", "--summac-device", "cuda")
    run("analyze_autocot_automatecot_qa.py", "--detailed", str(PROJECT / "qa_report/qa_retention_detailed.csv"), "--output-dir", str(PROJECT / "qa_report"), "--bootstrap-samples", "10000", "--seed", "32")
    run("compute_length_adjusted_retention.py", "--qa-article", str(PROJECT / "qa_report/qa_article_level.csv"), "--length-detailed", str(PROJECT / "metrics/metrics_detailed.csv"), "--output-dir", str(PROJECT / "combined_metrics"), "--bootstrap-samples", "10000", "--seed", "32")
    completion = {"status": "complete", "completed_at_utc": now(), "canonical_facts": 2000, "expected_qa_units": 48000}
    (PROJECT / "downstream_completion.json").write_text(json.dumps(completion, indent=2) + "\n", encoding="utf-8")
    print("PASS: final-100 downstream evaluation complete", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
