#!/usr/bin/env python3
"""Resume-safe single-pass generation for the frozen six-method 100-article experiment."""

from __future__ import annotations

import argparse
import csv
import json
import os
import time
import urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from all_loaded_models_microtest import seed_raw
from iterative_summarize import bounds_for_target, count_words, extract_text, extract_thinking, ollama_generate
from run_six_method_pilot_v2 import (
    GENERATIVE_METHODS,
    METHODS,
    RAW_WRAPPER_COT,
    ROOT,
    TARGETS,
    complete_sentence,
    demonstration_prompt,
    direct_prompt,
    lead_k,
    method_order,
    sha256_file,
    sha256_text,
)


PROJECT = ROOT / "experiments/six_method_final_100"
INPUT = ROOT / "experiments/autocot_automatecot_100/data/final_test_100.csv"
PROMPT_MANIFEST = ROOT / "experiments/autocot_automatecot_100/final_prompts/manifest.json"
FROZEN_PROTOCOL = PROJECT / "frozen_protocol.json"
OUT = PROJECT / "run"
MODEL = "thesis-seed:v1"
MODEL_DIGEST = "7a66a2f466bf48fdafa7004a7975a7f5fac6e667a6de7d01751aacb98b3f387c"
HOST = "127.0.0.1:11435"
SEED = 32
TEMPERATURE = 0.0
TOP_P = 0.95
REPEAT_PENALTY = 1.0
NUM_CTX = 524288
NUM_PREDICT = 4096
REASONING_BUDGET = 1024
REFLECTION_INTERVAL = 512


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def write_json_atomic(path: Path, payload: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def append_jsonl_durable(path: Path, payload: Any) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def load_prompt_manifest() -> dict[str, Any]:
    return json.loads(PROMPT_MANIFEST.read_text(encoding="utf-8"))


def prompt_for(method: str, text: str, target: int, manifest: dict[str, Any]) -> str:
    if method == "plain":
        return direct_prompt(text, target, False)
    if method == "zero_shot_cot":
        return direct_prompt(text, target, True)
    return demonstration_prompt(method, text, target, manifest)


def configuration() -> dict[str, Any]:
    return {
        "status": "frozen before any final-test model generation",
        "input_path": str(INPUT.relative_to(ROOT)),
        "input_sha256": sha256_file(INPUT),
        "input_rows": 100,
        "methods": list(METHODS),
        "model": MODEL,
        "model_digest": MODEL_DIGEST,
        "demonstration_generation_temperature": 1.1,
        "evaluation_temperature": TEMPERATURE,
        "seed": SEED,
        "top_p": TOP_P,
        "repeat_penalty": REPEAT_PENALTY,
        "num_ctx": NUM_CTX,
        "num_predict": NUM_PREDICT,
        "reasoning_budget_zero_shot_only": REASONING_BUDGET,
        "reflection_interval_zero_shot_only": REFLECTION_INTERVAL,
        "raw_wrapper_cot": RAW_WRAPPER_COT,
        "single_pass": True,
        "revision": False,
        "best_of": False,
        "automatic_transport_retry": False,
        "targets": list(TARGETS),
        "tolerance_pct": 5.0,
        "accepted_windows": {str(target): list(bounds_for_target(target, 5.0)) for target in TARGETS},
        "word_count_rule": r"regex \b\w+\b",
        "prompt_manifest_path": str(PROMPT_MANIFEST.relative_to(ROOT)),
        "prompt_manifest_sha256": sha256_file(PROMPT_MANIFEST),
        "order_protocol": "five-method cyclic rotation; each generative method occurs exactly 20 times in every slot",
        "recursive_stage_input": True,
        "final_test_used_for_development": False,
        "length_adjusted_retention_formula": "retention_all_missing_zero / (1 + word_window_violation_rate)",
        "length_adjusted_retention_role": "secondary descriptive metric; primary dimensions remain separately reported",
    }


def runtime_metadata() -> dict[str, Any]:
    with urllib.request.urlopen(f"http://{HOST}/api/version", timeout=30) as response:
        version = json.loads(response.read().decode("utf-8"))
    with urllib.request.urlopen(f"http://{HOST}/api/tags", timeout=30) as response:
        tags = json.loads(response.read().decode("utf-8"))
    match = next((item for item in tags.get("models", []) if item.get("name") == MODEL), None)
    if match is None:
        raise RuntimeError(f"required model not installed: {MODEL}")
    if match.get("digest") != MODEL_DIGEST:
        raise RuntimeError(f"model digest mismatch: {match.get('digest')}")
    return {"ollama": version.get("version"), "observed_model_digest": match.get("digest")}


def validate_freeze() -> tuple[list[dict[str, str]], dict[str, Any], dict[str, Any]]:
    frozen = json.loads(FROZEN_PROTOCOL.read_text(encoding="utf-8"))
    current = configuration()
    if current != frozen:
        mismatches = sorted(key for key in set(current) | set(frozen) if current.get(key) != frozen.get(key))
        raise RuntimeError(f"frozen protocol mismatch: {mismatches}")
    with INPUT.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 100:
        raise RuntimeError(f"expected 100 frozen test rows, found {len(rows)}")
    if len({row["article_sha256"] for row in rows}) != 100:
        raise RuntimeError("final-test article hashes are not unique")
    for row in rows:
        if sha256_text(row["article"].strip()) != row["article_sha256"]:
            raise RuntimeError(f"article hash mismatch: {row['dataset_index']}")
    manifest = load_prompt_manifest()
    return rows, manifest, runtime_metadata()


def run_stage(method: str, source: str, target: int, manifest: dict[str, Any], signature: str, key: str) -> dict[str, Any]:
    prompt = prompt_for(method, source, target, manifest)
    cot = RAW_WRAPPER_COT[method]
    started = time.monotonic()
    raw = ollama_generate(
        model=MODEL,
        prompt=seed_raw(prompt, cot, reflection_interval=REFLECTION_INTERVAL, thinking_budget=REASONING_BUDGET),
        host=HOST,
        temperature=TEMPERATURE,
        top_p=TOP_P,
        repeat_penalty=REPEAT_PENALTY,
        seed=SEED,
        num_ctx=NUM_CTX,
        keep_alive="30m",
        num_predict=NUM_PREDICT,
        raw=True,
        timeout=1800,
    )
    response = extract_text(raw).strip()
    thinking = extract_thinking(raw).strip()
    words = count_words(response)
    low, high = bounds_for_target(target, 5.0)
    attempt = {
        "attempt_index": 1,
        "sampling_seed": SEED,
        "temperature": TEMPERATURE,
        "prompt_sha256": sha256_text(prompt),
        "raw_wrapper_cot": cot,
        "response": response,
        "thinking": thinking,
        "response_word_count": words,
        "thinking_word_count": count_words(thinking),
        "word_window_success": low <= words <= high,
        "word_window_violation_words": max(low - words, words - high, 0),
        "word_window_violation_rate": max(low - words, words - high, 0) / target,
        "empty_output": not bool(response),
        "ends_with_complete_sentence": complete_sentence(response),
        "done_reason": raw.get("done_reason"),
        "eval_count": raw.get("eval_count"),
        "latency_seconds": time.monotonic() - started,
    }
    append_jsonl_durable(
        OUT / "attempts.jsonl",
        {"run_signature": signature, "article_key": key, "method": method, "target_words": target, **attempt},
    )
    return {
        "target_words": target,
        "input_text": source,
        "input_word_count": count_words(source),
        "selected_attempt_index": 1,
        "selection_reason": "single-pass output; no retry or selection",
        "selected": attempt,
        "attempts": [attempt],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--confirm-frozen-protocol", action="store_true")
    args = parser.parse_args()
    if not args.confirm_frozen_protocol:
        raise RuntimeError("refusing to access final-test texts without --confirm-frozen-protocol")

    rows, manifest, runtime = validate_freeze()
    OUT.mkdir(parents=True, exist_ok=True)
    for method in METHODS:
        (OUT / "articles" / method).mkdir(parents=True, exist_ok=True)
    config = configuration()
    signature = sha256_text(json.dumps(config, sort_keys=True))
    manifest_path = OUT / "collection_manifest.json"
    start_manifest = {"created_at_utc": now(), "run_signature": signature, "runtime": runtime, **config}
    if manifest_path.exists():
        old = json.loads(manifest_path.read_text(encoding="utf-8"))
        if old.get("run_signature") != signature:
            raise RuntimeError("incompatible existing final run directory")
    else:
        write_json_atomic(manifest_path, start_manifest)

    total_calls = len(rows) * len(GENERATIVE_METHODS) * len(TARGETS)
    for position, source in enumerate(rows, 1):
        key = f"test__{source['dataset_index']}"
        lead_path = OUT / "articles/lead_k" / f"{key}.json"
        if not lead_path.exists():
            current = source["article"].strip()
            stages = []
            for target in TARGETS:
                response = lead_k(current, target)
                low, high = bounds_for_target(target, 5.0)
                words = count_words(response)
                selected = {
                    "response": response,
                    "thinking": "",
                    "response_word_count": words,
                    "word_window_success": low <= words <= high,
                    "word_window_violation_words": max(low - words, words - high, 0),
                    "word_window_violation_rate": max(low - words, words - high, 0) / target,
                    "empty_output": not bool(response),
                    "ends_with_complete_sentence": complete_sentence(response),
                }
                stages.append({"target_words": target, "input_text": current, "input_word_count": count_words(current), "selected": selected, "attempts": [selected]})
                current = response
            write_json_atomic(lead_path, {"complete": True, "run_signature": signature, "method": "lead_k", "source_sha256": source["article_sha256"], "stages": stages})

        for method in method_order(position):
            path = OUT / "articles" / method / f"{key}.json"
            stages: list[dict[str, Any]] = []
            if path.exists():
                existing = json.loads(path.read_text(encoding="utf-8"))
                if existing.get("run_signature") != signature or existing.get("source_sha256") != source["article_sha256"]:
                    raise RuntimeError(f"resume provenance mismatch: {path}")
                stages = existing.get("stages", [])
                if existing.get("complete") is True:
                    continue
                if [stage["target_words"] for stage in stages] != list(TARGETS[:len(stages)]):
                    raise RuntimeError(f"invalid partial stage order: {path}")
            current = stages[-1]["selected"]["response"] if stages else source["article"].strip()
            for target in TARGETS[len(stages):]:
                stage = run_stage(method, current, target, manifest, signature, key)
                stages.append(stage)
                current = stage["selected"]["response"]
                write_json_atomic(path, {"complete": False, "run_signature": signature, "method": method, "source_sha256": source["article_sha256"], "stages": stages})
                completed = sum(
                    len(json.loads(item.read_text(encoding="utf-8")).get("stages", []))
                    for item in (OUT / "articles").glob("*/*.json") if item.parent.name != "lead_k"
                )
                print(
                    f"PROGRESS {completed}/{total_calls} article={position}/100 method={method} "
                    f"stage={target} words={stage['selected']['response_word_count']} "
                    f"window={stage['selected']['word_window_success']} empty={stage['selected']['empty_output']} "
                    f"done={stage['selected']['done_reason']} latency={stage['selected']['latency_seconds']:.1f}s",
                    flush=True,
                )
            write_json_atomic(path, {"complete": True, "run_signature": signature, "method": method, "source_sha256": source["article_sha256"], "stages": stages})

    artifacts = [json.loads(path.read_text(encoding="utf-8")) for path in (OUT / "articles").glob("*/*.json")]
    counts = Counter(item["method"] for item in artifacts if item.get("complete"))
    write_json_atomic(OUT / "completion.json", {"status": "complete", "completed_at_utc": now(), "complete_articles_by_method": counts, "expected_articles_by_method": 100})
    print("PASS: frozen six-method 100-article generation complete", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
