"""Strict, offline analysis of the NEW 3 x 200 human validation (stdlib only).

No human results are included. See README for commands and prespecified rules.
"""
from pathlib import Path
from collections import Counter, defaultdict
from itertools import combinations
from datetime import datetime
import argparse
import csv
import hashlib
import json
import math
import random

ROOT = Path(__file__).resolve().parent
LABELS = ('retained', 'lost', 'unsupported')
HUMAN_LABELS = (*LABELS, 'special')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def save_csv(path, rows, fields=None):
    rows = list(rows)
    fields = fields or (list(rows[0]) if rows else ['case_id'])
    with Path(path).open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def read_csv(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def boolean(v):
    if v is True or isinstance(v,str) and v.casefold() == 'true':
        return True
    if v is False or isinstance(v,str) and v.casefold() == 'false':
        return False
    raise ValueError('Invalid boolean: '+str(v))


def validate_ratings(paths, root=ROOT):
    if len(paths) != 3:
        raise ValueError('Exactly three independent participant files are required.')
    manifest = load_json(root / 'human_validation_manifest.json')
    cases = load_json(root / 'intern/evaluation_cases.json')
    expected = {c['case_id'] for c in cases}
    if len(cases) != 200 or len(expected) != 200:
        raise ValueError('Case registry must contain exactly 200 unique cases.')
    # Prevent pairing exports with changed cases/configs.
    for name in ['human_validation_cases.json','intern/evaluation_cases.json',*[f'participant_{i:02d}.json' for i in (1,2,3)]]:
        if sha(root / name) != manifest['file_sha256'][name]:
            raise ValueError('Frozen file changed: '+name)
    configs = {f'participant_{i:02d}':load_json(root/f'participant_{i:02d}.json') for i in (1,2,3)}
    grouped, audits = {}, []
    for path in paths:
        if Path(path).suffix.lower() == '.json':
            obj = load_json(path)
            if obj.get('schema_version') != 1 or obj.get('dataset_id') != manifest['dataset_id']:
                raise ValueError('Wrong study/schema: '+str(path))
            pid = obj.get('participant_id')
            if pid not in configs or obj.get('order') != configs[pid]['case_ids']:
                raise ValueError('Unknown participant or wrong randomized order.')
            responses = obj.get('responses')
            if not isinstance(responses, dict) or any(k != r.get('case_id') for k,r in responses.items()):
                raise ValueError('Malformed response registry.')
            rows = list(responses.values())
            audits.append(dict(participant_id=pid, revisions=obj.get('revisions', [])))
        else:
            rows = read_csv(path)
            pids = {r['participant_id'] for r in rows}
            if len(pids) != 1:
                raise ValueError('Mixed or empty participant CSV.')
            pid = pids.pop()
        if pid not in configs or pid in grouped:
            raise ValueError('Unknown or repeated participant: '+str(pid))
        if len(rows) != 200 or {r['case_id'] for r in rows} != expected:
            raise ValueError('Missing, duplicate or foreign case IDs in '+str(path))
        for r in rows:
            if r['participant_id'] != pid or r['human_label'] not in HUMAN_LABELS:
                raise ValueError('Invalid identity/label.')
            if str(r['case_order']) != str(configs[pid]['case_ids'].index(r['case_id'])+1):
                raise ValueError('Wrong case_order.')
            t = float(r['response_time_seconds'])
            if not math.isfinite(t) or t < 0 or not isinstance(r['comment'], str):
                raise ValueError('Invalid response time/comment.')
            datetime.fromisoformat(r['timestamp'].replace('Z', '+00:00'))
            r['response_time_seconds'] = t
            for k in ('full_summary_opened','answer_changed'):
                r[k] = boolean(r[k])
        grouped[pid] = {r['case_id']:r for r in rows}
    assert len(grouped) == 3 and sum(map(len, grouped.values())) == 600
    return cases, grouped, audits, manifest


def consensus(votes):
    counts = Counter(votes)
    winners = [k for k,v in counts.items() if v == max(counts.values())]
    unique = len(winners) == 1
    label = winners[0] if unique else None
    majority = unique and counts[label] > len(votes)/2
    return dict(**{f'votes_{k}':counts[k] for k in HUMAN_LABELS},
                absolute_majority=majority, unique_plurality=unique,
                plurality_without_majority=unique and not majority,
                tie=not unique, consensus_label=label,
                three_class_consensus=majority and label in LABELS)


def alpha_nominal(units):
    units = [list(u) for u in units if len(u) >= 2]
    counts = Counter(x for unit in units for x in unit)
    n = sum(counts.values())
    if n < 2:
        return None
    observed = sum((len(u)**2-sum(v*v for v in Counter(u).values()))/(len(u)-1) for u in units)/n
    expected = (n*n-sum(v*v for v in counts.values()))/(n*(n-1))
    return 1-observed/expected if expected else None


def reliability(grouped):
    pids = sorted(grouped)
    ids = sorted(grouped[pids[0]])
    units = [[grouped[p][i]['human_label'] for p in pids] for i in ids]
    pairs = []
    for a,b in combinations(pids,2):
        n = sum(grouped[a][i]['human_label']==grouped[b][i]['human_label'] for i in ids)
        pairs.append(dict(participant_a=a,participant_b=b,agreements=n,n=len(ids),agreement=n/len(ids)))
    dist = Counter(v for u in units for v in u)
    return dict(n_cases=len(ids),n_ratings=sum(dist.values()),
        full_agreement_cases=sum(len(set(u))==1 for u in units),
        full_agreement=sum(len(set(u))==1 for u in units)/len(units),
        pairwise_agreement=sum(r['agreements'] for r in pairs)/(3*len(ids)),
        pairs=pairs,krippendorff_alpha_nominal=alpha_nominal(units),
        label_counts={k:dist[k] for k in HUMAN_LABELS},
        label_counts_by_participant={p:{k:sum(grouped[p][i]['human_label']==k for i in ids) for k in HUMAN_LABELS} for p in pids},
        special_rate=dist['special']/(3*len(ids)),
        cases_with_any_special=sum('special' in u for u in units))


def confusion(truth, pred):
    cm = [[0]*3 for _ in range(3)]
    for a,b in zip(truth,pred):
        cm[LABELS.index(a)][LABELS.index(b)] += 1
    return cm


def metrics_cm(cm):
    n = sum(map(sum,cm))
    correct = sum(cm[i][i] for i in range(3))
    per = []
    for i,label in enumerate(LABELS):
        support, predicted, tp = sum(cm[i]),sum(r[i] for r in cm),cm[i][i]
        p = tp/predicted if predicted else 0.0
        r = tp/support if support else None
        f = 2*tp/(support+predicted) if support+predicted else 0.0
        per.append(dict(label=label,support=support,predicted=predicted,precision=p,recall=r,f1=f))
    expected = sum(sum(cm[i])*sum(r[i] for r in cm) for i in range(3))/n**2 if n else None
    accuracy = correct/n if n else None
    return dict(n=n,correct=correct,errors=n-correct,error_rate=1-accuracy if n else None,
        accuracy=accuracy,macro_f1=sum(r['f1'] for r in per)/3 if n else None,
        cohen_kappa=(accuracy-expected)/(1-expected) if n and expected<1 else None,
        class_order=LABELS,confusion_matrix=cm,per_class=per,
        absent_truth_classes=[r['label'] for r in per if not r['support']])


def metrics(truth,pred):
    return metrics_cm(confusion(truth,pred))


def flat_metrics(m):
    out={k:m[k] for k in ('accuracy','macro_f1','cohen_kappa','error_rate')}
    for r in m['per_class']:
        for k in ('precision','recall','f1'):
            out[r['label']+'.'+k]=r[k]
    return out


def percentile(values,q):
    values=sorted(values)
    if not values:
        return None
    k=(len(values)-1)*q
    lo=math.floor(k)
    return values[lo]+(values[math.ceil(k)]-values[lo])*(k-lo)


def interval(values,attempts):
    values=[v for v in values if v is not None]
    return dict(lower=percentile(values,.025),upper=percentile(values,.975),
                valid_replicates=len(values),undefined_replicates=attempts-len(values))


def bootstrap(rows,repetitions=10000,seed=32):
    """Paired article-cluster percentile bootstrap; all cases of a drawn article travel together."""
    if not rows:
        return dict(status='NO_THREE_CLASS_CONSENSUS')
    names=['calibrated_scorer_label']+(['jev_label'] if all(r.get('jev_label') in LABELS for r in rows) else [])
    articles=sorted({r['article_id'] for r in rows})
    matrices={a:{name:confusion([r['consensus_label'] for r in rows if r['article_id']==a],
                              [r[name] for r in rows if r['article_id']==a]) for name in names} for a in articles}
    samples={name:defaultdict(list) for name in names}
    diffs=[]
    rng=random.Random(seed)
    for _ in range(repetitions):
        weights=Counter(rng.choices(articles,k=len(articles)))
        point={}
        for name in names:
            cm=[[sum(w*matrices[a][name][i][j] for a,w in weights.items()) for j in range(3)] for i in range(3)]
            point[name]=flat_metrics(metrics_cm(cm))
            for k,v in point[name].items():
                samples[name][k].append(v)
        if 'jev_label' in names:
            diffs.append(point['jev_label']['accuracy']-point['calibrated_scorer_label']['accuracy'])
    return dict(method='Paired article-cluster percentile bootstrap; 95% intervals; conditional on selected consensus cases.',
        seed=seed,repetitions=repetitions,article_clusters=len(articles),
        metrics={name:{k:interval(v,repetitions) for k,v in vals.items()} for name,vals in samples.items()},
        paired_accuracy_difference_jev_minus_calibrated=interval(diffs,repetitions) if diffs else None)


def mcnemar(b,c):
    n=b+c
    p=min(1.0,2*sum(math.comb(n,k) for k in range(min(b,c)+1))/2**n) if n else 1.0
    return dict(only_jev_correct=b,only_calibrated_correct=c,discordant=n,exact_two_sided_p=p,
                caveat='Supplementary only: ordinary exact McNemar assumes independent case pairs; within-article dependence is not corrected. Use article bootstrap for primary uncertainty.')


def import_jev(path,protocol_path,cases,manifest,root=ROOT):
    if not protocol_path:
        raise ValueError('--jev-protocol is required with --jev.')
    protocol=load_json(protocol_path)
    for k in ('model_version','model_digest','prompt_or_classification_definition','frozen_at','protocol_sha256'):
        if not protocol.get(k):
            raise ValueError('Missing frozen Jev metadata: '+k)
    body={k:v for k,v in protocol.items() if k!='protocol_sha256'}
    if hashlib.sha256(json.dumps(body,sort_keys=True,ensure_ascii=False).encode()).hexdigest()!=protocol['protocol_sha256']:
        raise ValueError('Jev protocol digest mismatch.')
    if protocol.get('status')!='FROZEN_BEFORE_HUMAN_INSPECTION' or protocol.get('dataset_id')!=manifest['dataset_id'] or protocol.get('input_sha256')!=sha(root/'intern/jev_inputs.json') or not isinstance(protocol.get('parameters'),dict):
        raise ValueError('Jev input/protocol is not frozen for this dataset.')
    rows=read_csv(path) if Path(path).suffix.lower()=='.csv' else load_json(path)
    ids={r['case_id'] for r in cases}
    if not isinstance(rows,list) or len(rows)!=200 or {r['case_id'] for r in rows}!=ids or any(r.get('jev_label') not in LABELS for r in rows):
        raise ValueError('Jev requires exactly 200 unique valid predictions for the same cases.')
    return {r['case_id']:r['jev_label'] for r in rows},protocol


def run(args):
    cases,grouped,audits,manifest=validate_ratings(args.ratings)
    if args.check_only:
        print('PASS: 200 unique cases; 3 independent participants; 600 valid ratings.')
        return
    if args.bootstrap<100:
        raise ValueError('Use at least 100 bootstrap replicates (default 10000).')
    jev,protocol=({},None)
    if args.jev:
        jev,protocol=import_jev(args.jev,args.jev_protocol,cases,manifest)
    joined=[]
    for c in cases:
        votes=[grouped[p][c['case_id']]['human_label'] for p in sorted(grouped)]
        joined.append({**c,**consensus(votes),'jev_label':jev.get(c['case_id'])})
    primary=[r for r in joined if r['three_class_consensus']]
    excluded=[r for r in joined if not r['three_class_consensus']]
    reliability_results=reliability(grouped)
    names=['calibrated_scorer_label']+(['jev_label'] if jev else [])
    estimates={name:metrics([r['consensus_label'] for r in primary],[r[name] for r in primary]) for name in names}
    paired=Counter()
    for r in primary:
        if jev:
            a,b=r['jev_label']==r['consensus_label'],r['calibrated_scorer_label']==r['consensus_label']
            r['paired_result']={(True,True):'both_correct',(True,False):'only_jev_correct',(False,True):'only_calibrated_correct',(False,False):'both_wrong'}[a,b]
            paired[r['paired_result']]+=1
    comparison=None
    if jev:
        comparison=dict(n=len(primary),counts={k:paired[k] for k in ('both_correct','only_jev_correct','only_calibrated_correct','both_wrong')},
            paired_accuracy_difference_jev_minus_calibrated=(paired['only_jev_correct']-paired['only_calibrated_correct'])/len(primary) if primary else None,
            mcnemar=mcnemar(paired['only_jev_correct'],paired['only_calibrated_correct']),
            scorer_agreement_all_200=metrics([r['calibrated_scorer_label'] for r in joined],[r['jev_label'] for r in joined]))
    by_group=[]
    for dimension in ('method','stage'):
        for val in sorted({r[dimension] for r in joined},key=str):
            subset=[r for r in primary if r[dimension]==val]
            for name in names:
                m=metrics([r['consensus_label'] for r in subset],[r[name] for r in subset])
                by_group.append(dict(dimension=dimension,value=val,scorer=name,**{k:m[k] for k in ('n','accuracy','macro_f1','cohen_kappa','errors')}))
    sensitivity={}
    for name,subset in [('unanimous_main_class',[r for r in primary if any(r['votes_'+k]==3 for k in LABELS)]),
                        ('no_special_vote',[r for r in primary if r['votes_special']==0])]:
        sensitivity[name]={s:metrics([r['consensus_label'] for r in subset],[r[s] for r in subset]) for s in names}
    report=dict(status='ANALYSIS_OF_OBSERVED_HUMAN_RATINGS',dataset_id=manifest['dataset_id'],
        completeness=dict(unique_cases=200,participants=3,ratings=600,missing=0,duplicate=0),
        presentation_versions=dict(Counter(r.get('presentation_version') or 'legacy_or_not_recorded' for g in grouped.values() for r in g.values())),
        consensus_counts=dict(three_class=len(primary),excluded=len(excluded),ties=sum(r['tie'] for r in joined),special_consensus=sum(r['consensus_label']=='special' for r in joined),absolute_majority=sum(r['absolute_majority'] for r in joined),unique_plurality=sum(r['unique_plurality'] for r in joined),plurality_without_majority=sum(r['plurality_without_majority'] for r in joined)),
        reliability=reliability_results,scorers=estimates,paired_comparison=comparison,
        bootstrap=bootstrap(primary,args.bootstrap,32),sensitivity=sensitivity,
        jev_status='FROZEN_PREDICTIONS_INCLUDED' if jev else 'MISSING: no paired comparison performed',
        jev_protocol=protocol,weighting='No population weighting: inclusion probabilities not reconstructed.',
        observable_answer_diagnostics=dict(
            not_found_count=sum(r['generated_answer'].strip().upper()=='NOT_FOUND' for r in joined),
            not_found_by_consensus=dict(Counter(r['consensus_label'] or 'tie' for r in joined if r['generated_answer'].strip().upper()=='NOT_FOUND')),
            retained_consensus_with_nonidentical_answer=sum(r['consensus_label']=='retained' and r['generated_answer'].casefold().strip()!=r['reference_answer'].casefold().strip() for r in joined),
            interpretation='These are observable answer/consensus combinations, not independently verified semantic error subtypes. NOT_FOUND plus special consensus alone does not establish information presence.'),
        metric_conventions='Fixed three-class Macro-F1; zero precision with no predictions; zero F1 with empty class; undefined recall and degenerate kappa are null. Confusion matrix rows=human consensus, columns=scorer. Undefined bootstrap values are reported, never silently filled.',
        limitations=['Agreement with majority is not proof of truth. Reliability is measured separately on all four human categories.',
            'Purposive enriched sample; unweighted metrics do not estimate population accuracy or experimental factual retention.',
            'Cluster bootstrap accounts for shared articles, conditional on this sample, fixed raters and available consensus. It does not model rater-population uncertainty or repair selection bias.',
            'Unsupported combines reference discordance and lack of support; do not call its frequency a hallucination rate.',
            'Subtype counts require independent manual verification; hints and comments are not validated subtype ground truth.',
            'No automatic statistical-superiority declaration. Ordinary McNemar is supplementary because cases share articles.'],
        source_sha256={str(p):sha(p) for p in args.ratings},jev_sha256=sha(args.jev) if args.jev else None)
    out=args.output
    out.mkdir(parents=True,exist_ok=False)
    save_json(out/'results.json',report)
    save_json(out/'annotation_audit.json',audits)
    save_csv(out/'consensus_all_200.csv',joined)
    save_csv(out/'excluded_no_three_class_consensus.csv',excluded,list(joined[0]))
    save_csv(out/'paired_case_results.csv',primary,list(dict.fromkeys([*joined[0],'paired_result'])))
    save_csv(out/'by_method_stage.csv',by_group)
    save_csv(out/'all_600_ratings.csv',[r for p in sorted(grouped) for r in grouped[p].values()])
    # No heuristic is counted as a confirmed error subtype. This is an unfilled audit worksheet.
    review=[]
    for r in joined:
        review.append({k:r[k] for k in ('case_id','article_id','method','stage','question','reference_answer','generated_answer','summary_text','consensus_label','calibrated_scorer_label','jev_label')} | dict(selection_hints=';'.join(r['selection_flags']),verified_subtype='',verification_evidence='',reviewer='',note='Hints are not confirmed subtypes.'))
    save_csv(out/'error_subtype_review_UNCODED.csv',review)
    text=f"# Auswertung der unabhängigen Human Validation\n\n200 Fälle, 600 gültige Urteile. Eindeutiger Drei-Klassen-Mehrheitskonsens: {len(primary)}/200. Ausgeschlossen: {len(excluded)}.\n\n"
    text+=f"Vollständige menschliche Übereinstimmung: {reliability_results['full_agreement']:.3f}; paarweise: {reliability_results['pairwise_agreement']:.3f}; nominales Alpha: {reliability_results['krippendorff_alpha_nominal']}.\n\n"
    for name,m in estimates.items():
        text+=f"- {name}: n={m['n']}; Accuracy={m['accuracy']}; Macro-F1={m['macro_f1']}; Kappa={m['cohen_kappa']}.\n"
    text+='\n95%-Intervalle und gepaarte Differenzen stehen in results.json; Falllisten und Gruppenmetriken in den CSV-Dateien. Jev-Status: '+report['jev_status']+'.\n\n'
    text+='\n\n'.join(report['limitations'])
    (out/'analysis_report.md').write_text(text+'\n',encoding='utf-8')
    print('Wrote observed-data analysis to',out)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ratings',nargs='+',type=Path)
    parser.add_argument('--jev',type=Path)
    parser.add_argument('--jev-protocol',type=Path)
    parser.add_argument('--bootstrap',type=int,default=10000)
    parser.add_argument('--output',type=Path,default=ROOT/'observed_results')
    parser.add_argument('--check-only',action='store_true')
    args=parser.parse_args()
    try:
        run(args)
    except (ValueError,KeyError,TypeError,FileNotFoundError) as exc:
        parser.exit(2,'Validation failed: '+str(exc)+'\n')
