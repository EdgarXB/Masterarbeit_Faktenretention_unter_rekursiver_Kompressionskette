"""Offline descriptive LLM-rater comparison. Never creates human study results.

Uses the frozen case registry and the existing, tested numerical functions.
The input field human_label is a legacy container name, not a claim of human origin.
"""
from pathlib import Path
from collections import Counter, defaultdict
from itertools import combinations
from datetime import datetime, timezone
import argparse
import hashlib
import json
import random
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import auswertung_human_validation as core

SCORERS = ('calibrated_scorer_label', 'original_scorer_label')
NAMES = {'calibrated_scorer_label':'Kalibrierter QA-Scorer',
         'original_scorer_label':'Rekonstruierte Regel vor Kalibrierung'}


def strict_json(path):
    def unique(pairs):
        obj = {}
        for key,value in pairs:
            if key in obj:
                raise ValueError('Duplicate JSON key: '+key)
            obj[key] = value
        return obj
    return json.loads(Path(path).read_text(encoding='utf-8-sig'),object_pairs_hook=unique)


def nominal_pair(a,b):
    labels=core.HUMAN_LABELS
    matrix=[[sum(x==u and y==v for x,y in zip(a,b)) for v in labels] for u in labels]
    n=len(a); matches=sum(x==y for x,y in zip(a,b))
    expected=sum(a.count(k)*b.count(k) for k in labels)/n**2 if n else None
    return dict(n=n,matches=matches,agreement=matches/n if n else None,
                cohen_kappa=(matches/n-expected)/(1-expected) if n and expected<1 else None,
                class_order=labels,confusion_matrix=matrix)


def validate(paths):
    # Reject ambiguous JSON before the reused format validator sees the files.
    objects=[strict_json(p) for p in paths]
    cases,grouped,_,manifest=core.validate_ratings(paths,ROOT)
    sources=[]
    for path,obj in zip(paths,objects):
        rows=list(obj['responses'].values())
        alias_count=0
        for row in rows:
            if 'label' in row:
                auxiliary='special' if row['label']=='unclear' else row['label']
                if auxiliary!=row['human_label']:
                    raise ValueError('Conflicting label and human_label: '+row['case_id'])
                alias_count+=row['label']=='unclear'
        sources.append(dict(rater_id=obj['participant_id'],filename=path.name,
            model_name_as_supplied=path.stem.removeprefix(obj['participant_id']+'_results_'),
            model_identity_evidence='Filename supplied by user; not verified against a provider model receipt.',
            sha256=core.sha(path),ratings=len(rows),label_counts=dict(Counter(r['human_label'] for r in rows)),
            presentation_versions=dict(Counter(r.get('presentation_version','unrecorded') for r in rows)),
            unclear_alias_in_auxiliary_label=alias_count,
            comments=sum(bool(r.get('comment')) for r in rows),
            interaction_metadata_used=False,review_metadata=obj.get('review_metadata'),
            missing_run_metadata=['verified_model_id_or_digest','full_prompt','generation_parameters','independent_execution_receipt']))
    return cases,grouped,manifest,sources


def estimates(rows):
    return {name:core.metrics([r['consensus_label'] for r in rows],[r[name] for r in rows]) for name in SCORERS}


def cluster_intervals(rows,repetitions,seed=32):
    if not rows:
        return dict(status='NO_MAIN_CLASS_LLM_MAJORITY')
    articles=sorted({r['article_id'] for r in rows})
    blocks={a:{s:core.confusion([r['consensus_label'] for r in rows if r['article_id']==a],
                              [r[s] for r in rows if r['article_id']==a]) for s in SCORERS} for a in articles}
    samples={s:defaultdict(list) for s in SCORERS}; differences=[]
    rng=random.Random(seed)
    for _ in range(repetitions):
        weights=Counter(rng.choices(articles,k=len(articles)));point={}
        for scorer in SCORERS:
            cm=[[sum(w*blocks[a][scorer][i][j] for a,w in weights.items()) for j in range(3)] for i in range(3)]
            point[scorer]=core.flat_metrics(core.metrics_cm(cm))
            for k,v in point[scorer].items():samples[scorer][k].append(v)
        differences.append(point[SCORERS[0]]['accuracy']-point[SCORERS[1]]['accuracy'])
    return dict(seed=seed,repetitions=repetitions,article_clusters=len(articles),
        method='95% percentile article-cluster bootstrap; paired predictions travel together; conditional on selected cases, observed LLM majority and these three model outputs.',
        scorers={s:{k:core.interval(v,repetitions) for k,v in vals.items()} for s,vals in samples.items()},
        calibrated_minus_original_accuracy=core.interval(differences,repetitions))


def run(paths,output,repetitions=10000):
    if repetitions<100:raise ValueError('At least 100 bootstrap draws required.')
    before={str(p):core.sha(p) for p in paths}
    cases,grouped,manifest,sources=validate(paths)
    for s in sources:s['path_relative_to_study']=str(next(p for p in paths if p.name==s['filename']).relative_to(ROOT))
    pids=sorted(grouped)
    joined=[]
    for c in cases:
        votes=[grouped[p][c['case_id']]['human_label'] for p in pids]
        joined.append(dict(c,**core.consensus(votes),
            **{p+'_llm_label':v for p,v in zip(pids,votes)},
            **{p+'_comment':grouped[p][c['case_id']]['comment'] for p in pids}))
    primary=[r for r in joined if r['three_class_consensus']]
    excluded=[r for r in joined if not r['three_class_consensus']]
    # Rename generic numerical output so no artifact claims these are human judgments.
    agreement=core.reliability(grouped)
    agreement['rater_type']='LLM'
    pairwise=[]
    for a,b in combinations(pids,2):
        pairwise.append(dict(rater_a=a,rater_b=b,**nominal_pair(
            [grouped[a][r['case_id']]['human_label'] for r in cases],
            [grouped[b][r['case_id']]['human_label'] for r in cases])))
    individual=[]
    common=[r for r in cases if all(grouped[p][r['case_id']]['human_label'] in core.LABELS for p in pids)]
    for p in pids:
        for set_name,population in [('own_main_labels',[r for r in cases if grouped[p][r['case_id']]['human_label'] in core.LABELS]),
                                    ('all_three_raters_main_labels',common)]:
            for scorer in SCORERS:
                m=core.metrics([grouped[p][r['case_id']]['human_label'] for r in population],[r[scorer] for r in population])
                individual.append(dict(rater_id=p,comparison_set=set_name,scorer=scorer,**m))
    sensitivities={name:estimates(subset) for name,subset in [
        ('unanimous_main_labels',[r for r in primary if any(r['votes_'+k]==3 for k in core.LABELS)]),
        ('no_special_vote',[r for r in primary if r['votes_special']==0])]} 
    both=Counter((r[SCORERS[0]]==r['consensus_label'],r[SCORERS[1]]==r['consensus_label']) for r in primary)
    metrics=estimates(primary)
    bootstrap=cluster_intervals(primary,repetitions)
    paired=dict(both_correct=both[True,True],only_calibrated_correct=both[True,False],
        only_original_correct=both[False,True],both_wrong=both[False,False],
        calibrated_minus_original_accuracy=metrics[SCORERS[0]]['accuracy']-metrics[SCORERS[1]]['accuracy'] if primary else None,
        supplementary_exact_mcnemar=dict(
            discordant=both[True,False]+both[False,True],
            two_sided_p=core.mcnemar(both[True,False],both[False,True])['exact_two_sided_p'],
            limitation='Assumes independent case pairs; shared articles violate that assumption. Supplementary only; article bootstrap is primary uncertainty.'))
    by_group=[]
    for dimension in ('method','stage'):
        for value in sorted({r[dimension] for r in joined},key=str):
            sub=[r for r in primary if r[dimension]==value]
            for scorer,m in estimates(sub).items():
                by_group.append(dict(dimension=dimension,value=value,scorer=scorer,**{k:m[k] for k in ('n','correct','errors','accuracy','macro_f1','cohen_kappa')}))
    findings=[]
    limitations=[
        'Automated LLM judgments, not human validation or proof of factual truth. Different claimed model families do not establish independent errors.',
        'Model names and medium settings are supplied in filenames; full prompts, verified version/digest, parameters and independent run receipts are missing.',
        'Browser interaction fields and timestamps from model-generated JSON are not treated as measured behavior or verified run times.',
        'The targeted difficult-case sample is not representative of the full main experiment. No fabricated sampling weights are used.',
        'Special votes are kept as a fourth nominal category for agreement. Ties and special-majority cases are excluded from three-class scorer comparisons; retained coverage is reported.',
        'Scorer accuracy is agreement with LLM majority, not LLM accuracy against external truth. A majority including a model itself is not an independent benchmark for ranking those models.',
        'Bootstrap intervals are conditional on fixed model outputs and consensus cases; they do not cover model/run/prompt uncertainty or selection bias.',
        'Unsupported is not synonymous with proven hallucination; comments are qualitative claims, not verified error subtype counts.',
        'No new Jev predictions or verified Jev model metadata are available; a Jev versus calibrated comparison is not possible.']
    findings.append(dict(severity='high',topic='Model provenance',evidence='All three inputs lack a complete, independently verifiable model/run protocol.',action='Retain exact prompts, provider model IDs/versions, settings, input artifacts and execution receipts for reproducibility.'))
    findings.append(dict(severity='medium',topic='Interaction metadata',evidence='Interaction values were generated or unmeasured; one input explicitly states no browser interaction.',action='Exclude these fields from timing and effort analyses.'))
    result=dict(status='LLM_RATER_COMPARISON_NOT_HUMAN_VALIDATION',created_at_utc=datetime.now(timezone.utc).isoformat(),
        dataset_id=manifest['dataset_id'],sources=sources,
        completeness=dict(cases=200,llm_raters=3,llm_judgments=600,missing=0,duplicates=0,valid_ids=True,matching_case_orders=True),
        source_field_policy='human_label is used as the submitted label; auxiliary label=unclear is accepted only when equivalent to special. Raw files are never rewritten.',
        consensus=dict(main_class_majority_cases=len(primary),excluded_cases=len(excluded),
            ties=sum(r['tie'] for r in joined),special_majority_cases=sum(r['consensus_label']=='special' for r in joined),
            all_four_class_counts=dict(Counter(r['consensus_label'] or 'tie' for r in joined)),
            main_consensus_coverage=len(primary)/200),
        agreement=agreement,pairwise=pairwise,scorers_against_llm_majority=metrics,
        article_cluster_bootstrap=bootstrap,individual_reference_comparisons=individual,
        common_non_special_case_count=len(common),sensitivities=sensitivities,
        paired_calibrated_vs_reconstructed_original=paired,
        jev_status='NOT_AVAILABLE_FOR_NEW_CASES',data_quality_findings=findings,limitations=limitations,
        input_sha256=before,frozen_manifest_sha256=core.sha(ROOT/'human_validation_manifest.json'),
        analysis_code_sha256=core.sha(Path(__file__)),numerical_core_sha256=core.sha(ROOT/'auswertung_human_validation.py'))
    assert all(core.sha(p)==h for p,h in before.items()),'Input files changed'
    assert sum(result['consensus']['all_four_class_counts'].values())==200
    assert sum(paired[k] for k in ('both_correct','only_calibrated_correct','only_original_correct','both_wrong'))==len(primary)
    output.mkdir(parents=True,exist_ok=False)
    core.save_json(output/'llm_results.json',result)
    exported=[]
    for r in joined:
        row={k:v for k,v in r.items() if k!='three_class_consensus'}
        row['llm_main_class_majority']=r['three_class_consensus']
        for s in SCORERS:row[s+'_matches_llm_majority']=r[s]==r['consensus_label'] if r['three_class_consensus'] else ''
        exported.append(row)
    core.save_csv(output/'all_200_cases_llm_consensus.csv',exported)
    fields=list(exported[0])
    core.save_csv(output/'excluded_special_or_tie.csv',[r for r in exported if not r['llm_main_class_majority']],fields)
    core.save_csv(output/'calibrated_disagreements.csv',[r for r in exported if r['llm_main_class_majority'] and not r['calibrated_scorer_label_matches_llm_majority']],fields)
    core.save_csv(output/'individual_scorer_comparisons.csv',[{k:r[k] for k in ('rater_id','comparison_set','scorer','n','correct','errors','accuracy','macro_f1','cohen_kappa')} for r in individual])
    core.save_csv(output/'by_method_stage.csv',by_group)
    core.save_csv(output/'all_600_llm_judgments.csv',[dict(rater_id=p,case_id=cid,llm_label=r['human_label'],comment=r['comment'],presentation_version=r.get('presentation_version','unrecorded')) for p in pids for cid,r in grouped[p].items()])
    core.save_csv(output/'class_distributions.csv',[dict(rater_id=s['rater_id'],model_name_as_supplied=s['model_name_as_supplied'],**{k:s['label_counts'].get(k,0) for k in core.HUMAN_LABELS}) for s in sources])
    core.save_json(output/'input_metadata_audit.json',sources)
    lines=['# LLM-Rater-Vergleich – keine Human Validation','',
        'Ausgewertet werden die drei neu hochgeladenen LLM-Ausgaben; frühere Mock-Dateien und historische menschliche Urteile werden nicht hinzugemischt.',
        '',f"200 gemeinsame Fälle, 600 gültige LLM-Urteile. Eindeutige Drei-Klassen-Mehrheit: **{len(primary)}/200**; Sonderfallmehrheit: **{result['consensus']['special_majority_cases']}**; Gleichstände: **{result['consensus']['ties']}**.",'',
        '| Scorer gegen LLM-Mehrheit | Richtig / auswertbar | Accuracy | 95%-Artikel-Cluster-Intervall | Macro-F1 | Kappa |',
        '|---|---:|---:|---|---:|---:|']
    for s,m in metrics.items():
        ci=bootstrap.get('scorers',{}).get(s,{}).get('accuracy',{})
        interval=f"{ci['lower']:.1%} bis {ci['upper']:.1%}" if ci.get('lower') is not None else 'undefiniert'
        lines.append(f"| {NAMES[s]} | {m['correct']} / {m['n']} | {m['accuracy']:.1%} | {interval} | {m['macro_f1']:.3f} | {m['cohen_kappa']:.3f} |" if m['n'] and m['cohen_kappa'] is not None else f"| {NAMES[s]} | {m['correct']} / {m['n']} | siehe JSON | {interval} | siehe JSON | siehe JSON |")
    lines+=['',f"Vollständige Übereinstimmung aller drei Modelle: {agreement['full_agreement_cases']}/200 ({agreement['full_agreement']:.1%}). Paarweise Gesamtübereinstimmung: {agreement['pairwise_agreement']:.1%}. Nominales Krippendorff-Alpha über vier Klassen: {agreement['krippendorff_alpha_nominal']:.3f}.",'',
        '| Eingabe (Modellname laut Dateiname) | Retained | Lost | Unsupported | Sonderfall |','|---|---:|---:|---:|---:|']
    for s in sources:lines.append('| '+s['model_name_as_supplied']+' | '+' | '.join(str(s['label_counts'].get(k,0)) for k in core.HUMAN_LABELS)+' |')
    lines+=['','## Vergleich zu jedem einzelnen Modell','',
        'Hier ist der jeweilige LLM-Rater die Referenz; seine Sonderfälle sind ausgeschlossen. Unterschiedliche Nenner erlauben keine Rangfolge der Modellqualität.',
        '','| Referenz-Rater | Kalibrierter Scorer stimmt überein | Accuracy |','|---|---:|---:|']
    for p in pids:
        v=next(v for v in individual if v['rater_id']==p and v['comparison_set']=='own_main_labels' and v['scorer']==SCORERS[0])
        lines.append(f"| {p} | {v['correct']} / {v['n']} | {v['accuracy']:.1%} |")
    lines+=['','## Methodik und Grenzen','',
        'Die vier Klassen gehen vollständig in die Übereinstimmungsanalyse ein. Eine Hauptklassenmehrheit erfordert mindestens zwei von drei Stimmen; eine Sonderfall-Minderheitsstimme wird nicht entfernt. Eine Sonderfallmehrheit oder drei unterschiedliche Stimmen führen zum Ausschluss aus dem Drei-Klassen-Scorervergleich. Alle Ausschlüsse sind als Fallliste dokumentiert.',
        '',f'Unsicherheit: {repetitions:,} gepaarte Artikel-Cluster-Resamples, Seed 32, 95%-Perzentilintervalle; alle Fälle eines gezogenen Artikels reisen gemeinsam. Keine erfundenen Auswahlgewichte. Sensitivitäten für einstimmige Urteile und Fälle ohne Sonderfallstimme stehen in llm_results.json.',
        '',*['- '+x for x in limitations],
        '','## Dateien und Reproduktion','',
        '`llm_results.json` enthält alle Metriken, Konfusionsmatrizen, Intervalle und Quellenhashes. `calibrated_disagreements.csv` enthält die konkret abweichenden Fälle einschließlich Texte und LLM-Kommentare. `all_200_cases_llm_consensus.csv` erhält alle Fall- und Stimmeninformationen. Timingfelder werden bewusst nicht in die 600-Zeilen-Analysedatei übernommen.',
        '','Aus dem Studienordner in einen neuen Ausgabeordner starten:',
        '','```bash','python3 -B llm_auswertung/auswertung_llm_rater.py --output llm_auswertung/erneute_auswertung','```','',
        'Die ursprünglichen JSON-Dateien, die HTML-Anwendung, die Teilnehmerkonfigurationen und das eingefrorene Hauptexperiment bleiben unverändert. Die Herkunftsnamen sind Angaben der Dateien; die tatsächlichen Modellversionen und die behauptete Unabhängigkeit wurden nicht extern verifiziert.']
    (output/'README_AUSWERTUNG.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    summary={'status':result['status'],'consensus':result['consensus'],'agreement':{k:agreement[k] for k in ('full_agreement_cases','full_agreement','pairwise_agreement','krippendorff_alpha_nominal')},
             'scorers':{s:{k:m[k] for k in ('n','correct','accuracy','macro_f1','cohen_kappa')} for s,m in metrics.items()},'output':str(output)}
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=ROOT/'llm_bewertungen')
    parser.add_argument('--output',type=Path,default=ROOT/'llm_auswertung/ergebnisse_20261017')
    parser.add_argument('--bootstrap',type=int,default=10000)
    args=parser.parse_args()
    try:run(sorted(args.input.glob('*.json')),args.output,args.bootstrap)
    except (ValueError,KeyError,TypeError,OSError) as e:parser.exit(2,'Validation failed: '+str(e)+'\n')
