# Quellenprüfung und Abgrenzung

Die vorhandenen Quellen sind für die Vorbereitung geeignet. Die neue menschliche Erhebung und ein verifizierbarer Jev-Lauf stehen aus. Die technische Vorbereitung ersetzt diese beiden Erhebungen nicht.

## Autorität und Körnung

Maßgeblich ist `Masterarbeit_Abgabe/02_Auswertung/hauptexperiment_qa_daten/`, Standardfassung `aktuell_20260930` laut archiviertem `source_manifest.json`. Die QA-Körnung ist Artikel × Methode × Wortstufe × kanonischer Fakt. Stabile Quellschlüssel enthalten zusätzlich den Versionsnamensraum. Die vier Stufen sind rekursive Zusammenfassungen, keine vier unabhängigen Artikel.

| Quelle | Zeilen | Join und Prüfung |
|---|---:|---|
| shared/test_articles.csv.gz | 100 | Eindeutige Originalartikel |
| shared/canonical_facts.csv.gz | 2.000 | Kanonische Fakt-ID; Frage und Referenz identisch zu den QA-Zeilen |
| aktuell_20260930/summaries.csv.gz | 600 | Artikel × Methode; vier Summaryspalten pro Zeile |
| aktuell_20260930/answers.csv.gz | 48.000 | Vollständiger zusammengesetzter QA-Schlüssel |
| aktuell_20260930/scored_archived.csv.gz | 48.000 | Alle gespeicherten Antwortfelder byteinhaltlich identisch zum Antwortenexport |
| human_validation_qa_daten/qa/human_validation_annotation.csv | 60 | Ausschlussliste; lokale IDs des historischen Experiments |
| historischer selected_articles_10.csv | 10 | Vollständige Originaltexte, anderer Pilotbestand |

Archivierte SHA-256-Hashes der gelesenen Hauptdaten werden vor dem Extrahieren geprüft. Das archivierte kalibrierte Scoring wird auf allen eindeutigen gültigen Kandidaten aus den gespeicherten Antworten reproduziert und mit den archivierten Labels abgeglichen. Die verwendeten Quellen werden nach dem Aufbau und in den Tests erneut gehasht; kein Quellschreibvorgang ist implementiert. Quellhashes und genaue Pfade stehen im Studienmanifest.

## Vollständigkeit, Ausschlüsse und Duplikate

Von 48.000 QA-Positionen werden 196 technische Fehlwerte ausgeschlossen. Im verbleibenden Bestand werden 1.529 normalisierte inhaltsidentische Frage/Referenz/Antwort/Summary-Kombinationen zusammengeführt (erster Datensatz in archivierter Reihenfolge bleibt erhalten). Es verbleiben 46.275 Kandidaten: 24.267 retained, 17.012 lost und 4.996 unsupported nach dem archivierten kalibrierten Scorer. Es fehlen keine zum ausgewählten Fall gehörenden Fakten oder Summarytexte; der Join wird durch Assertions abgesichert. `evidence_quote` ist ein Beleg aus dem Originalartikel und wird nicht als Beweis für die Unterstützung durch das Summary behandelt oder den Bewertenden eingeblendet.

Die 60 historischen Fälle sind nach ID-Namensraum, normalisierten Frage/Referenz-Paaren, Fakten und QA-Gesamtinhalten ausgeschlossen. Im finalen Bestand wurden keine inhaltlichen Überschneidungen festgestellt. Zusätzlich ergibt der normalisierte Volltext-Hashvergleich aller zehn historischen Pilotartikel mit allen 100 aktuellen Testartikeln null Überschneidungen. Historische `article_id=1` bezeichnet einen anderen Text als finale `article_id=1`; ein bloßer numerischer ID-Antijoin wäre fachlich falsch. Die historischen Artikel stammen aus dem Train-Split, die finalen aus dem Test-Split; Datensatzindices verschiedener Splits sind ebenfalls keine globalen Identitäten.

Die vorbereitete Auswahl enthält 200 unterschiedliche Fälle, alle 100 Artikel, alle 24 Methoden-Stufen-Kombinationen, 50 Fälle je Wortstufe und 33–34 Fälle je Methode. Die Quoten 80/80/40 beziehen sich auf vorläufige Scorerlabels, nicht auf menschliche Ergebnisse. Exakte Zählwerte und Texthinweise stehen in `berichte/source_profile.json` und im Manifest. Die zusätzlich genutzten Übungsfälle sind echte, disjunkte Datensätze und werden separat nachgewiesen.

## Wesentliche Definitionskonflikte

**Hoch, bestätigt:** Der kalibrierte Scorer (`code/score_model_selection_batch.py`, Funktionen `retained`, `retention_token_f1`, `score_qa`) bekommt im Retentionvergleich Referenz und Antwort. Er klassifiziert NOT_FOUND als Verlust und nicht passende andere Antworten als Referenzabweichung; er prüft nicht semantisch, ob die vollständige Zusammenfassung die Antwort stützt oder den Fakt enthält. Das archivierte `unsupported_or_hallucinated` ist ausdrücklich ein rückwärtskompatibler Alias von `reference_discordant_answer`. Daher sind weder seine Unsupported-Quote noch die neue menschliche zusammengesetzte Unsupported-Klasse automatisch eine Halluzinationsrate. Die neuen Regeln sind präziser als historische Lost-Definitionen, die fehlende Information unabhängig vom Antwortstring beschreiben konnten. Historische Labels bleiben unverändert.

**Hoch, bestätigt:** Die vorhandenen Jev-Ergebnisse unter `jev_scorer_test/` beziehen sich auf die bereits zur Kalibrierung verwendeten 60 Fälle. `jev_kennzahlen.json` hält fest, dass Version, Prompt und Parameter nicht mitgeliefert und nicht rekonstruierbar sind. Für die neuen 200 Fälle gibt es daher weder bestätigte Jev-Labels noch einen bestätigten Modelldigest. Neue Labels werden erst nach separatem eingefrorenem Lauf akzeptiert. Die echte Jev-Schnittstelle kann ohne diese Angaben nicht implementiert oder verifiziert werden; vorbereitet sind verblindete Eingaben, Metadatenfreeze und strenger späterer Import.

**Hoch, designbedingt:** Die beschränkte Stichprobe priorisiert schwierige Konstellationen. Die meisten vorläufigen Retained-Fälle enthalten einen kalibrierungsbedingten Unterschied zur rekonstruierten Originalregel; viele vorläufige Lost-Fälle haben einen wörtlichen Referenzphrasenhinweis. Das ist eine absichtliche Herausforderung, keine Schätzung der typischen Fehlerquote des Hauptexperiments. Es gibt keine wissenschaftlich begründbaren Inklusionsgewichte. Ein wörtlicher Referenzhinweis beweist keine Beantwortbarkeit; kurze Namen/Zahlen können in anderem Kontext erscheinen. Es werden keine entsprechenden Fehlerhäufigkeiten vorweggenommen.

**Mittel, dokumentiert:** `original_scorer_label` wird nach der in der historischen Kalibrierungsdokumentation festgehaltenen ursprünglichen Regel auf denselben aktuellen Antworten rekonstruiert. `original_frozen` ist eine andere Experimentfassung mit teilweise anderen Antworten, kein allgemeiner Ersatz für das Label vor Kalibrierung. Rekonstruktionsprovenienz steht explizit im Manifest.

**Mittel, dokumentiert:** Aktive Zeit ist eine Interaktionsnäherung. Hintergrund, Fokusverlust und Zeit nach 60 Sekunden Interaktionsruhe werden ausgeschlossen. Längeres stilles Lesen kann unterschätzt werden. Kein Zeitraum einer geschlossenen Anwendung wird angerechnet.

## Noch ausstehend

Drei echte, voneinander unabhängige vollständige Rückgaben; konkrete Jev-Version/Digest/Definition/Parameter; separater Jev-Lauf mit Receipt; anschließend Beobachtungsdatenanalyse und gegebenenfalls belegte qualitative Fehlerkodierung. Es wurden keine empirischen Human-Ergebnisse erzeugt. Technische Tests verwenden ausschließlich ausdrücklich künstliche, anschließend gelöschte temporäre Prüfdaten.

## Methodische Referenzen

Die nominale Reliabilitätsmessung ist an der Alpha-Definition orientiert: [Hughes, 2021, R Journal](https://journal.r-project.org/articles/RJ-2021-046/). Der ergänzende exakte McNemar-Test verwendet die binomiale Variante gemäß [statsmodels-Methodendokumentation](https://www.statsmodels.org/dev/generated/statsmodels.stats.contingency_tables.mcnemar.html). Die eigentlichen Kennzahlen werden in Standardbibliothek-Python berechnet und gegen bekannte Rechenbeispiele getestet; keine neue statistische Bibliothek ist zur Durchführung erforderlich.

## Angegebene Summary-Passagen (Darstellungsrevision v2)

119 der 200 Fälle haben eine wortwörtlich im Summary vorhandene QA-Support-Passage, eine weitere stimmt nach Entfernen äußerer Anführungszeichen und Angleichung von Groß-/Kleinschreibung bzw. Leerraum überein. Angezeigt wird stets die unveränderte tatsächlich gefundene Textspanne. Bei 80 Fällen ist keine solche Passage angegeben; hier bleibt die bisherige Lesehilfe. Originalartikelbelege werden nicht als Summary-Passagen verwendet. Das Auftreten einer Zeichenfolge beweist noch keine inhaltliche Unterstützung. Die modellextrahierte Auswahl kann Aufmerksamkeit lenken und wird als Bestandteil der Anzeige dokumentiert. Die Stichprobe und bisherige Zwischenstände bleiben erhalten; neue Urteile erhalten eine Darstellungsversionsangabe.
