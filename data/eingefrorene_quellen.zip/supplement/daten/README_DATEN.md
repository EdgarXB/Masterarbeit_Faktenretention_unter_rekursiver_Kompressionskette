# Daten und Herkunft

`hauptexperiment/` enthält den von den drei QA-Notebooks tatsächlich verwendeten Ausschnitt aus dem eingefrorenen Abgabepaket: Originalartikel, Fakten, Fragen, Referenzantworten, QA-Antworten, vollständige Zusammenfassungen, Scorerlabels, Kettenzustände, archivierte Artikelstatistiken, Längenvergleiche und unveränderte Definitions-/Quelltexte. Es ist kein neues Experiment und keine neu erzeugte Modellantwort. Die Originalmanifeste bleiben als historische Herkunftsnachweise erhalten; sie nennen auch Dateien des größeren Originalarchivs, die für diese vier Analysen nicht benötigt werden.

Referenznotebooks aus dem Archiv liegen bytegleich als `*.quellnotebook.json` vor. Das sind lesbare JSON-Quellen, aus denen die Arbeitsnotebooks nur benötigte Funktionen/Definitionen lesen. Dadurch enthält das Paket genau vier ausführbare Arbeitsnotebooks.

`llm_vergleich/eingaben/` enthält unverändert die drei hochgeladenen LLM-Dateien. `evaluation_cases.json` enthält alle 200 tatsächlichen Falltexte, Identitäten, Methoden, Stufen und Scorerlabels. Teilnehmerkonfigurationen und Studienmanifest dokumentieren Reihenfolgen, Seed und Auswahl. `referenz_auswertung.json` ist der bereits ausgeführte Kontrolllauf; das neue Notebook berechnet die zentralen Kennzahlen und Intervalle neu und vergleicht sie damit.

QA-Körnung: Artikel × Methode × Zielstufe × Fakt. 100 Artikel, 2.000 kanonische Fakten, sechs Methoden und vier Stufen ergeben 48.000 QA-Positionen. Technische Fehlwerte sind keine Lost-Urteile. Der archivierte Alias `unsupported_or_hallucinated` ist eine Referenzabweichung und kein unabhängiger Halluzinationsnachweis. Details stehen in den jeweiligen Notebooks.

`quellen_und_kopierpruefung.json` nennt ursprüngliche Quellenpfade und SHA-256-Werte. Historische absolute Pfade sind Herkunftsangaben; die vier Arbeitsnotebooks lesen ausschließlich relative Paketdateien. Ausführungsdaten und Diagramme liegen unter `ergebnisse/`. Große gespeicherte NPZ-Dateien erhalten Bootstrap-/Simulationsergebnisse und vermeiden unnötige Neuberechnungen. LLM-Interaktionsfelder sind keine gemessenen menschlichen Bearbeitungsdaten.
