# 4.4 Verlustmuster

Die explorative Auswertung zu F4 verfolgte 2.000 kanonische Ausgangsfakten aus 100 Testartikeln (20 je Artikel) unter sechs Verfahren über 500, 300, 150 und 75 Zielwörter. Die Analyseeinheit war die Faktenlaufbahn, identifiziert durch Artikel-ID, kanonische Fakten-ID und Verfahren; insgesamt lagen 12.000 Laufbahnen mit 48.000 QA-Positionen vor. Verwendet wurde ausschließlich aktuell_20260930, einschließlich der ersetzten Plain- und Few-Shot-CoT-Ketten.

Nicht Retained fasst die tatsächlichen Quelllabels Lost und reference_discordant zusammen. Ein separates Unsupported-Label liegt nicht vor; Referenzabweichungen sind kein Halluzinationsnachweis. Die 196 technischen QA-Fehlwerte wurden nicht als Verlust gewertet. Ein Fehlwert vor einem ersten beobachteten Nicht-Retained-Label oder in einer ansonsten vollständig Retained-bewerteten Laufbahn verhindert die eindeutige Bestimmung der ersten Stufe. Fehlwerte nach einer eindeutig bestimmten ersten Stufe können die Persistenz offenlassen. Die erste Stufe 500 bezeichnet bereits eine Zusammenfassung.

## 4.4.1 Verlust entlang der Kompressionskette

Abbildung 4.4a zeigt je Verfahren die erste eindeutig bestimmbare Nicht-Retained-Stufe und die bis 75 durchgehend Retained-bewerteten Laufbahnen. Der Nenner beträgt stets 2.000 Ausgangsfakten je Verfahren; die unbestimmbaren Laufbahnen bleiben als eigene Kategorie erhalten.

Lead-k: erstmals nicht Retained bei 500 Wörter: 487/2.000 (24,3 %); 300 Wörter: 532/2.000 (26,6 %); 150 Wörter: 388/2.000 (19,4 %); 75 Wörter: 254/2.000 (12,7 %). Durchgehend Retained blieben 332/2.000 (16,6 %); 7/2.000 (0,4 %) waren bezüglich der ersten Stufe nicht eindeutig bestimmbar.

Plain: erstmals nicht Retained bei 500 Wörter: 898/2.000 (44,9 %); 300 Wörter: 122/2.000 (6,1 %); 150 Wörter: 101/2.000 (5,1 %); 75 Wörter: 229/2.000 (11,5 %). Durchgehend Retained blieben 634/2.000 (31,7 %); 16/2.000 (0,8 %) waren bezüglich der ersten Stufe nicht eindeutig bestimmbar.

Zero-Shot-CoT: erstmals nicht Retained bei 500 Wörter: 560/2.000 (28,0 %); 300 Wörter: 103/2.000 (5,1 %); 150 Wörter: 295/2.000 (14,8 %); 75 Wörter: 489/2.000 (24,4 %). Durchgehend Retained blieben 544/2.000 (27,2 %); 9/2.000 (0,4 %) waren bezüglich der ersten Stufe nicht eindeutig bestimmbar.

Few-Shot-CoT: erstmals nicht Retained bei 500 Wörter: 710/2.000 (35,5 %); 300 Wörter: 82/2.000 (4,1 %); 150 Wörter: 222/2.000 (11,1 %); 75 Wörter: 323/2.000 (16,2 %). Durchgehend Retained blieben 638/2.000 (31,9 %); 25/2.000 (1,2 %) waren bezüglich der ersten Stufe nicht eindeutig bestimmbar.

Auto-CoT: erstmals nicht Retained bei 500 Wörter: 569/2.000 (28,4 %); 300 Wörter: 88/2.000 (4,4 %); 150 Wörter: 228/2.000 (11,4 %); 75 Wörter: 381/2.000 (19,1 %). Durchgehend Retained blieben 717/2.000 (35,9 %); 17/2.000 (0,9 %) waren bezüglich der ersten Stufe nicht eindeutig bestimmbar.

Automate-CoT: erstmals nicht Retained bei 500 Wörter: 529/2.000 (26,5 %); 300 Wörter: 114/2.000 (5,7 %); 150 Wörter: 315/2.000 (15,8 %); 75 Wörter: 329/2.000 (16,4 %). Durchgehend Retained blieben 691/2.000 (34,5 %); 22/2.000 (1,1 %) waren bezüglich der ersten Stufe nicht eindeutig bestimmbar.

Für die Persistenz wurden nur Laufbahnen mit eindeutiger erster Nicht-Retained-Stufe vor 75 betrachtet. Laufbahnen mit erstem Label bei 75 haben keine beobachtete Folgestufe und zählen nicht als Nachweis anhaltender Nicht-Retention.

Bei Lead-k blieben 1384/1407 (98,4 %) der betreffenden Laufbahnen danach auf allen Stufen nicht Retained. Bei 21/1407 (1,5 %) erschien später mindestens ein Retained-Label; bei 2/1407 blieb die Persistenz wegen späterer technischer Fehlwerte offen.

Bei Plain blieben 1064/1121 (94,9 %) der betreffenden Laufbahnen danach auf allen Stufen nicht Retained. Bei 53/1121 (4,7 %) erschien später mindestens ein Retained-Label; bei 4/1121 blieb die Persistenz wegen späterer technischer Fehlwerte offen.

Bei Zero-Shot-CoT blieben 882/958 (92,1 %) der betreffenden Laufbahnen danach auf allen Stufen nicht Retained. Bei 72/958 (7,5 %) erschien später mindestens ein Retained-Label; bei 4/958 blieb die Persistenz wegen späterer technischer Fehlwerte offen.

Bei Few-Shot-CoT blieben 919/1014 (90,6 %) der betreffenden Laufbahnen danach auf allen Stufen nicht Retained. Bei 86/1014 (8,5 %) erschien später mindestens ein Retained-Label; bei 9/1014 blieb die Persistenz wegen späterer technischer Fehlwerte offen.

Bei Auto-CoT blieben 789/885 (89,2 %) der betreffenden Laufbahnen danach auf allen Stufen nicht Retained. Bei 92/885 (10,4 %) erschien später mindestens ein Retained-Label; bei 4/885 blieb die Persistenz wegen späterer technischer Fehlwerte offen.

Bei Automate-CoT blieben 872/958 (91,0 %) der betreffenden Laufbahnen danach auf allen Stufen nicht Retained. Bei 81/958 (8,5 %) erschien später mindestens ein Retained-Label; bei 5/958 blieb die Persistenz wegen späterer technischer Fehlwerte offen.

Der größte beobachtete Paaranteil Retained → nicht Retained bei Lead-k trat bei 500→300 auf: 532/1994 (26,7 %) gültige Paare. Bezogen auf die gültigen Paare mit Retained-Ausgangslabel waren es 532/1507 (35,3 %). Diese Auswahl des größten Anteils ist deskriptiv.

Der größte beobachtete Paaranteil Retained → nicht Retained bei Auto-CoT trat bei 150→75 auf: 408/1985 (20,6 %) gültige Paare. Bezogen auf die gültigen Paare mit Retained-Ausgangslabel waren es 408/1153 (35,4 %). Diese Auswahl des größten Anteils ist deskriptiv.

Bei Lead-k wurden folgende Rückwechsel nicht Retained → Retained beobachtet: 500→300: 10/1994 gültige Paare (0,5 %), bedingt 10/487 (2,1 %); 300→150: 9/1994 gültige Paare (0,5 %), bedingt 9/1009 (0,9 %); 150→75: 4/1996 gültige Paare (0,2 %), bedingt 4/1393 (0,3 %).

Bei Lead-k waren 300/300 geprüften Stufenpaaren verschachtelte Präfixe. Die exemplarische Textprüfung zeigte bei Artikel 14, Fakt 14_F08, trotz NOT_FOUND bei 150 und Retained bei 75 denselben späteren Beleg bereits im längeren Text. Bei Artikel 15, Fakt 15_F09, änderte sich die Antwortauswahl bei einer bereits vorhandenen Club-Liste. Rückwechsel belegen somit zunächst Änderungen automatischer QA-Urteile, keine tatsächliche Wiedergewinnung verschwundener Information. Fünf gezielt ausgewählte Beispiele samt vollständigen Texten stehen im Notebook-Anhang; sie erlauben keine Schätzung der QA-Fehlerrate.

## 4.4.2 Unterschiede nach Entitätstyp

Abbildung 4.4b zeigt Retained / gültige QA-Urteile je Entitätstyp, Verfahren und Zielstufe. Dieser Anteil ist faktengewichtet, im Unterschied zu den gleichgewichteten Artikelmitteln in 4.2. Die punktweisen 95-%-Perzentilintervalle verwenden 10.000 Artikelbootstrap-Ziehungen mit Seed 32; alle Fakten, Verfahren und Stufen eines Artikels bleiben gemeinsam. Die Intervalle berücksichtigen die Artikelheterogenität, keine Unsicherheit der automatischen Bewertung. Es gibt keine vorab festgelegte Typenrangfolge; sämtliche Vergleiche bleiben explorativ.

Die Fallzahlen der acht Entitätstypen betrugen: NUMBER: 526 Ausgangsfakten in 96 Artikeln; PERSON: 420 Ausgangsfakten in 97 Artikeln; LOCATION: 255 Ausgangsfakten in 93 Artikeln; DATE_TIME: 216 Ausgangsfakten in 90 Artikeln; OTHER: 181 Ausgangsfakten in 74 Artikeln; OBJECT: 168 Ausgangsfakten in 67 Artikeln; ORG: 154 Ausgangsfakten in 77 Artikeln; EVENT: 80 Ausgangsfakten in 53 Artikeln. Kleine Gruppen werden bei weniger als 100 Fakten oder 30 Artikeln markiert; damit ist EVENT (80 Fakten, 53 Artikel) als relativ kleine Gruppe gekennzeichnet. Die zugrunde liegenden Fakten werden einmal gezählt, nicht erneut pro Verfahren oder Stufe.

Im gepoolten Übergangsvergleich der fünf generativen Verfahren war der bedingte Verlustanteil — unter gültigen Ausgangsfällen mit Retained-Label — bei folgenden Typen am höchsten: 500→300: OBJECT 36/375 = 9,6 % (95-%-KI [6,4; 13,5]); 300→150: LOCATION 132/475 = 27,8 % (95-%-KI [22,2; 33,7]); 150→75: OBJECT 117/273 = 42,9 % (95-%-KI [34,3; 52,6]). Nach Nettoänderung, bei der Rückwechsel abgezogen werden, lauten die höchsten Werte: 500→300: OBJECT (6,6 Prozentpunkte netto); 300→150: ORG (17,0 Prozentpunkte netto); 150→75: NUMBER (23,4 Prozentpunkte netto). Die Rangfolgen unterscheiden sich, weil einige Faktenläufe wieder zu Retained wechseln. Die Intervalle überlappen; die höchsten Punktschätzungen belegen keine eindeutigen Typenunterschiede. Details und Nenner je Typ stehen in der ergänzenden Übergangstabelle.

Abbildung 4.4c stellt das stufenspezifische Risiko als Retained→nicht-Retained-Anteil unter den zuvor Retained bewerteten Fällen dar. Zero-Shot-CoT, Auto-CoT und Automate-CoT sind für jede Linie zusammengefasst; alle acht Entitätstypen werden gemeinsam gezeigt. So lässt sich erkennen, bei welchen Typen die Verlustanteile an den späteren Übergängen ansteigen. Die Intervalle sind artikelbasiert; überlappende Intervalle und die explorative Auswahl erlauben keine gesicherte Rangfolge.

Bei 75 Wörtern ergaben sich für NUMBER folgende Werte unter gültigen QA-Urteilen: Lead-k: 92/526 (17,5 %); Plain: 241/525 (45,9 %); Zero-Shot-CoT: 185/526 (35,2 %); Few-Shot-CoT: 231/526 (43,9 %); Auto-CoT: 259/526 (49,2 %); Automate-CoT: 229/526 (43,5 %). Die methodenspezifischen Intervalle und alle übrigen Typen/Stufen stehen in Abbildung und Anhang.

Bei 75 Wörtern ergaben sich für PERSON folgende Werte unter gültigen QA-Urteilen: Lead-k: 57/420 (13,6 %); Plain: 120/416 (28,8 %); Zero-Shot-CoT: 103/419 (24,6 %); Few-Shot-CoT: 114/416 (27,4 %); Auto-CoT: 130/420 (31,0 %); Automate-CoT: 130/417 (31,2 %). Die methodenspezifischen Intervalle und alle übrigen Typen/Stufen stehen in Abbildung und Anhang.

Bei 75 Wörtern ergaben sich für LOCATION folgende Werte unter gültigen QA-Urteilen: Lead-k: 57/255 (22,4 %); Plain: 57/255 (22,4 %); Zero-Shot-CoT: 58/255 (22,7 %); Few-Shot-CoT: 71/255 (27,8 %); Auto-CoT: 76/255 (29,8 %); Automate-CoT: 81/255 (31,8 %). Die methodenspezifischen Intervalle und alle übrigen Typen/Stufen stehen in Abbildung und Anhang.

Bei 75 Wörtern ergaben sich für EVENT folgende Werte unter gültigen QA-Urteilen: Lead-k: 22/80 (27,5 %); Plain: 32/79 (40,5 %); Zero-Shot-CoT: 29/80 (36,2 %); Few-Shot-CoT: 26/79 (32,9 %); Auto-CoT: 36/79 (45,6 %); Automate-CoT: 32/80 (40,0 %). Die methodenspezifischen Intervalle und alle übrigen Typen/Stufen stehen in Abbildung und Anhang.

## Kurzer Abschluss

Die Laufbahnen unterscheiden frühe Nicht-Retained-Bewertungen bei 500 von späteren Bewertungen und von vollständig erhaltenen Laufbahnen. Rückwechsel treten auf und müssen als QA-Labelwechsel gelesen werden. In 6/6 Verfahren lag bei 75 Wörtern der beobachtete faktengewichtete Anteil für NUMBER über PERSON. Das ist ein explorativer Befund ohne bestätigte Typenrangfolge; insbesondere EVENT beruht auf einer kleineren Faktenbasis. Ursachen und die Bedeutung für die Zusammenfassungsqualität werden in Kapitel 5 diskutiert.

Die Hauptauswertung enthält 40 regelbasierte NOT_FOUND-Positionen aus zwei leeren Zero-Shot-CoT-Ausgaben. Die gemeinsame Sensitivität ohne die beiden betroffenen Artikel umfasst 98 Artikel und 1.960 Faktenlaufbahnen je Verfahren; die größte absolute Änderung einer Kategorie der ersten Stufe beträgt 0,72 Prozentpunkte. Die Sensitivität beseitigt keine allgemeinen QA-Messfehler.

**Abbildung 4.4a:** Erste Nicht-Retained-Bewertung je Verfahren, einschließlich durchgehend Retained und nicht eindeutig bestimmbarer Laufbahnen; n = 2.000 je Verfahren. Nicht Retained = Lost oder reference_discordant; technische QA-Fehlwerte erhalten kein Verlustlabel.

**Abbildung 4.4b:** Faktengewichtete QA-Retention nach Entitätstyp über die vier Zielstufen; gleiche Skalen, Fakten- und Artikelzahlen je Panel, punktweise 95-%-Artikelbootstrap-Intervalle. EVENT ist nach der angegebenen Darstellungsschwelle eine kleine Gruppe.

**Abbildung 4.4c:** Anteil der zuvor Retained bewerteten Faktenläufe, die je Übergang zu Lost oder reference_discordant wechseln; Zero-Shot-CoT, Auto-CoT und Automate-CoT gepoolt zu einer Linie je Typ. Alle acht Entitätstypen in einem gemeinsamen Diagramm. Nenner und punktweise 95-%-Artikelbootstrap-Intervalle stehen in der Übergangstabelle.