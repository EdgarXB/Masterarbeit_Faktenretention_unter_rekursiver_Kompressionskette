# 4.2 QA-basierte Faktenretention

Verwendet wurde der am 1. Oktober 2026 abgeschlossene Ergebnisstand, der die ursprünglichen Ergebnisse von Lead-k, Zero-Shot-CoT, Auto-CoT und Automate-CoT mit neuen Plain- und Few-shot-CoT-Ketten vom 30. September verbindet. Die Ersetzung erfolgte nach dem ursprünglichen Protokoll-Freeze; der ursprüngliche Lauf wird daher als separate Versionssensitivität ausgewiesen.

Die Analyse umfasste 100 Artikel, sechs Verfahren und vier rekursive Zielstufen von 500, 300, 150 und 75 Wörtern. Je Artikel wurden dieselben 20 kanonischen Originalfakten verwendet. Alle 2.400 Zusammenfassungspositionen und 48.000 vorgesehenen QA-Positionen lagen vor. Davon waren 47.804 exportierte QA-Positionen auswertbar und 196 aufgrund fehlender maschinell prüfbarer Textbelege technisch nicht auswertbar. Technisch fehlende QA-Urteile erhielten kein inhaltliches Verlustlabel. Zusätzlich gab es zwei leere Zero-shot-CoT-Ausgaben. Dafür wurden insgesamt 40 NOT_FOUND-Positionen regelbasiert ohne QA-Modellantwort eingetragen; sie sind in der reproduzierten End-to-end-Auswertung enthalten und werden als Generierungsfehler separat ausgewiesen. Eine der beiden Ketten wurde anschließend mit leerer Eingabe fortgesetzt. Die Sensitivität ohne beide betroffenen Artikel erhält 98 Artikel für alle Methoden. Die primäre Retention wurde entsprechend der implementierten Auswertung zunächst pro Artikel als Anteil retained unter den gültigen Urteilen und anschließend gleichgewichtet über die Artikel berechnet. Je Artikel-Methoden-Stufe standen 17 bis 20 gültige Urteile zur Verfügung. Ergänzend wurden Grenzen mit festem Nenner von 20 Fakten berechnet.

Unsicherheitsintervalle beruhen auf 10.000 Bootstrap-Stichproben auf Artikelebene mit Seed 32. Bei Methoden- und Stufenvergleichen wurde die Paarung derselben Artikel erhalten. Die Intervalle sind punktweise 95-%-Perzentilintervalle; sie beschreiben Artikelheterogenität bei fest vorliegenden automatischen Labels.

## 4.2.1 Retentionsverlauf über die Kompressionsstufen

Die gemessene Retention nahm bei allen sechs Verfahren im Mittel von 500 auf 75 Zielwörter ab. Abbildung 4.X zeigt die Verläufe auf einer gemeinsamen Skala von 0 bis 100 %. Die Stufen beziehen sich auf Zielwortzahlen; ihre tatsächliche Einhaltung wird im folgenden Abschnitt getrennt untersucht.

Lead-k lag bei 500 Zielwörtern mit 75,6 % (95-%-KI [72,8; 78,3]) am höchsten, fiel jedoch bis 75 Wörter auf 17,3 % (95-%-KI [15,6; 19,1]). Die gesamte gepaarte Änderung betrug -58,3 Prozentpunkte. Unter den generativen Verfahren lag Automate-CoT bei 500 Wörtern mit 73,4 % (95-%-KI [70,6; 76,1]) am höchsten. Bei 75 Wörtern erreichte Auto-CoT den höchsten Mittelwert (39,1 % (95-%-KI [36,4; 41,7])), gefolgt von Automate-CoT (37,0 % (95-%-KI [34,1; 39,9])), Few-Shot-CoT (34,6 % (95-%-KI [31,7; 37,5])), Plain (33,8 % (95-%-KI [30,9; 36,7])) und Zero-Shot-CoT (28,9 % (95-%-KI [26,1; 31,8])). Diese Rangfolge ist deskriptiv; ihre Unsicherheit wird durch gepaarte Kontraste untersucht.

Bei allen fünf generativen Verfahren trat der größte mittlere Rückgang im letzten Übergang von 150 auf 75 Zielwörter auf. Er reichte von 11,3 Prozentpunkten bei Plain bis 24,7 Prozentpunkten bei Zero-Shot-CoT. Lead-k zeigte seinen stärksten Rückgang bereits bei 500→300 Wörtern (26,2 Prozentpunkte). Plain wies insgesamt den geringsten absoluten Rückgang auf (21,1 Prozentpunkte), begann aber auch mit dem niedrigsten Ausgangsniveau. Ein geringerer Rückgang allein bedeutet deshalb keine höhere Retention.

Die Position des stärksten Rückgangs wird deskriptiv aus drei Stufenübergängen gewählt und ist kein gesondert getesteter Unterschied zwischen Rückgängen. Spätere Anstiege einzelner Artikel oder Fakten wurden als QA-Labelwechsel erfasst; aus ihnen lässt sich ohne Textprüfung keine tatsächliche Wiedergewinnung von Information ableiten.

## 4.2.2 Gepaarter Vergleich der Verfahren

Tabelle 4.X berichtet die vier in den Auswertungsvorgaben genannten Kontraste für jede Zielstufe. Positive Werte entsprechen einer höheren Retention der erstgenannten Methode. Lead-k wird als zusätzliche deskriptive Baseline gezeigt und gehört nicht zu diesen vier Kontrasten.

Für Zero-Shot-CoT − Plain ergaben sich folgende gepaarte Differenzen mit 95-%-Intervallen: 500 Wörter: 17,0 pp [14,3; 19,8]; 300 Wörter: 17,8 pp [15,1; 20,6]; 150 Wörter: 8,5 pp [5,6; 11,3]; 75 Wörter: -4,9 pp [-7,6; -2,2]. Jeder Vergleich umfasste 100 Artikelpaare.

Für Few-Shot-CoT − Plain ergaben sich folgende gepaarte Differenzen mit 95-%-Intervallen: 500 Wörter: 9,3 pp [6,8; 11,9]; 300 Wörter: 11,0 pp [8,5; 13,6]; 150 Wörter: 5,7 pp [3,3; 8,1]; 75 Wörter: 0,8 pp [-1,7; 3,2]. Jeder Vergleich umfasste 100 Artikelpaare.

Für Auto-CoT − Few-Shot-CoT ergaben sich folgende gepaarte Differenzen mit 95-%-Intervallen: 500 Wörter: 7,1 pp [4,9; 9,5]; 300 Wörter: 7,1 pp [5,0; 9,3]; 150 Wörter: 7,2 pp [4,5; 9,8]; 75 Wörter: 4,5 pp [2,2; 6,9]. Jeder Vergleich umfasste 100 Artikelpaare.

Für Automate-CoT − Auto-CoT ergaben sich folgende gepaarte Differenzen mit 95-%-Intervallen: 500 Wörter: 2,0 pp [0,1; 4,0]; 300 Wörter: 1,0 pp [-1,1; 3,0]; 150 Wörter: -4,1 pp [-6,5; -1,7]; 75 Wörter: -2,1 pp [-4,5; 0,3]. Jeder Vergleich umfasste 100 Artikelpaare.

Damit wechselte Zero-Shot-CoT gegenüber Plain von einem positiven Unterschied bei den drei längeren Zielstufen zu einem negativen Unterschied bei 75 Wörtern. Few-Shot-CoT lag dort nur geringfügig über Plain, und sein Intervall umfasste 0. Auto-CoT lag in allen vier Zielstufen über Few-Shot-CoT. Automate-CoT zeigte gegenüber Auto-CoT keinen durchgehend positiven Unterschied; bei 150 Wörtern war der Mittelwert niedriger. Diese Befunde sprechen für stufenabhängige Unterschiede und nicht für einen einheitlichen Vorteil sämtlicher CoT-Verfahren.

Die konservative Setzung fehlender Urteile auf 0 veränderte die mittlere Retention gegenüber der Hauptauswertung um höchstens 0,6 Prozentpunkte. Zusätzlich wurden gegenläufige Missingness-Grenzen, vollständig bewertete Paare sowie ein gemeinsamer vollständiger Panel von 47 Artikeln ausgewertet. Im vollständigen Panel wechselte der kleine Few-Shot-CoT−Plain-Unterschied bei 75 Wörtern das Vorzeichen. Der Ausschluss der beiden Generierungsfehler änderte die Richtung der vier Kontraste nicht. Der vollständige Panel ändert die Artikelbasis und kann daher selektiv sein; die entsprechenden Ergebnisse und Artikelzahlen stehen im Anhang.

Die 16 dargestellten Intervalle sind nicht für Mehrfachvergleiche korrigiert. Da das eingefrorene Protokoll keine formale Entscheidungsregel für H1 enthält, werden die Methodenunterschiede als Effektgrößen mit Unsicherheit berichtet und nicht als nachträglich definierte Bestätigung der Hypothese. Höhere QA-Retention bei derselben Zielwortzahl ist außerdem ohne Berücksichtigung der tatsächlichen Textlänge keine vollständige Aussage über die Überlegenheit eines Verfahrens.

Die Befunde beruhen auf der kalibrierten automatischen QA-Pipeline. Die historische Human-Validierung wurde zur Entwicklung dieser Bewertung verwendet und liefert keine Fehlerrate für den finalen Faktensatz. NOT_FOUND und Referenzabweichungen sind daher automatische Messurteile; insbesondere sind Referenzabweichungen kein direkter Nachweis von Halluzinationen der Zusammenfassung.

**Tabelle 4.X.** Gepaarte Differenzen in Prozentpunkten mit punktweisen 95-%-Artikelbootstrap-Intervallen und Artikelzahl.

| Vergleich | 500 Wörter | 300 Wörter | 150 Wörter | 75 Wörter |
|---|---:|---:|---:|---:|
| Zero-Shot-CoT − Plain | 17,0 [14,3; 19,8]; n=100 | 17,8 [15,1; 20,6]; n=100 | 8,5 [5,6; 11,3]; n=100 | -4,9 [-7,6; -2,2]; n=100 |
| Few-Shot-CoT − Plain | 9,3 [6,8; 11,9]; n=100 | 11,0 [8,5; 13,6]; n=100 | 5,7 [3,3; 8,1]; n=100 | 0,8 [-1,7; 3,2]; n=100 |
| Auto-CoT − Few-Shot-CoT | 7,1 [4,9; 9,5]; n=100 | 7,1 [5,0; 9,3]; n=100 | 7,2 [4,5; 9,8]; n=100 | 4,5 [2,2; 6,9]; n=100 |
| Automate-CoT − Auto-CoT | 2,0 [0,1; 4,0]; n=100 | 1,0 [-1,1; 3,0]; n=100 | -4,1 [-6,5; -1,7]; n=100 | -2,1 [-4,5; 0,3]; n=100 |

**Abbildung 4.X.** Retentionsverlauf der sechs Verfahren; n = 100 Artikel je Methode/Stufe. Technische QA-Fehlwerte werden aus dem primären Artikelnenner ausgeschlossen. Zwei leere Zero-shot-Ausgaben gehen gemäß implementierter End-to-end-Regel mit 0 ein; Sensitivitäten sind separat berichtet.
