# 4.3 Längeneinhaltung und längenadjustierte Faktenretention

## 4.3.1 Einhaltung der Wortvorgaben

Für F3 wurden die tatsächlich erzeugten Texte von 100 Artikeln, sechs Verfahren und vier rekursiven Zielstufen untersucht (2.400 Artikel-Methoden-Stufen-Zeilen). Verwendet wurde derselbe aktuelle Datenstand wie in Kapitel 4.2: vier ursprüngliche Verfahren und die neuen Plain-/Few-Shot-CoT-Ketten vom 30. September 2026. Die Regex-Wortzählung wurde gegen sämtliche gespeicherten Zähler geprüft. Die zulässigen inklusiven Fenster waren 475–525, 285–315, 142–158 und 71–79 Wörter. Abbildung 4.3-1 zeigt die Unter-/Fenster-/Überzahlen; n = 100 je Verfahren und Stufe.

Lead-k hielt alle vier Fenster bei sämtlichen Artikeln ein. Für die generativen Verfahren zeigte sich dagegen ein stufenabhängiges Muster.

Bei 500 Zielwörtern zeigte sich folgendes Muster: Plain, Zero-Shot-CoT und Few-Shot-CoT trafen das Fenster bei keinem Artikel; Auto-CoT bei 1, Automate-CoT bei 5/100. Alle Fehler waren Unterschreitungen. Der mittlere normalisierte Abstand D reichte unter den generativen Verfahren von 0,166 bei Automate-CoT bis 0,531 bei Plain (95-%-Artikelbootstrap-Intervall [0,513; 0,549]).

Bei 300 Zielwörtern zeigte sich folgendes Muster: Plain unterschritt das Fenster bei 98/100 Artikeln. Die CoT-Verfahren trafen es bei 19–29/100 und zeigten Fehler in beiden Richtungen. Auto-CoT und Automate-CoT überschritten es bei 41 beziehungsweise 44/100. Der mittlere normalisierte Abstand D reichte unter den generativen Verfahren von 0,070 bei Zero-Shot-CoT bis 0,368 bei Plain (95-%-Artikelbootstrap-Intervall [0,342; 0,392]).

Bei 150 Zielwörtern zeigte sich folgendes Muster: Die CoT-Verfahren erzeugten bei 78–97/100 Artikeln Überlängen. Plain lag bei 39 Artikeln unter, 22 im und 39 über dem Fenster. Der mittlere normalisierte Abstand D reichte unter den generativen Verfahren von 0,111 bei Plain bis 0,384 bei Auto-CoT (95-%-Artikelbootstrap-Intervall [0,329; 0,442]).

Bei 75 Zielwörtern zeigte sich folgendes Muster: Zero-Shot-CoT traf das Fenster bei 33/100 Artikeln, lag jedoch bei 53 darüber und 14 darunter. Die anderen generativen Verfahren überschritten es bei 86–100/100. Der mittlere normalisierte Abstand D reichte unter den generativen Verfahren von 0,115 bei Zero-Shot-CoT bis 0,482 bei Automate-CoT (95-%-Artikelbootstrap-Intervall [0,423; 0,548]).

Die Fehlergröße ergänzt die Trefferquote: Bei 75 Wörtern lagen Auto-CoT und Automate-CoT im Mittel bei 115,1 beziehungsweise 115,2 Wörtern und D ≈ 0,48. Dieser D-Wert misst den Abstand jenseits der erlaubten Grenze, nicht den Abstand zum Sollwert. Zwei leere Zero-Shot-Ausgaben (bei 150 und 75 Wörtern) blieben als Unterschreitungen und Generierungsfehler enthalten; auch die fortgesetzte leere Informationskette blieb markiert.

## 4.3.2 Faktenretention unter Berücksichtigung der Länge

Abbildung 4.3-2 stellt die mittlere beobachtete QA-Retention R_obs = K/V dem mittleren D gegenüber. Die 24 Punkte sind Methoden-Stufen-Mittelwerte über dieselben 100 Artikel, keine artikelweise Korrelation oder Kausalwirkung der Länge. Bei 500 Wörtern dominiert Lead-k nach den Punktschätzern alle anderen Verfahren: höhere Retention und geringere D. Bei 150 Wörtern wird dagegen kein Verfahren dominiert. Die Pareto-Markierung berücksichtigt keine Unsicherheit.

Für H2 wurde zusätzlich pro Artikel R_adj = (K/20)/(1+D) berechnet und anschließend gemittelt. Technisch fehlende QA-Urteile gelten beim festen Nenner K/20 als nicht erhalten. Innerhalb des Fensters entspricht R_adj daher R_zero, nicht grundsätzlich R_obs. Der Abschlag wurde in den Nenneranteil R_obs−R_zero und den Längenanteil R_zero−R_adj zerlegt. Im Hauptpanel veränderte der Nenneranteil keine Rangfolge; die beobachteten Wechsel entstanden erst durch D.

Der feste QA-Nenner verringerte den Gruppenmittelwert um höchstens 0,57 Prozentpunkte; der reine Längenabschlag erreichte dagegen bis zu 18,45 Prozentpunkte. Beide Größen werden getrennt im Anhang ausgewiesen.

Bei 500 Wörtern blieb die Rangfolge unverändert. Lead-k erreichte den höchsten adjustierten Mittelwert (75,40 %). Zero-Shot-CoT und Auto-CoT lagen nach Adjustierung nur 0,08 Prozentpunkte auseinander (gepaartes 95-%-Intervall [-1,95; 2,08]).

Bei 300 Wörtern änderte die Adjustierung die Rangfolge. Zero-Shot-CoT überholte Auto-CoT, Lead-k überholte Plain. Die höchsten adjustierten Mittelwerte waren Automate-CoT 63,86 %, Zero-Shot-CoT 63,62 %, Auto-CoT 62,77 %. Der Abstand der beiden führenden Verfahren betrug 0,24 Prozentpunkte [-2,18; 2,62].

Bei 150 Wörtern änderte die Adjustierung die Rangfolge. Zero-Shot-CoT stieg von Rang 3 auf 1; Auto-CoT fiel von 1 auf 4. Die höchsten adjustierten Mittelwerte waren Zero-Shot-CoT 44,06 %, Few-Shot-CoT 43,07 %, Automate-CoT 42,88 %, Auto-CoT 42,54 %. Der Abstand der beiden führenden Verfahren betrug 0,99 Prozentpunkte [-1,50; 3,43].

Bei 75 Wörtern änderte die Adjustierung die Rangfolge. Zero-Shot-CoT stieg von Rang 5 auf 2; Auto-CoT blieb auf Rang 1. Die höchsten adjustierten Mittelwerte waren Auto-CoT 26,88 %, Zero-Shot-CoT 26,34 %, Few-Shot-CoT 26,13 %. Der Abstand der beiden führenden Verfahren betrug 0,54 Prozentpunkte [-1,63; 2,77].

Damit unterschied sich die Rangfolge nach R_adj auf drei von vier Stufen von der Rangfolge nach R_obs (11 von 24 Rangpositionen; Tabelle 4.3-1). Dies entspricht H2 als deskriptivem Rangvergleich; eine nachträgliche formale Testentscheidung wird daraus nicht abgeleitet. Die knappen Spitzenabstände und ihre Intervalle belegen keinen klaren Leistungsvorteil. Artikelbootstrap-Ranghäufigkeiten stehen im Anhang.

Nach gemeinsamem Ausschluss der beiden Fehlerartikel (n = 98 für alle Verfahren) blieben die zentralen Längenmuster und Rangänderungen auf drei Stufen bestehen. Die adjustierte Spitzenposition bei 75 Wörtern wechselte jedoch von Auto-CoT zu Zero-Shot-CoT (26,87 % gegenüber 26,80 %; gepaarte Differenz 0,08 pp [-1,94; 2,05]). Bei 300 Wörtern entstand die Vertauschung von Auto-CoT und Zero-Shot-CoT bereits durch den festen QA-Nenner; Lead-k und Plain waren auf dieser Zwischenkennzahl exakt gleichrangig. Die Herkunft von Rangwechseln ist somit teilweise populationsabhängig.

Die Intervalle beruhen auf 10.000 gepaarten Artikelbootstrap-Ziehungen mit Seed 32 und sind punktweise, nicht für Mehrfachvergleiche korrigiert. Die adjustierte Sekundärkennzahl beschreibt einen festgelegten Trade-off und ersetzt nicht die getrennte Beurteilung von QA-Retention und Längeneinhaltung. Vollständige Verteilungen und Abschlagskomponenten stehen im Anhang.

**Tabelle 4.3-1.** Rang nach R_obs → Rang nach R_adj; * markiert Wechsel. Ungerundete Artikelmittelwerte, n = 100.

| Verfahren | 500 Wörter | 300 Wörter | 150 Wörter | 75 Wörter |
|---|---:|---:|---:|---:|
| Lead-k | 1 → 1 | 6 → 5 * | 6 → 6 | 6 → 6 |
| Plain | 6 → 6 | 5 → 6 * | 5 → 5 | 4 → 5 * |
| Zero-Shot-CoT | 3 → 3 | 3 → 2 * | 3 → 1 * | 5 → 2 * |
| Few-Shot-CoT | 5 → 5 | 4 → 4 | 4 → 2 * | 3 → 3 |
| Auto-CoT | 4 → 4 | 2 → 3 * | 1 → 4 * | 1 → 1 |
| Automate-CoT | 2 → 2 | 1 → 1 | 2 → 3 * | 2 → 4 * |

**Abbildung 4.3-1.** Einhaltung der inklusiven Wortfenster: Anzahl unter, im und über dem Fenster, n = 100 je Verfahren und Stufe.

**Abbildung 4.3-2.** Mittlere beobachtete QA-Retention und mittlere normalisierte Fensterabweichung; 24 Methoden-Stufen-Mittelwerte, jeweils n = 100. Ringe markieren nichtdominierte Punktschätzer ohne Unsicherheit.
