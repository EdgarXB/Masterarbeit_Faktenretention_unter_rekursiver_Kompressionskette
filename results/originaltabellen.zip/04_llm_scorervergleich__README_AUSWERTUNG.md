# LLM-Rater-Vergleich – keine Human Validation

Ausgewertet werden die drei neu hochgeladenen LLM-Ausgaben; frühere Mock-Dateien und historische menschliche Urteile werden nicht hinzugemischt.

200 gemeinsame Fälle, 600 gültige LLM-Urteile. Eindeutige Drei-Klassen-Mehrheit: **138/200**; Sonderfallmehrheit: **60**; Gleichstände: **2**.

| Scorer gegen LLM-Mehrheit | Richtig / auswertbar | Accuracy | 95%-Artikel-Cluster-Intervall | Macro-F1 | Kappa |
|---|---:|---:|---|---:|---:|
| Kalibrierter QA-Scorer | 113 / 138 | 81.9% | 75.8% bis 87.6% | 0.735 | 0.685 |
| Rekonstruierte Regel vor Kalibrierung | 50 / 138 | 36.2% | 27.3% bis 45.5% | 0.411 | 0.262 |

Vollständige Übereinstimmung aller drei Modelle: 166/200 (83.0%). Paarweise Gesamtübereinstimmung: 88.3%. Nominales Krippendorff-Alpha über vier Klassen: 0.824.

| Eingabe (Modellname laut Dateiname) | Retained | Lost | Unsupported | Sonderfall |
|---|---:|---:|---:|---:|
| Gemini_4_Argon_medium | 88 | 36 | 16 | 60 |
| Claude_Sonnet_5.5_medium | 93 | 31 | 9 | 67 |
| GPT-61_sol_medium | 92 | 43 | 7 | 58 |

## Vergleich zu jedem einzelnen Modell

Hier ist der jeweilige LLM-Rater die Referenz; seine Sonderfälle sind ausgeschlossen. Unterschiedliche Nenner erlauben keine Rangfolge der Modellqualität.

| Referenz-Rater | Kalibrierter Scorer stimmt überein | Accuracy |
|---|---:|---:|
| participant_01 | 115 / 140 | 82.1% |
| participant_02 | 108 / 133 | 81.2% |
| participant_03 | 115 / 142 | 81.0% |

## Methodik und Grenzen

Die vier Klassen gehen vollständig in die Übereinstimmungsanalyse ein. Eine Hauptklassenmehrheit erfordert mindestens zwei von drei Stimmen; eine Sonderfall-Minderheitsstimme wird nicht entfernt. Eine Sonderfallmehrheit oder drei unterschiedliche Stimmen führen zum Ausschluss aus dem Drei-Klassen-Scorervergleich. Alle Ausschlüsse sind als Fallliste dokumentiert.

Unsicherheit: 10,000 gepaarte Artikel-Cluster-Resamples, Seed 32, 95%-Perzentilintervalle; alle Fälle eines gezogenen Artikels reisen gemeinsam. Keine erfundenen Auswahlgewichte. Sensitivitäten für einstimmige Urteile und Fälle ohne Sonderfallstimme stehen in llm_results.json.

- Automated LLM judgments, not human validation or proof of factual truth. Different claimed model families do not establish independent errors.
- Model names and medium settings are supplied in filenames; full prompts, verified version/digest, parameters and independent run receipts are missing.
- Browser interaction fields and timestamps from model-generated JSON are not treated as measured behavior or verified run times.
- The targeted difficult-case sample is not representative of the full main experiment. No fabricated sampling weights are used.
- Special votes are kept as a fourth nominal category for agreement. Ties and special-majority cases are excluded from three-class scorer comparisons; retained coverage is reported.
- Scorer accuracy is agreement with LLM majority, not LLM accuracy against external truth. A majority including a model itself is not an independent benchmark for ranking those models.
- Bootstrap intervals are conditional on fixed model outputs and consensus cases; they do not cover model/run/prompt uncertainty or selection bias.
- Unsupported is not synonymous with proven hallucination; comments are qualitative claims, not verified error subtype counts.
- No new Jev predictions or verified Jev model metadata are available; a Jev versus calibrated comparison is not possible.

## Dateien und Reproduktion

`llm_results.json` enthält alle Metriken, Konfusionsmatrizen, Intervalle und Quellenhashes. `calibrated_disagreements.csv` enthält die konkret abweichenden Fälle einschließlich Texte und LLM-Kommentare. `all_200_cases_llm_consensus.csv` erhält alle Fall- und Stimmeninformationen. Timingfelder werden bewusst nicht in die 600-Zeilen-Analysedatei übernommen.

Aus dem Studienordner in einen neuen Ausgabeordner starten:

```bash
python3 -B llm_auswertung/auswertung_llm_rater.py --output llm_auswertung/erneute_auswertung
```

Die ursprünglichen JSON-Dateien, die HTML-Anwendung, die Teilnehmerkonfigurationen und das eingefrorene Hauptexperiment bleiben unverändert. Die Herkunftsnamen sind Angaben der Dateien; die tatsächlichen Modellversionen und die behauptete Unabhängigkeit wurden nicht extern verifiziert.

## Konkrete Abweichungen und Prüfstatus

Von 25 Abweichungen des kalibrierten Scorers sind 23 Fälle LLM-Mehrheit Retained / Scorer Unsupported und zwei Fälle LLM-Mehrheit Unsupported / Scorer Retained. Das ist eine beobachtete Labelabweichung; semantische Fehlerarten sind damit noch nicht unabhängig bewiesen. Nur neun primäre Konsensfälle gehören zur Klasse Unsupported. Die entsprechende Precision beträgt 0,233, Recall 0,778 und F1 0,359; kleine Fallzahl und gezielte Auswahl beachten.

Fünf separate Prüfgruppen bestanden: unabhängige Rekonstruktion der Mehrheitslabels und Kennzahlen aus den Originaldateien, Abstimmung aller Exportnenner, unveränderte Eingabe- und Studienhashes, Abweisung doppelter JSON-Schlüssel sowie Artikel-Cluster- und Vier-Klassen-Prüfungen. Das vollständige Protokoll steht in `validation_tests.log`.
