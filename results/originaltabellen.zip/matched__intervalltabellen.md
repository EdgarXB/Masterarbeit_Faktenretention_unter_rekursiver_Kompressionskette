# Begleitende 95-%-Bootstrap-Perzentilintervalle

10.000 Ziehungen vollständiger Artikelpaare, Seed 32. ΔR = Zeile − Spalte in Prozentpunkten. Punktweise Intervalle, keine Korrektur für multiple Vergleiche. †: n < 10; Hinweis auf kleine Stichprobe, keine feste Belastbarkeitsgrenze. Für n < 2 kein Intervall. Datenstand: aktuell_20260930.

## 500 Zielwörter

| Zeilenverfahren | Spaltenverfahren | ΔR (PP) | n | 95-%-Perzentilintervall (PP) | Hinweis |
| --- | --- | --- | --- | --- | --- |
| Lead-k | Plain | — | 0 | kein Intervall (n < 2) | kein Vergleich |
| Lead-k | Zero-Shot-CoT | — | 0 | kein Intervall (n < 2) | kein Vergleich |
| Lead-k | Few-Shot-CoT | — | 0 | kein Intervall (n < 2) | kein Vergleich |
| Lead-k | Auto-CoT | +15,00 | 1 | kein Intervall (n < 2) | † kleine Stichprobe |
| Lead-k | Automate-CoT | −11,00 | 5 | [−18,00; −4,00] | † kleine Stichprobe |
| Plain | Zero-Shot-CoT | +5,00 | 1 | kein Intervall (n < 2) | † kleine Stichprobe |
| Plain | Few-Shot-CoT | −7,60 | 4 | [−11,49; −2,50] | † kleine Stichprobe |
| Plain | Auto-CoT | — | 0 | kein Intervall (n < 2) | kein Vergleich |
| Plain | Automate-CoT | — | 0 | kein Intervall (n < 2) | kein Vergleich |
| Zero-Shot-CoT | Few-Shot-CoT | +0,10 | 18 | [−4,06; +3,87] |  |
| Zero-Shot-CoT | Auto-CoT | +0,33 | 29 | [−3,97; +4,66] |  |
| Zero-Shot-CoT | Automate-CoT | +1,43 | 20 | [−3,66; +6,32] |  |
| Few-Shot-CoT | Auto-CoT | −1,86 | 15 | [−5,52; +2,21] |  |
| Few-Shot-CoT | Automate-CoT | +1,67 | 3 | [+0,00; +5,00] | † kleine Stichprobe |
| Auto-CoT | Automate-CoT | +0,46 | 16 | [−3,11; +4,00] |  |

## 300 Zielwörter

| Zeilenverfahren | Spaltenverfahren | ΔR (PP) | n | 95-%-Perzentilintervall (PP) | Hinweis |
| --- | --- | --- | --- | --- | --- |
| Lead-k | Plain | −15,00 | 1 | kein Intervall (n < 2) | † kleine Stichprobe |
| Lead-k | Zero-Shot-CoT | −23,18 | 29 | [−29,38; −17,04] |  |
| Lead-k | Few-Shot-CoT | −7,73 | 18 | [−14,56; −0,91] |  |
| Lead-k | Auto-CoT | −15,42 | 19 | [−22,16; −9,20] |  |
| Lead-k | Automate-CoT | −20,24 | 23 | [−24,31; −16,36] |  |
| Plain | Zero-Shot-CoT | +2,50 | 2 | [+0,00; +5,00] | † kleine Stichprobe |
| Plain | Few-Shot-CoT | −2,38 | 4 | [−13,16; +12,17] | † kleine Stichprobe |
| Plain | Auto-CoT | — | 0 | kein Intervall (n < 2) | kein Vergleich |
| Plain | Automate-CoT | +10,00 | 1 | kein Intervall (n < 2) | † kleine Stichprobe |
| Zero-Shot-CoT | Few-Shot-CoT | +4,96 | 21 | [+0,34; +9,67] |  |
| Zero-Shot-CoT | Auto-CoT | +1,73 | 21 | [−2,22; +5,68] |  |
| Zero-Shot-CoT | Automate-CoT | +2,86 | 24 | [−1,74; +7,36] |  |
| Few-Shot-CoT | Auto-CoT | −3,91 | 22 | [−7,85; +0,01] |  |
| Few-Shot-CoT | Automate-CoT | −5,64 | 23 | [−8,71; −2,46] |  |
| Auto-CoT | Automate-CoT | −2,16 | 24 | [−5,89; +1,35] |  |

## 150 Zielwörter

| Zeilenverfahren | Spaltenverfahren | ΔR (PP) | n | 95-%-Perzentilintervall (PP) | Hinweis |
| --- | --- | --- | --- | --- | --- |
| Lead-k | Plain | −17,81 | 19 | [−24,65; −10,44] |  |
| Lead-k | Zero-Shot-CoT | −22,26 | 14 | [−29,64; −14,64] |  |
| Lead-k | Few-Shot-CoT | −15,30 | 15 | [−24,25; −5,91] |  |
| Lead-k | Auto-CoT | −12,50 | 2 | [−30,00; +5,00] | † kleine Stichprobe |
| Lead-k | Automate-CoT | −18,39 | 8 | [−24,38; −13,12] | † kleine Stichprobe |
| Plain | Zero-Shot-CoT | −3,57 | 9 | [−11,35; +3,27] | † kleine Stichprobe |
| Plain | Few-Shot-CoT | +0,67 | 13 | [−4,23; +5,47] |  |
| Plain | Auto-CoT | −2,50 | 4 | [−5,00; +0,00] | † kleine Stichprobe |
| Plain | Automate-CoT | +1,88 | 7 | [−5,71; +10,19] | † kleine Stichprobe |
| Zero-Shot-CoT | Few-Shot-CoT | +2,97 | 19 | [−1,55; +7,69] |  |
| Zero-Shot-CoT | Auto-CoT | +3,63 | 16 | [−2,81; +10,39] |  |
| Zero-Shot-CoT | Automate-CoT | +0,63 | 20 | [−5,12; +6,25] |  |
| Few-Shot-CoT | Auto-CoT | +1,39 | 14 | [−3,59; +6,43] |  |
| Few-Shot-CoT | Automate-CoT | +1,49 | 17 | [−5,00; +7,97] |  |
| Auto-CoT | Automate-CoT | +0,93 | 20 | [−3,71; +5,44] |  |

## 75 Zielwörter

| Zeilenverfahren | Spaltenverfahren | ΔR (PP) | n | 95-%-Perzentilintervall (PP) | Hinweis |
| --- | --- | --- | --- | --- | --- |
| Lead-k | Plain | −12,74 | 7 | [−25,00; −2,52] | † kleine Stichprobe |
| Lead-k | Zero-Shot-CoT | −7,17 | 21 | [−11,43; −2,67] |  |
| Lead-k | Few-Shot-CoT | −9,06 | 5 | [−12,12; −6,00] | † kleine Stichprobe |
| Lead-k | Auto-CoT | — | 0 | kein Intervall (n < 2) | kein Vergleich |
| Lead-k | Automate-CoT | −10,00 | 1 | kein Intervall (n < 2) | † kleine Stichprobe |
| Plain | Zero-Shot-CoT | +0,00 | 8 | [−3,75; +3,75] | † kleine Stichprobe |
| Plain | Few-Shot-CoT | −2,31 | 15 | [−6,98; +2,02] |  |
| Plain | Auto-CoT | −3,89 | 18 | [−7,78; −0,28] |  |
| Plain | Automate-CoT | +2,27 | 11 | [−4,09; +9,09] |  |
| Zero-Shot-CoT | Few-Shot-CoT | +1,92 | 10 | [−4,37; +7,71] |  |
| Zero-Shot-CoT | Auto-CoT | −1,88 | 8 | [−6,25; +3,12] | † kleine Stichprobe |
| Zero-Shot-CoT | Automate-CoT | +6,67 | 3 | [−15,00; +20,00] | † kleine Stichprobe |
| Few-Shot-CoT | Auto-CoT | −2,29 | 16 | [−8,12; +3,96] |  |
| Few-Shot-CoT | Automate-CoT | +2,65 | 17 | [−0,88; +6,47] |  |
| Auto-CoT | Automate-CoT | +1,18 | 23 | [−3,08; +5,53] |  |

